## MUI Storybook _by Amplicode Team_ [![npm version](https://img.shields.io/npm/v/@amplicode/amplicode-ra-storybook.svg)](https://www.npmjs.com/package/@amplicode/amplicode-ra-storybook)

The package provides a set of Storybook MUI components.

To get the most from it try the [Amplicode](https://marketplace.visualstudio.com/items?itemName=Haulmont.amplicode) extension, that allows to examine the stories directly within VS Code and use it as a component palette.

![palette and preview](media/palette_and_preview.png)