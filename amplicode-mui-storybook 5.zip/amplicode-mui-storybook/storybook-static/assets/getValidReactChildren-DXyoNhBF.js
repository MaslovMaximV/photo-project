import{r}from"./iframe-U1MoWpc_.js";function a(t){return r.Children.toArray(t).filter(e=>r.isValidElement(e))}export{a as g};
