function s(r){try{return r.matches(":focus-visible")}catch{}return!1}export{s as i};
