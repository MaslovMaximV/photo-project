import{j as n,G as o,a as l}from"./iframe-U1MoWpc_.js";import{G as r}from"./Grid-DSEZCbod.js";import{B as d}from"./Box-nnrC_EdN.js";import{P as s}from"./Paper-BtmMZDrw.js";import{T as a}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./styled-DKEkqMyo.js";import"./extendSxProp-Cl0Joej-.js";import"./isMuiElement-BH3XSIgM.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./memoTheme-BNYDzr43.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const F={title:"Layout/Grid",component:r,parameters:{layout:"centered",controls:{exclude:["divider"]}},decorators:[e=>n.jsx(d,{width:500,children:e()})],argTypes:{spacing:{control:"select",options:[1,2,3,4,5,6,7,8]},rowSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columnSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columns:{control:"select",options:[7,12,16,20,24]}},args:{spacing:2}},t={render:({...e})=>n.jsxs(r,{container:!0,...e,children:[n.jsx(r,{size:{xs:12,lg:3},children:n.jsx(o.Exclude,{children:n.jsx(s,{children:n.jsx(a,{variant:"body1",textAlign:"center",p:2,children:"Item 1"})})})}),n.jsx(r,{size:{xs:12,lg:3},children:n.jsx(o.Exclude,{children:n.jsx(s,{children:n.jsx(a,{variant:"body1",textAlign:"center",p:2,children:"Item 2"})})})}),n.jsx(r,{size:{xs:12,lg:3},children:n.jsx(o.Exclude,{children:n.jsx(s,{children:n.jsx(a,{variant:"body1",textAlign:"center",p:2,children:"Item 3"})})})})]})},i={render:({...e})=>n.jsx(r,{container:!0,...e,children:l(new Array(10).fill(1).map((p,c)=>c+1)).map(p=>n.jsx(r,{size:{xs:12,lg:3},children:n.jsx(o.Exclude,{children:n.jsx(s,{children:n.jsxs(a,{variant:"body1",textAlign:"center",p:2,children:["Item ",p]})})})}))})};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Grid container {...props}>
        <Grid size={{
        xs: 12,
        lg: 3
      }}>
          <GenerationInstructions.Exclude>
            <Paper>
              <Typography variant="body1" textAlign={"center"} p={2}>
                Item 1
              </Typography>
            </Paper>
          </GenerationInstructions.Exclude>
        </Grid>
        <Grid size={{
        xs: 12,
        lg: 3
      }}>
          <GenerationInstructions.Exclude>
            <Paper>
              <Typography variant="body1" textAlign={"center"} p={2}>
                Item 2
              </Typography>
            </Paper>
          </GenerationInstructions.Exclude>
        </Grid>
        <Grid size={{
        xs: 12,
        lg: 3
      }}>
          <GenerationInstructions.Exclude>
            <Paper>
              <Typography variant="body1" textAlign={"center"} p={2}>
                Item 3
              </Typography>
            </Paper>
          </GenerationInstructions.Exclude>
        </Grid>
      </Grid>;
  }
}`,...t.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Grid container {...props}>
        {replaceOnGenerate(new Array(10).fill(1).map((_, index) => index + 1), []).map(gridItem => {
        return <Grid size={{
          xs: 12,
          lg: 3
        }}>
              <GenerationInstructions.Exclude>
                <Paper>
                  <Typography variant="body1" textAlign={"center"} p={2}>
                    Item {gridItem}
                  </Typography>
                </Paper>
              </GenerationInstructions.Exclude>
            </Grid>;
      })}
      </Grid>;
  }
}`,...i.parameters?.docs?.source}}};const _=["FullStatic","FullLoop"];export{i as FullLoop,t as FullStatic,_ as __namedExportsOrder,F as default};
