import{j as r}from"./iframe-U1MoWpc_.js";import{F as t}from"./FormControlLabel-Bq-a8dVL.js";import{R as m}from"./Radio-BaYSeLyF.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./formControlState-Dq1zat_P.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useFormControl-q410XUqr.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./SwitchBase-9AkWq_7-.js";import"./useControlled-CeZ7-hqo.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./createSvgIcon-Ck9VyYEl.js";import"./createChainedFunction-BO_9K8Jh.js";const k={title:"Inputs/Radio/FormControl",component:t,parameters:{layout:"centered",controls:{exclude:["control"]}},decorators:[],argTypes:{labelPlacement:{control:"select",options:["end","start","top","bottom"]}},args:{labelPlacement:"start"}},o={render:({label:e,labelPlacement:a})=>r.jsx(t,{control:r.jsx(m,{}),label:e,labelPlacement:a}),args:{label:"Label",control:r.jsx(r.Fragment,{})}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    label,
    labelPlacement
  }) => {
    return <FormControlLabel control={<Radio />} label={label} labelPlacement={labelPlacement} />;
  },
  args: {
    label: 'Label',
    control: <></>
  }
}`,...o.parameters?.docs?.source}}};const q=["Label"];export{o as Label,q as __namedExportsOrder,k as default};
