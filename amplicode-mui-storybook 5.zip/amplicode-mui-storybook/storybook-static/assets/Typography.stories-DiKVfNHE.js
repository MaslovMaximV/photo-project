import{t as T,j as r}from"./iframe-U1MoWpc_.js";import{T as e}from"./Typography-NbeDhiLn.js";import{B as v}from"./Box-nnrC_EdN.js";import{P as x}from"./Paper-BtmMZDrw.js";import{L as b}from"./Link-B50BWoEZ.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useTheme-DUWNGOj_.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useTheme-CMyrA-7l.js";import"./isFocusVisible-B8k4qzLc.js";const S=()=>{},M={title:"DataDisplay/Typography",component:e,parameters:{layout:"centered",studioMeta:{kind:"multiple"}},decorators:[],argTypes:{variant:{control:"select",options:["button","caption","h1","h2","h3","h4","h5","h6","subtitle1","subtitle2","body1","body2","overline"]},noWrap:{control:"select",options:[!1,!0]},onClick:{control:"select",options:["default","genTest"],mapping:{default:void 0,genTest:T(S)}}},args:{variant:"h6"}},t={render:()=>r.jsx(e,{variant:"h1",children:"Header"})},a={render:()=>r.jsx(e,{variant:"h2",children:"Header"})},n={render:()=>r.jsx(e,{variant:"h3",children:"Header"})},o={render:()=>r.jsx(e,{variant:"h4",children:"Header"})},s={render:()=>r.jsx(e,{variant:"h5",children:"Header"})},i={render:()=>r.jsx(e,{variant:"h6",children:"Header"})},p={render:()=>r.jsx(e,{variant:"subtitle1",children:"Subtitle"})},c={render:()=>r.jsx(e,{variant:"subtitle2",children:"Subtitle"})},d={render:()=>r.jsx(e,{variant:"body1",children:"Lorem ipsum, dolor sit amet consectetur adipisicing elit. Qui ducimus provident itaque doloribus necessitatibus inventore est porro officia, mollitia nisi laudantium rerum quod praesentium reiciendis eaque corrupti culpa sequi illum!"})},u={render:()=>r.jsx(e,{variant:"body2",children:"Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet nulla perspiciatis dolore cum dicta suscipit dolores molestias ea illum, odit iste a ab, nemo, ut error inventore! Animi, enim recusandae."})},m={render:()=>r.jsx(e,{variant:"button",children:"Button text"})},l={render:()=>r.jsx(e,{variant:"caption",children:"Caption"})},y={render:()=>r.jsx(e,{variant:"overline",children:"Text"})},h={render:()=>r.jsx(e,{mx:12,mt:4,border:1,children:"Text"}),decorators:[g=>r.jsx(v,{sx:{width:500},children:r.jsxs(x,{sx:{p:2},children:[r.jsxs(e,{children:["The Typography component"," ",r.jsx(b,{href:"https://mui.com/system/properties/#properties-reference-table",children:"supports"})," ","all system properties"]}),r.jsx(g,{})]})})]};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h1"}>Header</Typography>;
  }
}`,...t.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h2"}>Header</Typography>;
  }
}`,...a.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h3"}>Header</Typography>;
  }
}`,...n.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h4"}>Header</Typography>;
  }
}`,...o.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h5"}>Header</Typography>;
  }
}`,...s.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"h6"}>Header</Typography>;
  }
}`,...i.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"subtitle1"}>Subtitle</Typography>;
  }
}`,...p.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"subtitle2"}>Subtitle</Typography>;
  }
}`,...c.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"body1"}>
        Lorem ipsum, dolor sit amet consectetur adipisicing elit. Qui ducimus
        provident itaque doloribus necessitatibus inventore est porro officia,
        mollitia nisi laudantium rerum quod praesentium reiciendis eaque
        corrupti culpa sequi illum!
      </Typography>;
  }
}`,...d.parameters?.docs?.source}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"body2"}>
        Lorem ipsum dolor sit amet consectetur adipisicing elit. Amet nulla
        perspiciatis dolore cum dicta suscipit dolores molestias ea illum, odit
        iste a ab, nemo, ut error inventore! Animi, enim recusandae.
      </Typography>;
  }
}`,...u.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"button"}>Button text</Typography>;
  }
}`,...m.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"caption"}>Caption</Typography>;
  }
}`,...l.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography variant={"overline"}>Text</Typography>;
  }
}`,...y.parameters?.docs?.source}}};h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Typography mx={12} mt={4} border={1}>
        Text
      </Typography>;
  },
  decorators: [Story => {
    return <Box sx={{
      width: 500
    }}>
          <Paper sx={{
        p: 2
      }}>
            <Typography>
              The Typography component{" "}
              <Link href="https://mui.com/system/properties/#properties-reference-table">
                supports
              </Link>{" "}
              all system properties
            </Typography>
            <Story />
          </Paper>
        </Box>;
  }]
}`,...h.parameters?.docs?.source}}};const R=["Heading1","Heading2","Heading3","Heading4","Heading5","Heading6","Subtitle1","Subtitle2","Body1","Body2","Button","Caption","Overline","SystemProps"];export{d as Body1,u as Body2,m as Button,l as Caption,t as Heading1,a as Heading2,n as Heading3,o as Heading4,s as Heading5,i as Heading6,y as Overline,p as Subtitle1,c as Subtitle2,h as SystemProps,R as __namedExportsOrder,M as default};
