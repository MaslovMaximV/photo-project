import{j as r}from"./iframe-U1MoWpc_.js";import{S as o}from"./Stack-DsCsj_BD.js";import{P as n}from"./Paper-BtmMZDrw.js";import{D as x}from"./Divider-ldTtmydz.js";import{T as t}from"./Typography-NbeDhiLn.js";import{B as l}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./styled-DKEkqMyo.js";import"./extendSxProp-Cl0Joej-.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./useTheme-DUWNGOj_.js";import"./useTheme-CMyrA-7l.js";import"./memoTheme-BNYDzr43.js";import"./dividerClasses-BwqMPq15.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const b={title:"Layout/Stack",component:o,parameters:{layout:"centered",controls:{exclude:["divider"]}},decorators:[e=>r.jsx(n,{sx:{width:500,height:250,p:2},children:r.jsx(e,{})})],argTypes:{direction:{control:"select",options:["row","row-reverse","column","column-reverse"]},alignItems:{control:"select",options:["baseline","normal","stretch","center","flex-end","flex-start"]},justifyContent:{control:"select",options:["baseline","normal","stretch","center","flex-end","flex-start","space-around","space-between","space-evenly"]},spacing:{control:"select",options:[1,2,3,4,5,6,7,8]},useFlexGap:{control:"boolean"}},tags:["wrapper"],args:{direction:"column",spacing:2}},s={render:({...e})=>r.jsxs(o,{...e,alignItems:"center",children:[r.jsx(n,{sx:{p:2},children:"Item 1"}),r.jsx(n,{sx:{p:2},children:"Item 2"}),r.jsx(n,{sx:{p:2},children:"Item 3"})]}),args:{direction:"row"}},a={render:({...e})=>r.jsxs(o,{...e,children:[r.jsx(n,{sx:{p:2},children:"Item 1"}),r.jsx(n,{sx:{p:2},children:"Item 2"}),r.jsx(n,{sx:{p:2},children:"Item 3"})]}),args:{direction:"column"}},p={render:({...e})=>r.jsxs(o,{...e,children:[r.jsx(t,{children:"Item 1"}),r.jsx(t,{children:"Item 2"}),r.jsx(t,{children:"Item 3"})]}),args:{direction:"row",divider:r.jsx(x,{orientation:"vertical",flexItem:!0})}},i={render:({...e})=>r.jsxs(o,{...e,children:[r.jsx(t,{children:"Item 1"}),r.jsx(t,{children:"Item 2"}),r.jsx(t,{children:"Item 3"})]}),args:{direction:"column",divider:r.jsx(x,{orientation:"horizontal",flexItem:!0})}},c={render:({...e})=>r.jsxs(o,{...e,useFlexGap:!0,flexWrap:"wrap",children:[r.jsx(n,{sx:{p:2},children:"Item 1"}),r.jsx(n,{sx:{p:2},children:"Item 2"}),r.jsx(n,{sx:{p:2},children:"Loong content"})]}),args:{direction:"row"},decorators:[e=>r.jsx(l,{sx:{width:200},children:r.jsx(e,{})})]},d={render:({...e})=>r.jsxs(o,{...e,useFlexGap:!0,flexWrap:"wrap",children:[r.jsx(n,{sx:{p:2,flex:1},children:"Item 1"}),r.jsx(n,{sx:{p:2,flex:1},children:"Item 2"}),r.jsx(n,{sx:{p:2,flex:1},children:"Loong content"})]}),args:{direction:"row"},decorators:[e=>r.jsx(l,{sx:{width:200},children:r.jsx(e,{})})]},m={render:({...e})=>r.jsxs(o,{...e,children:[r.jsx(t,{noWrap:!0,children:"Item 1"}),r.jsx(t,{noWrap:!0,children:"Item 2"}),r.jsx(t,{noWrap:!0,children:"Loong content"})]}),args:{direction:"column"},decorators:[e=>r.jsx(l,{sx:{width:100},children:r.jsx(e,{})})]};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props} alignItems={"center"}>
        <Paper sx={{
        p: 2
      }}>Item 1</Paper>
        <Paper sx={{
        p: 2
      }}>Item 2</Paper>
        <Paper sx={{
        p: 2
      }}>Item 3</Paper>
      </Stack>;
  },
  args: {
    direction: "row"
  }
}`,...s.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props}>
        <Paper sx={{
        p: 2
      }}>Item 1</Paper>
        <Paper sx={{
        p: 2
      }}>Item 2</Paper>
        <Paper sx={{
        p: 2
      }}>Item 3</Paper>
      </Stack>;
  },
  args: {
    direction: "column"
  }
}`,...a.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props}>
        <Typography>Item 1</Typography>
        <Typography>Item 2</Typography>
        <Typography>Item 3</Typography>
      </Stack>;
  },
  args: {
    direction: "row",
    divider: <Divider orientation="vertical" flexItem />
  }
}`,...p.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props}>
        <Typography>Item 1</Typography>
        <Typography>Item 2</Typography>
        <Typography>Item 3</Typography>
      </Stack>;
  },
  args: {
    direction: "column",
    divider: <Divider orientation="horizontal" flexItem />
  }
}`,...i.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props} useFlexGap flexWrap="wrap">
        <Paper sx={{
        p: 2
      }}>Item 1</Paper>
        <Paper sx={{
        p: 2
      }}>Item 2</Paper>
        <Paper sx={{
        p: 2
      }}>Loong content</Paper>
      </Stack>;
  },
  args: {
    direction: "row"
  },
  decorators: [Story => {
    return <Box sx={{
      width: 200
    }}>
          <Story />
        </Box>;
  }]
}`,...c.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props} useFlexGap flexWrap="wrap">
        {/* flex: 1 is important for an item to fill all space in the stream */}
        <Paper sx={{
        p: 2,
        flex: 1
      }}>Item 1</Paper>
        <Paper sx={{
        p: 2,
        flex: 1
      }}>Item 2</Paper>
        <Paper sx={{
        p: 2,
        flex: 1
      }}>Loong content</Paper>
      </Stack>;
  },
  args: {
    direction: "row"
  },
  decorators: [Story => {
    return <Box sx={{
      width: 200
    }}>
          <Story />
        </Box>;
  }]
}`,...d.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack {...props}>
        <Typography noWrap>Item 1</Typography>
        <Typography noWrap>Item 2</Typography>
        <Typography noWrap>Loong content</Typography>
      </Stack>;
  },
  args: {
    direction: "column"
  },
  decorators: [Story => {
    return <Box sx={{
      width: 100
    }}>
          <Story />
        </Box>;
  }]
}`,...m.parameters?.docs?.source}}};const H=["Horizontal","Vertical","HorizontalDivided","VerticalDivided","Wrap","WrapFillWidth","Truncated"];export{s as Horizontal,p as HorizontalDivided,m as Truncated,a as Vertical,i as VerticalDivided,c as Wrap,d as WrapFillWidth,H as __namedExportsOrder,b as default};
