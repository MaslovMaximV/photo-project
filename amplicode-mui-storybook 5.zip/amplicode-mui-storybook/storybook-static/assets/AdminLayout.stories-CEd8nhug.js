import{j as e,r as g,a as j}from"./iframe-U1MoWpc_.js";import{B as s}from"./Box-nnrC_EdN.js";import{A as b,D as f}from"./Drawer-BfI29jr1.js";import{T as d}from"./Toolbar-CUdeLhnu.js";import{I as w}from"./IconButton-DY_fXBCG.js";import{M as v}from"./Menu-2grIudaM.js";import{D as y}from"./Divider-ldTtmydz.js";import{T as i}from"./Typography-NbeDhiLn.js";import{A as p,a as c,b as x}from"./AccordionSummary-CWABZDsO.js";import{A as h}from"./ArrowDropDown-ChzEnR_A.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./Paper-BtmMZDrw.js";import"./useTheme-CMyrA-7l.js";import"./index-BnGSTqEq.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./mergeSlotProps-BszqYXGC.js";import"./Slide-DVFtChZU.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./debounce-Be36O1Ab.js";import"./ownerWindow-HkKU3E4x.js";import"./ownerDocument-DW-IO8s5.js";import"./Modal-Cups6cDA.js";import"./FocusTrap-aa0DuC0e.js";import"./useEventCallback-ELgNMDCa.js";import"./createChainedFunction-BO_9K8Jh.js";import"./Portal-Dc2RZP_l.js";import"./Backdrop-DKjtt3hE.js";import"./Fade-P8xhlTFS.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./createSvgIcon-Ck9VyYEl.js";import"./dividerClasses-BwqMPq15.js";import"./index-CR3QZgfD.js";import"./useControlled-CeZ7-hqo.js";const fe={title:"Layout/Templates/AdminLayout",parameters:{layout:"fullscreen",controls:{exclude:["divider"]}},decorators:[l=>e.jsx(l,{})]},a={render:({...l})=>{const[r,m]=g.useState(!0),t=240,o=64,u=()=>{m(n=>!n)};return e.jsx(e.Fragment,{children:e.jsxs(s,{sx:{display:"flex"},children:[e.jsx(b,{position:"fixed",sx:n=>({width:r?`calc(100% - ${t}px)`:`calc(100% - ${o}px)`,ml:r?`${t}px`:`${o}px`,background:n.palette.background.default,boxShadow:"none",border:"none",borderBottom:`1px solid ${n.palette.divider}`,transition:"all 225ms"}),children:e.jsx(d,{children:e.jsx("img",{src:"vite.svg",alt:""})})}),e.jsxs(f,{sx:n=>({width:r?t:o,flexShrink:0,transition:"all 225ms",overflowX:"hidden","& .MuiDrawer-paper":{width:r?t:o,boxSizing:"border-box",transition:"all 225ms",background:n.palette.background.default}}),variant:"permanent",open:r,anchor:"left",children:[e.jsx(d,{children:e.jsx(w,{color:"primary",size:"medium",onClick:u,sx:n=>({position:"absolute",left:n.spacing(1.5)}),children:e.jsx(v,{})})}),e.jsx(y,{}),e.jsx(s,{sx:n=>({my:n.spacing(2.5),overflowX:"hidden"})})]}),e.jsxs(s,{component:"main",sx:{width:r?`calc(100% - ${t}px)`:`calc(100% - ${o}px)`,flexGrow:1,bgcolor:"#fff",p:2,boxSizing:"border-box",minHeight:"100vh"},children:[e.jsx(d,{}),j(e.jsx(D,{}))]})]})})}},D=()=>e.jsxs(s,{sx:l=>({px:2}),children:[e.jsx(i,{variant:"h6",children:"Admin layout"}),e.jsx(i,{variant:"body2",children:"This type of layout is widely used for admin panels, control panels, and other web applications. Its structure allows for easy navigation and provides a clean, organized workspace. The layout consists of the following key elements:"}),e.jsxs(s,{mt:2,children:[e.jsxs(p,{children:[e.jsx(c,{expandIcon:e.jsx(h,{}),children:e.jsx(i,{variant:"subtitle2",children:"Floating Sidebar (Navigation)"})}),e.jsx(x,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Fixed on the left side of the window."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Always visible, regardless of scrolling."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Contains navigation links, icons, or a menu for switching between sections."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Typically has a fixed width (e.g., 250px)."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Can be collapsible for smaller screens or when more content space is needed."})})]})]})]})})]}),e.jsxs(p,{children:[e.jsx(c,{expandIcon:e.jsx(h,{}),children:e.jsx(i,{variant:"subtitle2",children:"Floating Header (Top Bar)"})}),e.jsx(x,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Fixed at the top of the window, spanning the full width of the page."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Contains branding, a search bar, user profile, notifications, or other key actions."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Remains visible during scrolling for quick access."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Height is usually small (e.g., 60px), with position: fixed;."})})]})]})]})})]}),e.jsxs(p,{children:[e.jsx(c,{expandIcon:e.jsx(h,{}),children:e.jsx(i,{variant:"subtitle2",children:"Main Content Area"})}),e.jsx(x,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"To the right of the sidebar, below the header."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Occupies the remaining screen space after accounting for the sidebar and header."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Scrollable if the content overflows."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Typically has padding to ensure readability and spacing."})})]})]})]})})]})]})]});a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    const [open, setOpen] = useState<undefined | false | true>(true);
    const openedDrawerWidth = 240;
    const closedDrawerWidth = 64;
    const toggleOpenDrawer = () => {
      setOpen(prevState => !prevState);
    };
    return <>
        <Box sx={{
        display: "flex"
      }}>
          <AppBar position="fixed" sx={theme => ({
          width: open ? \`calc(100% - \${openedDrawerWidth}px)\` : \`calc(100% - \${closedDrawerWidth}px)\`,
          ml: open ? \`\${openedDrawerWidth}px\` : \`\${closedDrawerWidth}px\`,
          background: theme.palette.background.default,
          boxShadow: "none",
          border: "none",
          borderBottom: \`1px solid \${theme.palette.divider}\`,
          transition: "all 225ms"
        })}>
            <Toolbar>
              <img src="vite.svg" alt="" />
            </Toolbar>
          </AppBar>
          <Drawer sx={theme => ({
          width: open ? openedDrawerWidth : closedDrawerWidth,
          flexShrink: 0,
          transition: "all 225ms",
          overflowX: "hidden",
          "& .MuiDrawer-paper": {
            width: open ? openedDrawerWidth : closedDrawerWidth,
            boxSizing: "border-box",
            transition: "all 225ms",
            background: theme.palette.background.default
          }
        })} variant={"permanent"} open={open} anchor="left">
            <Toolbar>
              <IconButton color="primary" size="medium" onClick={toggleOpenDrawer} sx={theme => ({
              position: "absolute",
              left: theme.spacing(1.5)
            })}>
                <Menu />
              </IconButton>
            </Toolbar>
            <Divider />
            <Box sx={theme => ({
            my: theme.spacing(2.5),
            overflowX: "hidden"
          })}></Box>
          </Drawer>
          <Box component="main" sx={{
          width: open ? \`calc(100% - \${openedDrawerWidth}px)\` : \`calc(100% - \${closedDrawerWidth}px)\`,
          flexGrow: 1,
          bgcolor: "#fff",
          p: 2,
          boxSizing: "border-box",
          minHeight: "100vh"
        }}>
            <Toolbar />
            {replaceOnGenerate(<JustLayoutStoryDescription />, <div>Content</div>)}
          </Box>
        </Box>
      </>;
  }
}`,...a.parameters?.docs?.source}}};const we=["Default"];export{a as Default,we as __namedExportsOrder,fe as default};
