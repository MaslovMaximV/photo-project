import{j as n}from"./iframe-U1MoWpc_.js";import{P as t}from"./Paper-BtmMZDrw.js";import{B as s}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useTheme-DUWNGOj_.js";import"./memoTheme-BNYDzr43.js";import"./extendSxProp-Cl0Joej-.js";const i=r=>n.jsx(s,{sx:{width:200,height:200},children:n.jsx(r,{})}),b={title:"Surfaces/Paper",component:t,parameters:{layout:"centered",controls:{exclude:["onClick"]}},decorators:[i],argTypes:{elevation:{control:"select",options:[1,2,3,4,5,6,7,8]},variant:{control:"select",options:["elevation","outlined"]}},args:{},tags:["wrapper"]},e={render:({elevation:r,...a})=>n.jsx(t,{sx:{width:"100%",height:"100%",p:1,boxSizing:"border-box"},elevation:r}),args:{elevation:1}},o={render:({elevation:r,...a})=>n.jsx(t,{sx:{width:"100%",height:"100%",p:1,boxSizing:"border-box"},variant:"outlined"}),args:{}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: ({
    elevation,
    ...props
  }) => {
    return <Paper sx={{
      width: "100%",
      height: "100%",
      p: 1,
      boxSizing: "border-box"
    }} elevation={elevation}></Paper>;
  },
  args: {
    elevation: 1
  }
}`,...e.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    elevation,
    ...props
  }) => {
    return <Paper sx={{
      width: "100%",
      height: "100%",
      p: 1,
      boxSizing: "border-box"
    }} variant="outlined"></Paper>;
  },
  args: {}
}`,...o.parameters?.docs?.source}}};const w=["Elevation","Outlined"];export{e as Elevation,o as Outlined,w as __namedExportsOrder,b as default};
