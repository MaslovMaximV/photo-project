import{r as c,j as o}from"./iframe-U1MoWpc_.js";import{a as T,F as q}from"./FavoriteBorder-DiR9fGnD.js";import{a as S,g as L,c as V}from"./createTheme-CB0G2ADO.js";import{a as D,R as m}from"./Radio-BaYSeLyF.js";import{u as M}from"./useControlled-CeZ7-hqo.js";import{u as U}from"./useForkRef-OOgs0334.js";import{u as O}from"./useId-vd1Ifx8D.js";import{u as P}from"./useFormControl-q410XUqr.js";import{f as A}from"./formControlState-Dq1zat_P.js";import{u as H,s as W,a as I}from"./DefaultPropsProvider-Drazl94h.js";import{F as x,a as g}from"./FormLabel-gyC02a8P.js";import{F as f}from"./FormControlLabel-Bq-a8dVL.js";import{F as z}from"./FormHelperText-DApA1kKb.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./memoTheme-BNYDzr43.js";import"./SwitchBase-9AkWq_7-.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./createChainedFunction-BO_9K8Jh.js";import"./utils-DoM3o7-Q.js";import"./isMuiElement-BH3XSIgM.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";function N(e){return S("MuiFormGroup",e)}L("MuiFormGroup",["root","row","error"]);const _=e=>{const{classes:r,row:a,error:s}=e;return I({root:["root",a&&"row",s&&"error"]},N,r)},$=W("div",{name:"MuiFormGroup",slot:"Root",overridesResolver:(e,r)=>{const{ownerState:a}=e;return[r.root,a.row&&r.row]}})({display:"flex",flexDirection:"column",flexWrap:"wrap",variants:[{props:{row:!0},style:{flexDirection:"row"}}]}),J=c.forwardRef(function(r,a){const s=H({props:r,name:"MuiFormGroup"}),{className:n,row:t=!1,...d}=s,p=P(),u=A({props:s,muiFormControl:p,states:["error"]}),l={...s,row:t,error:u.error},w=_(l);return o.jsx($,{className:V(w.root,n),ownerState:l,ref:a,...d})});function K(e){return S("MuiRadioGroup",e)}L("MuiRadioGroup",["root","row","error"]);const Q=e=>{const{classes:r,row:a,error:s}=e;return I({root:["root",a&&"row",s&&"error"]},K,r)},h=c.forwardRef(function(r,a){const{actions:s,children:n,className:t,defaultValue:d,name:p,onChange:u,value:l,...w}=r,R=c.useRef(null),k=Q(r),[y,j]=M({controlled:l,default:d,name:"RadioGroup"});c.useImperativeHandle(s,()=>({focus:()=>{let i=R.current.querySelector("input:not(:disabled):checked");i||(i=R.current.querySelector("input:not(:disabled)")),i&&i.focus()}}),[]);const B=U(a,R),G=O(p),E=c.useMemo(()=>({name:G,onChange(i){j(i.target.value),u&&u(i,i.target.value)},value:y}),[G,u,j,y]);return o.jsx(D.Provider,{value:E,children:o.jsx(J,{role:"radiogroup",ref:B,className:V(k.root,t),...w,children:n})})}),Io={title:"Inputs/RadioGroup",component:h,tags:["autodocs"],parameters:{layout:"centered",docs:{description:{component:"A group of radio buttons that allows the user to select one option from a list."}}},args:{label:"Choose one option",row:!1,value:"Option 1",options:["Option 1","Option 2","Option 3"]},argTypes:{row:{control:"boolean",description:"Display radio buttons horizontally (row=true) or vertically (row=false)"},disabled:{control:"boolean",description:"Disables the entire radio group"},direction:{name:"Direction",control:"select",options:["row","column"],mapping:{row:!0,column:!1},description:"The layout direction of the radio group"},size:{name:"Size",control:"select",options:["small","medium"],description:"The size of the radio buttons"},color:{name:"Color",control:"select",options:["primary","secondary","error","default"],description:"Color of the radio buttons"},labelPlacement:{name:"Label placement",control:"select",options:["end","start","top","bottom"],description:"Position of the label relative to the radio"}}},v={render:({label:e,value:r,options:a=[],row:s,disabled:n})=>o.jsxs(x,{disabled:n,children:[o.jsx(g,{children:e}),o.jsx(h,{row:s,defaultValue:r,children:a.map(t=>o.jsx(f,{value:t,control:o.jsx(m,{}),label:t},t))})]}),parameters:{docs:{description:{story:"A basic radio group with several options."}}}},b={render:({label:e,options:r=[],row:a})=>{const[s,n]=c.useState("Option 1");return o.jsxs(x,{children:[o.jsx(g,{children:e}),o.jsx(h,{row:a,value:s,onChange:t=>n(t.target.value),children:r.map(t=>o.jsx(f,{value:t,control:o.jsx(m,{}),label:t},t))})]})},parameters:{docs:{description:{story:"A controlled version of the component with local state."}}}},F={render:()=>o.jsxs(x,{children:[o.jsx(g,{children:"Favorite color"}),o.jsxs(h,{defaultValue:"love",children:[o.jsx(f,{value:"love",control:o.jsx(m,{icon:o.jsx(q,{}),checkedIcon:o.jsx(T,{}),color:"secondary"}),label:"I love it"}),o.jsx(f,{value:"meh",control:o.jsx(m,{}),label:"It's okay"})]})]}),parameters:{docs:{description:{story:"Uses custom icons (filled and outlined hearts) to represent a radio option."}}}},C={render:({options:e=[],row:r,label:a})=>{const[s,n]=c.useState(""),[t,d]=c.useState(!1),p=l=>{n(l.target.value),d(!1)},u=()=>{n(""),d(!0)};return o.jsxs(x,{error:t,required:!0,children:[o.jsx(g,{children:a}),o.jsx(h,{row:r,value:s,onChange:p,onBlur:u,children:e.map(l=>o.jsx(f,{value:l,control:o.jsx(m,{}),label:l},l))}),t&&o.jsx(z,{children:"This field is required."})]})},parameters:{docs:{description:{story:"Demonstrates basic required field validation for a radio group."}}}};v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: ({
    label,
    value,
    options = [],
    row,
    disabled
  }) => <FormControl disabled={disabled}>
      <FormLabel>{label}</FormLabel>
      <RadioGroup row={row} defaultValue={value}>
        {options.map(opt => <FormControlLabel key={opt} value={opt} control={<Radio />} label={opt} />)}
      </RadioGroup>
    </FormControl>,
  parameters: {
    docs: {
      description: {
        story: "A basic radio group with several options."
      }
    }
  }
}`,...v.parameters?.docs?.source}}};b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: ({
    label,
    options = [],
    row
  }) => {
    const [selected, setSelected] = useState("Option 1");
    return <FormControl>
        <FormLabel>{label}</FormLabel>
        <RadioGroup row={row} value={selected} onChange={e => setSelected(e.target.value)}>
          {options.map(opt => <FormControlLabel key={opt} value={opt} control={<Radio />} label={opt} />)}
        </RadioGroup>
      </FormControl>;
  },
  parameters: {
    docs: {
      description: {
        story: "A controlled version of the component with local state."
      }
    }
  }
}`,...b.parameters?.docs?.source}}};F.parameters={...F.parameters,docs:{...F.parameters?.docs,source:{originalSource:`{
  render: () => <FormControl>
      <FormLabel>Favorite color</FormLabel>
      <RadioGroup defaultValue="love">
        <FormControlLabel value="love" control={<Radio icon={<FavoriteBorder />} checkedIcon={<Favorite />} color="secondary" />} label="I love it" />
        <FormControlLabel value="meh" control={<Radio />} label="It's okay" />
      </RadioGroup>
    </FormControl>,
  parameters: {
    docs: {
      description: {
        story: "Uses custom icons (filled and outlined hearts) to represent a radio option."
      }
    }
  }
}`,...F.parameters?.docs?.source}}};C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  render: ({
    options = [],
    row,
    label
  }) => {
    const [value, setValue] = useState("");
    const [error, setError] = useState(false);
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      setValue(event.target.value);
      setError(false);
    };
    const handleBlur = () => {
      setValue("");
      setError(true);
    };
    return <FormControl error={error} required>
        <FormLabel>{label}</FormLabel>
        <RadioGroup row={row} value={value} onChange={handleChange} onBlur={handleBlur}>
          {options.map(opt => <FormControlLabel key={opt} value={opt} control={<Radio />} label={opt} />)}
        </RadioGroup>
        {error && <FormHelperText>This field is required.</FormHelperText>}
      </FormControl>;
  },
  parameters: {
    docs: {
      description: {
        story: "Demonstrates basic required field validation for a radio group."
      }
    }
  }
}`,...C.parameters?.docs?.source}}};const ko=["Basic","Controlled","WithCustomIcons","WithValidation"];export{v as Basic,b as Controlled,F as WithCustomIcons,C as WithValidation,ko as __namedExportsOrder,Io as default};
