import{j as o}from"./iframe-U1MoWpc_.js";import{c as t}from"./createSvgIcon-Ck9VyYEl.js";const s=t(o.jsx("path",{d:"M3 18h18v-2H3zm0-5h18v-2H3zm0-7v2h18V6z"}));export{s as M};
