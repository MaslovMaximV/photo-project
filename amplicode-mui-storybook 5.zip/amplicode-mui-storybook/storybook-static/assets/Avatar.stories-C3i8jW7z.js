import{r as v,j as r}from"./iframe-U1MoWpc_.js";import{A as s,a as U}from"./Avatar-Ck2hUvP7.js";import{u as L,s as $,a as V}from"./DefaultPropsProvider-Drazl94h.js";import{B as _}from"./Badge-CBsmv7US.js";import{g as q,a as I,c as O}from"./createTheme-CB0G2ADO.js";import{m as K}from"./memoTheme-BNYDzr43.js";import{u as Q}from"./useSlot-ntrDZa7C.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./usePreviousProps-Bv8dyoI3.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";function X(a){return I("MuiAvatarGroup",a)}const Y=q("MuiAvatarGroup",["root","avatar"]),T={small:-16,medium:-8},Z=a=>{const{classes:e}=a;return V({root:["root"],avatar:["avatar"]},X,e)},rr=$("div",{name:"MuiAvatarGroup",slot:"Root",overridesResolver:(a,e)=>[{[`& .${Y.avatar}`]:e.avatar},e.root]})(K(({theme:a})=>({display:"flex",flexDirection:"row-reverse",[`& .${U.root}`]:{border:`2px solid ${(a.vars||a).palette.background.default}`,boxSizing:"content-box",marginLeft:"var(--AvatarGroup-spacing, -8px)","&:last-child":{marginLeft:0}}}))),P=v.forwardRef(function(e,n){const p=L({props:e,name:"MuiAvatarGroup"}),{children:c,className:t,component:l="div",componentsProps:g,max:w=5,renderSurplus:B,slotProps:R={},slots:D={},spacing:W="medium",total:E,variant:j="circular",...H}=p;let i=w<2?2:w;const o={...p,max:w,spacing:W,component:l,variant:j},C=Z(o),k=v.Children.toArray(c).filter(m=>v.isValidElement(m)),d=E||k.length;d===i&&(i+=1),i=Math.min(d+1,i);const M=Math.min(k.length,i-1),G=Math.max(d-i,d-M,0),N=B?B(G):`+${G}`;let u;o.spacing&&T[o.spacing]!==void 0?u=T[o.spacing]:o.spacing===0?u=0:u=-o.spacing||T.medium;const z={slots:D,slotProps:{surplus:R.additionalAvatar??g?.additionalAvatar,...g,...R}},[F,J]=Q("surplus",{elementType:s,externalForwardedProps:z,className:C.avatar,ownerState:o,additionalProps:{variant:j}});return r.jsxs(rr,{as:l,ownerState:o,className:O(C.root,t),ref:n,...H,style:{"--AvatarGroup-spacing":`${u}px`,...H.style},children:[G?r.jsx(F,{...J,children:N}):null,k.slice(0,M).reverse().map(m=>v.cloneElement(m,{className:O(m.props.className,C.avatar),variant:m.props.variant||j}))]})}),ur={title:"DataDisplay/Avatar",component:s,parameters:{layout:"centered"},decorators:[],argTypes:{src:{control:"text"},alt:{control:"text"},variant:{control:"select",options:["circular","rounded","square"]}},args:{variant:"rounded",sx:{width:60,height:60}}},h={render:a=>r.jsx(s,{sx:{width:60,height:60},...a}),args:{src:"/images/mascot-1.png"}},x={render:a=>r.jsx(s,{...a,sx:{width:60,height:60},children:"John Doe"[0]}),args:{src:"/images/mascot-1.pneg"},parameters:{controls:{exclude:["sx"]}}},A={render:a=>{const e="John Doe",n=p=>{let c=0,t;for(t=0;t<p.length;t+=1)c=p.charCodeAt(t)+((c<<5)-c);let l="#";for(t=0;t<3;t+=1){const g=c>>t*8&255;l+=`00${g.toString(16)}`.slice(-2)}return l};return r.jsx(s,{...a,sx:{bgcolor:n(e),width:60,height:60},children:e[0]})},args:{src:"/images/mascot-1.pneg"},parameters:{controls:{exclude:["sx"]}}},f={render:a=>{const e=$(_)(({theme:n})=>({"& .MuiBadge-badge":{backgroundColor:"#44b700",color:"#44b700",boxShadow:`0 0 0 2px ${n.palette.background.paper}`,"&::after":{position:"absolute",top:0,left:0,bottom:0,right:0,margin:"auto",width:"100%",height:"100%",borderRadius:"50%",animation:"ripple 1.2s infinite ease-in-out",border:"1px solid currentColor",boxSizing:"border-box",content:'""'}},"@keyframes ripple":{"0%":{transform:"scale(.8)",opacity:1},"100%":{transform:"scale(2.4)",opacity:0}}}));return r.jsx(e,{overlap:"circular",anchorOrigin:{vertical:"bottom",horizontal:"right"},variant:"dot",children:r.jsx(s,{alt:"Remy Sharp",src:"/images/mascot-1.png",...a})})}},S={render:a=>r.jsxs(P,{max:4,children:[r.jsx(s,{alt:"Remy Sharp",src:"/images/mascot-1.png"}),r.jsx(s,{alt:"Travis Howard",src:"/images/mascot-2.png"}),r.jsx(s,{alt:"Cindy Baker",src:"/images/mascot-3.png"}),r.jsx(s,{alt:"Agnes Walker",src:"/images/mascot-4.png"}),r.jsx(s,{alt:"Trevor Henderson",src:"/images/mascot-5.png"})]})},b={render:a=>r.jsxs(P,{total:24,children:[r.jsx(s,{alt:"Remy Sharp",src:"/images/mascot-1.png"}),r.jsx(s,{alt:"Travis Howard",src:"/images/mascot-2.png"}),r.jsx(s,{alt:"Agnes Walker",src:"/images/mascot-3.png"}),r.jsx(s,{alt:"Trevor Henderson",src:"/images/mascot-4.png"})]})},y={render:a=>r.jsxs(P,{renderSurplus:e=>r.jsxs("span",{children:["+",e.toString()[0],"k"]}),total:4251,children:[r.jsx(s,{alt:"Remy Sharp",src:"/images/mascot-1.png"}),r.jsx(s,{alt:"Travis Howard",src:"/images/mascot-2.png"}),r.jsx(s,{alt:"Agnes Walker",src:"/images/mascot-3.png"}),r.jsx(s,{alt:"Trevor Henderson",src:"/images/mascot-4.png"})]})};h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    return <Avatar sx={{
      width: 60,
      height: 60
    }} {...props}></Avatar>;
  },
  args: {
    src: "/images/mascot-1.png"
  }
}`,...h.parameters?.docs?.source}}};x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    const name = "John Doe";
    return <Avatar {...props} sx={{
      width: 60,
      height: 60
    }}>
        {name[0]}
      </Avatar>;
  },
  args: {
    src: "/images/mascot-1.pneg"
  },
  parameters: {
    controls: {
      exclude: ["sx"]
    }
  }
}`,...x.parameters?.docs?.source}}};A.parameters={...A.parameters,docs:{...A.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    const name = "John Doe";
    const stringToColor = (string: string) => {
      let hash = 0;
      let i;
      for (i = 0; i < string.length; i += 1) {
        hash = string.charCodeAt(i) + ((hash << 5) - hash);
      }
      let color = "#";
      for (i = 0; i < 3; i += 1) {
        const value = hash >> i * 8 & 0xff;
        color += \`00\${value.toString(16)}\`.slice(-2);
      }
      return color;
    };
    return <Avatar {...props} sx={{
      bgcolor: stringToColor(name),
      width: 60,
      height: 60
    }}>
        {name[0]}
      </Avatar>;
  },
  args: {
    src: "/images/mascot-1.pneg"
  },
  parameters: {
    controls: {
      exclude: ["sx"]
    }
  }
}`,...A.parameters?.docs?.source}}};f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    const StyledBadge = styled(Badge)(({
      theme
    }) => ({
      "& .MuiBadge-badge": {
        backgroundColor: "#44b700",
        color: "#44b700",
        boxShadow: \`0 0 0 2px \${theme.palette.background.paper}\`,
        "&::after": {
          position: "absolute",
          top: 0,
          left: 0,
          bottom: 0,
          right: 0,
          margin: "auto",
          width: "100%",
          height: "100%",
          borderRadius: "50%",
          animation: "ripple 1.2s infinite ease-in-out",
          border: "1px solid currentColor",
          boxSizing: "border-box",
          content: '""'
        }
      },
      "@keyframes ripple": {
        "0%": {
          transform: "scale(.8)",
          opacity: 1
        },
        "100%": {
          transform: "scale(2.4)",
          opacity: 0
        }
      }
    }));
    return <StyledBadge overlap="circular" anchorOrigin={{
      vertical: "bottom",
      horizontal: "right"
    }} variant="dot">
        <Avatar alt="Remy Sharp" src="/images/mascot-1.png" {...props} />
      </StyledBadge>;
  }
}`,...f.parameters?.docs?.source}}};S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    return <AvatarGroup max={4}>
        <Avatar alt="Remy Sharp" src="/images/mascot-1.png" />
        <Avatar alt="Travis Howard" src="/images/mascot-2.png" />
        <Avatar alt="Cindy Baker" src="/images/mascot-3.png" />
        <Avatar alt="Agnes Walker" src="/images/mascot-4.png" />
        <Avatar alt="Trevor Henderson" src="/images/mascot-5.png" />
      </AvatarGroup>;
  }
}`,...S.parameters?.docs?.source}}};b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    return <AvatarGroup total={24}>
        <Avatar alt="Remy Sharp" src="/images/mascot-1.png" />
        <Avatar alt="Travis Howard" src="/images/mascot-2.png" />
        <Avatar alt="Agnes Walker" src="/images/mascot-3.png" />
        <Avatar alt="Trevor Henderson" src="/images/mascot-4.png" />
      </AvatarGroup>;
  }
}`,...b.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: (props: AvatarOwnProps) => {
    return <AvatarGroup renderSurplus={surplus => <span>+{surplus.toString()[0]}k</span>} total={4251}>
        <Avatar alt="Remy Sharp" src="/images/mascot-1.png" />
        <Avatar alt="Travis Howard" src="/images/mascot-2.png" />
        <Avatar alt="Agnes Walker" src="/images/mascot-3.png" />
        <Avatar alt="Trevor Henderson" src="/images/mascot-4.png" />
      </AvatarGroup>;
  }
}`,...y.parameters?.docs?.source}}};const vr=["Basic","Fallback","ColoredFallback","WithBadge","Group","Total","CustomSurplus"];export{h as Basic,A as ColoredFallback,y as CustomSurplus,x as Fallback,S as Group,b as Total,f as WithBadge,vr as __namedExportsOrder,ur as default};
