import{r as u,j as n,e as g}from"./iframe-U1MoWpc_.js";import{a as I,g as T,c as M,b as Z}from"./createTheme-CB0G2ADO.js";import{u as z,s as b,a as $}from"./DefaultPropsProvider-Drazl94h.js";import{m as U}from"./memoTheme-BNYDzr43.js";import{B as f}from"./Box-nnrC_EdN.js";import{u as _}from"./useSlot-ntrDZa7C.js";import{c as ee,S as ae}from"./createSvgIcon-Ck9VyYEl.js";import{T as w}from"./Typography-NbeDhiLn.js";import{B}from"./Button-Z4BDc59h.js";import{i as ie}from"./isMuiElement-BH3XSIgM.js";import{B as le}from"./ButtonBase-BUPfvClL.js";import"./preload-helper-D9Z9MdNV.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./CircularProgress-Bb4IBCi9.js";import"./useTimeout-CYujZKVu.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";const O=u.createContext({}),V=u.createContext({});function pe(e){return I("MuiStep",e)}T("MuiStep",["root","horizontal","vertical","alternativeLabel","completed"]);const ce=e=>{const{classes:o,orientation:t,alternativeLabel:s,completed:r}=e;return $({root:["root",t,s&&"alternativeLabel",r&&"completed"]},pe,o)},de=b("div",{name:"MuiStep",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[o.root,o[t.orientation],t.alternativeLabel&&o.alternativeLabel,t.completed&&o.completed]}})({variants:[{props:{orientation:"horizontal"},style:{paddingLeft:8,paddingRight:8}},{props:{alternativeLabel:!0},style:{flex:1,position:"relative"}}]}),te=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStep"}),{active:r,children:i,className:c,component:l="div",completed:S,disabled:m,expanded:d=!1,index:p,last:a,...x}=s,{activeStep:v,connector:h,alternativeLabel:C,orientation:N,nonLinear:k}=u.useContext(O);let[y=!1,A=!1,R=!1]=[r,S,m];v===p?y=r!==void 0?r:!0:!k&&v>p?A=S!==void 0?S:!0:!k&&v<p&&(R=m!==void 0?m:!0);const D=u.useMemo(()=>({index:p,last:a,expanded:d,icon:p+1,active:y,completed:A,disabled:R}),[p,a,d,y,A,R]),L={...s,active:y,orientation:N,alternativeLabel:C,completed:A,disabled:R,expanded:d,component:l},P=ce(L),F=n.jsxs(de,{as:l,className:M(P.root,c),ref:t,ownerState:L,...x,children:[h&&C&&p!==0?h:null,i]});return n.jsx(V.Provider,{value:D,children:h&&!C&&p!==0?n.jsxs(u.Fragment,{children:[h,F]}):F})}),Se=ee(n.jsx("path",{d:"M12 0a12 12 0 1 0 0 24 12 12 0 0 0 0-24zm-2 17l-5-5 1.4-1.4 3.6 3.6 7.6-7.6L19 8l-9 9z"})),me=ee(n.jsx("path",{d:"M1 21h22L12 2 1 21zm12-3h-2v-2h2v2zm0-4h-2v-4h2v4z"}));function ue(e){return I("MuiStepIcon",e)}const H=T("MuiStepIcon",["root","active","completed","error","text"]);var Q;const xe=e=>{const{classes:o,active:t,completed:s,error:r}=e;return $({root:["root",t&&"active",s&&"completed",r&&"error"],text:["text"]},ue,o)},Y=b(ae,{name:"MuiStepIcon",slot:"Root"})(U(({theme:e})=>({display:"block",transition:e.transitions.create("color",{duration:e.transitions.duration.shortest}),color:(e.vars||e).palette.text.disabled,[`&.${H.completed}`]:{color:(e.vars||e).palette.primary.main},[`&.${H.active}`]:{color:(e.vars||e).palette.primary.main},[`&.${H.error}`]:{color:(e.vars||e).palette.error.main}}))),ve=b("text",{name:"MuiStepIcon",slot:"Text"})(U(({theme:e})=>({fill:(e.vars||e).palette.primary.contrastText,fontSize:e.typography.caption.fontSize,fontFamily:e.typography.fontFamily}))),he=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStepIcon"}),{active:r=!1,className:i,completed:c=!1,error:l=!1,icon:S,...m}=s,d={...s,active:r,completed:c,error:l},p=xe(d);if(typeof S=="number"||typeof S=="string"){const a=M(i,p.root);return l?n.jsx(Y,{as:me,className:a,ref:t,ownerState:d,...m}):c?n.jsx(Y,{as:Se,className:a,ref:t,ownerState:d,...m}):n.jsxs(Y,{className:a,ref:t,ownerState:d,...m,children:[Q||(Q=n.jsx("circle",{cx:"12",cy:"12",r:"12"})),n.jsx(ve,{className:p.text,x:"12",y:"12",textAnchor:"middle",dominantBaseline:"central",ownerState:d,children:S})]})}return S});function fe(e){return I("MuiStepLabel",e)}const j=T("MuiStepLabel",["root","horizontal","vertical","label","active","completed","error","disabled","iconContainer","alternativeLabel","labelContainer"]),be=e=>{const{classes:o,orientation:t,active:s,completed:r,error:i,disabled:c,alternativeLabel:l}=e;return $({root:["root",t,i&&"error",c&&"disabled",l&&"alternativeLabel"],label:["label",s&&"active",r&&"completed",i&&"error",c&&"disabled",l&&"alternativeLabel"],iconContainer:["iconContainer",s&&"active",r&&"completed",i&&"error",c&&"disabled",l&&"alternativeLabel"],labelContainer:["labelContainer",l&&"alternativeLabel"]},fe,o)},ye=b("span",{name:"MuiStepLabel",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[o.root,o[t.orientation]]}})({display:"flex",alignItems:"center",[`&.${j.alternativeLabel}`]:{flexDirection:"column"},[`&.${j.disabled}`]:{cursor:"default"},variants:[{props:{orientation:"vertical"},style:{textAlign:"left",padding:"8px 0"}}]}),ge=b("span",{name:"MuiStepLabel",slot:"Label"})(U(({theme:e})=>({...e.typography.body2,display:"block",transition:e.transitions.create("color",{duration:e.transitions.duration.shortest}),[`&.${j.active}`]:{color:(e.vars||e).palette.text.primary,fontWeight:500},[`&.${j.completed}`]:{color:(e.vars||e).palette.text.primary,fontWeight:500},[`&.${j.alternativeLabel}`]:{marginTop:16},[`&.${j.error}`]:{color:(e.vars||e).palette.error.main}}))),Ce=b("span",{name:"MuiStepLabel",slot:"IconContainer"})({flexShrink:0,display:"flex",paddingRight:8,[`&.${j.alternativeLabel}`]:{paddingRight:0}}),Le=b("span",{name:"MuiStepLabel",slot:"LabelContainer"})(U(({theme:e})=>({width:"100%",color:(e.vars||e).palette.text.secondary,[`&.${j.alternativeLabel}`]:{textAlign:"center"}}))),q=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStepLabel"}),{children:r,className:i,componentsProps:c={},error:l=!1,icon:S,optional:m,slots:d={},slotProps:p={},StepIconComponent:a,StepIconProps:x,...v}=s,{alternativeLabel:h,orientation:C}=u.useContext(O),{active:N,disabled:k,completed:y,icon:A}=u.useContext(V),R=S||A;let D=a;R&&!D&&(D=he);const L={...s,active:N,alternativeLabel:h,completed:y,disabled:k,error:l,orientation:C},P=be(L),F={slots:d,slotProps:{stepIcon:x,...c,...p}},[ne,oe]=_("root",{elementType:ye,externalForwardedProps:{...F,...v},ownerState:L,ref:t,className:M(P.root,i)}),[se,J]=_("label",{elementType:ge,externalForwardedProps:F,ownerState:L}),[K,re]=_("stepIcon",{elementType:D,externalForwardedProps:F,ownerState:L});return n.jsxs(ne,{...oe,children:[R||K?n.jsx(Ce,{className:P.iconContainer,ownerState:L,children:n.jsx(K,{completed:y,active:N,error:l,icon:R,...re})}):null,n.jsxs(Le,{className:P.labelContainer,ownerState:L,children:[r?n.jsx(se,{...J,className:M(P.label,J?.className),children:r}):null,m]})]})});q.muiName="StepLabel";function Re(e){return I("MuiStepButton",e)}const X=T("MuiStepButton",["root","horizontal","vertical","touchRipple"]),je=e=>{const{classes:o,orientation:t}=e;return $({root:["root",t],touchRipple:["touchRipple"]},Re,o)},ke=b(le,{name:"MuiStepButton",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[{[`& .${X.touchRipple}`]:o.touchRipple},o.root,o[t.orientation]]}})({width:"100%",padding:"24px 16px",margin:"-24px -16px",boxSizing:"content-box",[`& .${X.touchRipple}`]:{color:"rgba(0, 0, 0, 0.3)"},variants:[{props:{orientation:"vertical"},style:{justifyContent:"flex-start",padding:"8px",margin:"-8px"}}]}),we=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStepButton"}),{children:r,className:i,icon:c,optional:l,...S}=s,{disabled:m,active:d}=u.useContext(V),{orientation:p}=u.useContext(O),a={...s,orientation:p},x=je(a),v={icon:c,optional:l},h=ie(r,["StepLabel"])?u.cloneElement(r,v):n.jsx(q,{...v,children:r});return n.jsx(ke,{focusRipple:!0,disabled:m,TouchRippleProps:{className:x.touchRipple},className:M(x.root,i),ref:t,ownerState:a,"aria-current":d?"step":void 0,...S,children:h})});function Be(e){return I("MuiStepConnector",e)}T("MuiStepConnector",["root","horizontal","vertical","alternativeLabel","active","completed","disabled","line","lineHorizontal","lineVertical"]);const Me=e=>{const{classes:o,orientation:t,alternativeLabel:s,active:r,completed:i,disabled:c}=e,l={root:["root",t,s&&"alternativeLabel",r&&"active",i&&"completed",c&&"disabled"],line:["line",`line${Z(t)}`]};return $(l,Be,o)},Ne=b("div",{name:"MuiStepConnector",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[o.root,o[t.orientation],t.alternativeLabel&&o.alternativeLabel,t.completed&&o.completed]}})({flex:"1 1 auto",variants:[{props:{orientation:"vertical"},style:{marginLeft:12}},{props:{alternativeLabel:!0},style:{position:"absolute",top:12,left:"calc(-50% + 20px)",right:"calc(50% + 20px)"}}]}),Ae=b("span",{name:"MuiStepConnector",slot:"Line",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[o.line,o[`line${Z(t.orientation)}`]]}})(U(({theme:e})=>{const o=e.palette.mode==="light"?e.palette.grey[400]:e.palette.grey[600];return{display:"block",borderColor:e.vars?e.vars.palette.StepConnector.border:o,variants:[{props:{orientation:"horizontal"},style:{borderTopStyle:"solid",borderTopWidth:1}},{props:{orientation:"vertical"},style:{borderLeftStyle:"solid",borderLeftWidth:1,minHeight:24}}]}})),Pe=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStepConnector"}),{className:r,...i}=s,{alternativeLabel:c,orientation:l="horizontal"}=u.useContext(O),{active:S,disabled:m,completed:d}=u.useContext(V),p={...s,alternativeLabel:c,orientation:l,active:S,completed:d,disabled:m},a=Me(p);return n.jsx(Ne,{className:M(a.root,r),ref:t,ownerState:p,...i,children:n.jsx(Ae,{className:a.line,ownerState:p})})});function Fe(e){return I("MuiStepper",e)}T("MuiStepper",["root","horizontal","vertical","nonLinear","alternativeLabel"]);const Ie=e=>{const{orientation:o,nonLinear:t,alternativeLabel:s,classes:r}=e;return $({root:["root",o,t&&"nonLinear",s&&"alternativeLabel"]},Fe,r)},Te=b("div",{name:"MuiStepper",slot:"Root",overridesResolver:(e,o)=>{const{ownerState:t}=e;return[o.root,o[t.orientation],t.alternativeLabel&&o.alternativeLabel,t.nonLinear&&o.nonLinear]}})({display:"flex",variants:[{props:{orientation:"horizontal"},style:{flexDirection:"row",alignItems:"center"}},{props:{orientation:"vertical"},style:{flexDirection:"column"}},{props:{alternativeLabel:!0},style:{alignItems:"flex-start"}}]}),ze=n.jsx(Pe,{}),G=u.forwardRef(function(o,t){const s=z({props:o,name:"MuiStepper"}),{activeStep:r=0,alternativeLabel:i=!1,children:c,className:l,component:S="div",connector:m=ze,nonLinear:d=!1,orientation:p="horizontal",...a}=s,x={...s,nonLinear:d,alternativeLabel:i,orientation:p,component:S},v=Ie(x),h=u.Children.toArray(c).filter(Boolean),C=h.map((k,y)=>u.cloneElement(k,{index:y,last:y+1===h.length,...k.props})),N=u.useMemo(()=>({activeStep:r,alternativeLabel:i,connector:m,nonLinear:d,orientation:p}),[r,i,m,d,p]);return n.jsx(O.Provider,{value:N,children:n.jsx(Te,{as:S,ownerState:x,className:M(v.root,l),ref:t,...a,children:C})})}),it={title:"Navigation/Stepper",component:G,parameters:{layout:"centered",controls:{exclude:["onDelete"]}},decorators:[e=>n.jsx(f,{width:500,children:e()})],argTypes:{alternativeLabel:{control:"select",options:[!0,!1]},nonLinear:{control:"select",options:[!0,!1]},orientation:{control:"select",options:["horizontal","vertical"]}},args:{}},E={render:e=>{const o=["Step 1","Step 2","Step 3"],[t,s]=g.useState(0),[r,i]=g.useState(new Set),c=a=>a===1,l=a=>r.has(a),S=()=>{let a=r;l(t)&&(a=new Set(a.values()),a.delete(t)),s(x=>x+1),i(a)},m=()=>{s(a=>a-1)},d=()=>{if(!c(t))throw new Error("You can't skip a step that isn't optional.");s(a=>a+1),i(a=>{const x=new Set(a.values());return x.add(t),x})},p=()=>{s(0)};return n.jsxs(n.Fragment,{children:[n.jsx(G,{activeStep:t,...e,children:o.map((a,x)=>{const v={},h={};return c(x)&&(h.optional=n.jsx(w,{variant:"caption",children:"Optional"})),l(x)&&(v.completed=!1),n.jsx(te,{...v,sx:{p:0},children:n.jsx(q,{...h,children:a})},a)})}),t===o.length?n.jsxs(g.Fragment,{children:[n.jsx(w,{sx:{mt:2,mb:1},children:"All steps completed - you're finished"}),n.jsxs(f,{sx:{display:"flex",flexDirection:"row",pt:2},children:[n.jsx(f,{sx:{flex:"1 1 auto"}}),n.jsx(B,{variant:"contained",onClick:p,children:"Reset"})]})]}):n.jsxs(g.Fragment,{children:[n.jsxs(w,{sx:{mt:2,mb:1},children:["Step ",t+1]}),n.jsxs(f,{sx:{display:"flex",flexDirection:"row",pt:2},children:[n.jsx(B,{color:"inherit",disabled:t===0,onClick:m,sx:{mr:1},variant:"contained",children:"Back"}),n.jsx(f,{sx:{flex:"1 1 auto"}}),c(t)&&n.jsx(B,{variant:"contained",color:"inherit",onClick:d,sx:{mr:1},children:"Skip"}),n.jsx(B,{variant:"contained",onClick:S,children:t===o.length-1?"Finish":"Next"})]})]})]})}},W={render:e=>{const o=["Step 1","Step 2","Step 3"],[t,s]=g.useState(0),[r,i]=g.useState({}),c=()=>o.length,l=()=>Object.keys(r).length,S=()=>t===c()-1,m=()=>l()===c(),d=()=>{const v=S()&&!m()?o.findIndex((h,C)=>!(C in r)):t+1;s(v)},p=v=>()=>{s(v)},a=()=>{i({...r,[t]:!0}),d()},x=()=>{s(0),i({})};return n.jsxs(n.Fragment,{children:[n.jsx(G,{activeStep:t,...e,nonLinear:!0,children:o.map((v,h)=>n.jsx(te,{sx:{p:0},completed:r[h],children:n.jsx(we,{onClick:p(h),children:v})},v))}),t===o.length?n.jsxs(g.Fragment,{children:[n.jsx(w,{sx:{mt:2,mb:1},children:"All steps completed - you're finished"}),n.jsxs(f,{sx:{display:"flex",flexDirection:"row",pt:2},children:[n.jsx(f,{sx:{flex:"1 1 auto"}}),n.jsx(B,{variant:"contained",onClick:x,children:"Reset"})]})]}):n.jsx(g.Fragment,{children:m()?n.jsxs(g.Fragment,{children:[n.jsx(w,{sx:{mt:2,mb:1},children:"All steps completed - you're finished"}),n.jsxs(f,{sx:{display:"flex",flexDirection:"row",pt:2},children:[n.jsx(f,{sx:{flex:"1 1 auto"}}),n.jsx(B,{onClick:x,children:"Reset"})]})]}):n.jsxs(g.Fragment,{children:[n.jsxs(w,{sx:{mt:2,mb:1},children:["Step ",t+1]}),n.jsxs(f,{sx:{display:"flex",flexDirection:"row",pt:2},children:[n.jsx(f,{sx:{flex:"1 1 auto"}}),t!==o.length&&(r[t]?n.jsxs(w,{variant:"caption",sx:{display:"inline-block"},children:["Step ",t+1," already completed"]}):n.jsx(B,{size:"small",variant:"contained",onClick:a,children:l()===c()-1?"Finish":"Complete Step"}))]})]})})]})}};E.parameters={...E.parameters,docs:{...E.parameters?.docs,source:{originalSource:`{
  render: (props: StepperOwnProps) => {
    const steps = ["Step 1", "Step 2", "Step 3"];
    const [activeStep, setActiveStep] = React.useState(0);
    const [skipped, setSkipped] = React.useState(new Set<number>());
    const isStepOptional = (step: number) => {
      return step === 1;
    };
    const isStepSkipped = (step: number) => {
      return skipped.has(step);
    };
    const handleNext = () => {
      let newSkipped = skipped;
      if (isStepSkipped(activeStep)) {
        newSkipped = new Set(newSkipped.values());
        newSkipped.delete(activeStep);
      }
      setActiveStep(prevActiveStep => prevActiveStep + 1);
      setSkipped(newSkipped);
    };
    const handleBack = () => {
      setActiveStep(prevActiveStep => prevActiveStep - 1);
    };
    const handleSkip = () => {
      if (!isStepOptional(activeStep)) {
        throw new Error("You can't skip a step that isn't optional.");
      }
      setActiveStep(prevActiveStep => prevActiveStep + 1);
      setSkipped(prevSkipped => {
        const newSkipped = new Set(prevSkipped.values());
        newSkipped.add(activeStep);
        return newSkipped;
      });
    };
    const handleReset = () => {
      setActiveStep(0);
    };
    return <>
        <Stepper activeStep={activeStep} {...props}>
          {steps.map((label, index) => {
          const stepProps: {
            completed?: boolean;
          } = {};
          const labelProps: {
            optional?: React.ReactNode;
          } = {};
          if (isStepOptional(index)) {
            labelProps.optional = <Typography variant="caption">Optional</Typography>;
          }
          if (isStepSkipped(index)) {
            stepProps.completed = false;
          }
          return <Step key={label} {...stepProps} sx={{
            p: 0
          }}>
                <StepLabel {...labelProps}>{label}</StepLabel>
              </Step>;
        })}
        </Stepper>
        {activeStep === steps.length ? <React.Fragment>
            <Typography sx={{
          mt: 2,
          mb: 1
        }}>
              All steps completed - you&apos;re finished
            </Typography>
            <Box sx={{
          display: "flex",
          flexDirection: "row",
          pt: 2
        }}>
              <Box sx={{
            flex: "1 1 auto"
          }} />
              <Button variant="contained" onClick={handleReset}>
                Reset
              </Button>
            </Box>
          </React.Fragment> : <React.Fragment>
            <Typography sx={{
          mt: 2,
          mb: 1
        }}>Step {activeStep + 1}</Typography>
            <Box sx={{
          display: "flex",
          flexDirection: "row",
          pt: 2
        }}>
              <Button color="inherit" disabled={activeStep === 0} onClick={handleBack} sx={{
            mr: 1
          }} variant="contained">
                Back
              </Button>
              <Box sx={{
            flex: "1 1 auto"
          }} />
              {isStepOptional(activeStep) && <Button variant="contained" color="inherit" onClick={handleSkip} sx={{
            mr: 1
          }}>
                  Skip
                </Button>}
              <Button variant="contained" onClick={handleNext}>
                {activeStep === steps.length - 1 ? "Finish" : "Next"}
              </Button>
            </Box>
          </React.Fragment>}
      </>;
  }
}`,...E.parameters?.docs?.source}}};W.parameters={...W.parameters,docs:{...W.parameters?.docs,source:{originalSource:`{
  render: (props: StepperOwnProps) => {
    const steps = ["Step 1", "Step 2", "Step 3"];
    const [activeStep, setActiveStep] = React.useState(0);
    const [completed, setCompleted] = React.useState<{
      [k: number]: boolean;
    }>({});
    const totalSteps = () => {
      return steps.length;
    };
    const completedSteps = () => {
      return Object.keys(completed).length;
    };
    const isLastStep = () => {
      return activeStep === totalSteps() - 1;
    };
    const allStepsCompleted = () => {
      return completedSteps() === totalSteps();
    };
    const handleNext = () => {
      const newActiveStep = isLastStep() && !allStepsCompleted() ? steps.findIndex((step, i) => !(i in completed)) : activeStep + 1;
      setActiveStep(newActiveStep);
    };
    const handleStep = (step: number) => () => {
      setActiveStep(step);
    };
    const handleComplete = () => {
      setCompleted({
        ...completed,
        [activeStep]: true
      });
      handleNext();
    };
    const handleReset = () => {
      setActiveStep(0);
      setCompleted({});
    };
    return <>
        <Stepper activeStep={activeStep} {...props} nonLinear>
          {steps.map((label, index) => {
          return <Step key={label} sx={{
            p: 0
          }} completed={completed[index]}>
                <StepButton onClick={handleStep(index)}>{label}</StepButton>
              </Step>;
        })}
        </Stepper>
        {activeStep === steps.length ? <React.Fragment>
            <Typography sx={{
          mt: 2,
          mb: 1
        }}>
              All steps completed - you&apos;re finished
            </Typography>
            <Box sx={{
          display: "flex",
          flexDirection: "row",
          pt: 2
        }}>
              <Box sx={{
            flex: "1 1 auto"
          }} />
              <Button variant="contained" onClick={handleReset}>
                Reset
              </Button>
            </Box>
          </React.Fragment> : <React.Fragment>
            {allStepsCompleted() ? <React.Fragment>
                <Typography sx={{
            mt: 2,
            mb: 1
          }}>
                  All steps completed - you&apos;re finished
                </Typography>
                <Box sx={{
            display: "flex",
            flexDirection: "row",
            pt: 2
          }}>
                  <Box sx={{
              flex: "1 1 auto"
            }} />
                  <Button onClick={handleReset}>Reset</Button>
                </Box>
              </React.Fragment> : <React.Fragment>
                <Typography sx={{
            mt: 2,
            mb: 1
          }}>
                  Step {activeStep + 1}
                </Typography>
                <Box sx={{
            display: "flex",
            flexDirection: "row",
            pt: 2
          }}>
                  <Box sx={{
              flex: "1 1 auto"
            }} />
                  {activeStep !== steps.length && (completed[activeStep] ? <Typography variant="caption" sx={{
              display: "inline-block"
            }}>
                        Step {activeStep + 1} already completed
                      </Typography> : <Button size="small" variant="contained" onClick={handleComplete}>
                        {completedSteps() === totalSteps() - 1 ? "Finish" : "Complete Step"}
                      </Button>)}
                </Box>
              </React.Fragment>}
          </React.Fragment>}
      </>;
  }
}`,...W.parameters?.docs?.source}}};const lt=["LinearStepper","NonLinearStepper"];export{E as LinearStepper,W as NonLinearStepper,lt as __namedExportsOrder,it as default};
