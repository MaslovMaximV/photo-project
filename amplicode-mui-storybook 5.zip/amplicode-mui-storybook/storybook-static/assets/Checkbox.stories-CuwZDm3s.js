import{j as e}from"./iframe-U1MoWpc_.js";import{a as p,F as m}from"./FavoriteBorder-DiR9fGnD.js";import{C as o}from"./Checkbox-BnFC51e2.js";import{F as d}from"./FormControlLabel-Bq-a8dVL.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./SwitchBase-9AkWq_7-.js";import"./useFormControl-q410XUqr.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useControlled-CeZ7-hqo.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./mergeSlotProps-BszqYXGC.js";import"./formControlState-Dq1zat_P.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";const D={title:"Inputs/Checkbox",component:o,parameters:{layout:"centered",controls:{exclude:["icon","checkedIcon","checked"]}},decorators:[],argTypes:{defaultChecked:{control:"boolean"},disabled:{control:"boolean"},color:{control:"select",options:["inherit","primary","secondary","success","error","info","warning"]},size:{control:"select",options:["small","medium","large"]}},args:{defaultChecked:!0,disabled:!1,color:"primary",size:"medium"}},t={render:({...r})=>e.jsx(o,{...r})},n={render:({...r})=>e.jsx(o,{icon:e.jsx(e.Fragment,{}),checkedIcon:e.jsx(e.Fragment,{}),...r}),args:{defaultChecked:!1,icon:e.jsx(m,{}),checkedIcon:e.jsx(p,{})}},c={render:({checked:r,...a})=>e.jsx(d,{control:e.jsx(o,{defaultChecked:!0}),label:"Label"})},s={render:({checked:r,...a})=>e.jsx(o,{checked:r,onChange:()=>{},...a}),args:{checked:!0}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Checkbox {...props} />;
  }
}`,...t.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Checkbox icon={<></>} checkedIcon={<></>} {...props} />;
  },
  args: {
    defaultChecked: false,
    icon: <FavoriteBorder />,
    checkedIcon: <Favorite />
  }
}`,...n.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: ({
    checked,
    ...props
  }) => {
    return <FormControlLabel control={<Checkbox defaultChecked />} label="Label" />;
  }
}`,...c.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    checked,
    ...props
  }) => {
    return <Checkbox checked={checked} onChange={() => {}} {...props} />;
  },
  args: {
    checked: true
  }
}`,...s.parameters?.docs?.source}}};const G=["Basic","CustomIcon","Label","Controlled"];export{t as Basic,s as Controlled,n as CustomIcon,c as Label,G as __namedExportsOrder,D as default};
