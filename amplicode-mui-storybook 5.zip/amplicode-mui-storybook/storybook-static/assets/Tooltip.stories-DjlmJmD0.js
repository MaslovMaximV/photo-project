import{j as r}from"./iframe-U1MoWpc_.js";import{T as o}from"./Tooltip-DCxzgiP4.js";import{T as n}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./index-BnGSTqEq.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useTheme-DUWNGOj_.js";import"./memoTheme-BNYDzr43.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useTimeout-CYujZKVu.js";import"./useControlled-CeZ7-hqo.js";import"./useId-vd1Ifx8D.js";import"./useEventCallback-ELgNMDCa.js";import"./getReactElementRef-BK8oRZgb.js";import"./Grow-YN3686EE.js";import"./utils-DUlJK7XT.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./Popper-ueJFtwYo.js";import"./ownerDocument-DW-IO8s5.js";import"./Portal-Dc2RZP_l.js";import"./useSlotProps-BHg2pJuT.js";import"./isFocusVisible-B8k4qzLc.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const H={title:"Inputs/Tooltip",component:o,parameters:{layout:"centered",controls:{exclude:["children"]}},decorators:[],argTypes:{arrow:{control:"select",options:[!1,!0]},title:{control:"text"},placement:{control:"select",options:["bottom-end","bottom-start","bottom","left-end","left-start","left","right-end","right-start","right","top-end","top-start","top"]},enterDelay:{control:"text"},leaveDelay:{control:"text"}},args:{title:"Add",arrow:!0}},t={render:({title:e,children:p,arrow:i,...m})=>r.jsx(o,{title:e,arrow:i,children:p}),args:{children:r.jsx(n,{children:"Show tooltip"})}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    title,
    children,
    arrow,
    ...props
  }) => {
    return <Tooltip title={title} arrow={arrow}>
        {children}
      </Tooltip>;
  },
  args: {
    children: <Typography>Show tooltip</Typography>
  }
}`,...t.parameters?.docs?.source}}};const J=["Basic"];export{t as Basic,J as __namedExportsOrder,H as default};
