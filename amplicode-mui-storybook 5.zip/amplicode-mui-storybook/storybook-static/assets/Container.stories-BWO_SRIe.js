import{j as n}from"./iframe-U1MoWpc_.js";import{C as t}from"./Container-BslDs3ZR.js";import{B as i}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./styled-DKEkqMyo.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";const g={title:"Layout/Container",component:t,parameters:{layout:"centered",controls:{exclude:["divider"]}},argTypes:{maxWidth:{control:"select",options:["xs","sm","md","lg","xl"]},fixed:{control:"boolean"}},tags:["wrapper"],args:{}},e={render:({...o})=>n.jsx(t,{maxWidth:"lg",...o,children:n.jsx(i,{sx:{bgcolor:"#cfe8fc",height:"100vh",p:2},children:"A fluid container width is bounded by the maxWidth prop value."})})},r={render:({...o})=>n.jsx(t,{fixed:!0,...o,children:n.jsx(i,{sx:{bgcolor:"#cfe8fc",height:"100vh",p:2},children:"Responsive container. The max-width matches the min-width of the current breakpoint."})})};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Container maxWidth={"lg"} {...props}>
        <Box sx={{
        bgcolor: "#cfe8fc",
        height: "100vh",
        p: 2
      }}>
          A fluid container width is bounded by the maxWidth prop value.
        </Box>
      </Container>;
  }
}`,...e.parameters?.docs?.source}}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Container fixed {...props}>
        <Box sx={{
        bgcolor: "#cfe8fc",
        height: "100vh",
        p: 2
      }}>
          Responsive container. The max-width matches the min-width of the current breakpoint.
        </Box>
      </Container>;
  }
}`,...r.parameters?.docs?.source}}};const b=["Fluid","Fixed"];export{r as Fixed,e as Fluid,b as __namedExportsOrder,g as default};
