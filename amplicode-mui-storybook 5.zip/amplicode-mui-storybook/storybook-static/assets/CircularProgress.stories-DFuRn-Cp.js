import{j as a}from"./iframe-U1MoWpc_.js";import{C as s}from"./CircularProgress-Bb4IBCi9.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./emotion-react.browser.esm-B8CpGYti.js";const v={title:"Feedback/Progress/CircularProgress",component:s,parameters:{layout:"centered",controls:{exclude:["options","renderInput"]}},decorators:[],argTypes:{color:{control:"select",options:["inherit","primary","secondary","success","error","info","warning"]},size:{control:"text"}},args:{color:"primary",size:40}},r={render:({size:o,color:n,...t})=>a.jsx(s,{size:o,color:n})},e={render:({size:o,color:n,value:t,...i})=>a.jsx(s,{variant:"determinate",value:t,size:o,color:n}),argTypes:{value:{control:{type:"number",min:0,max:100}}},args:{value:40}};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: ({
    size,
    color,
    ...props
  }) => {
    return <CircularProgress size={size} color={color} />;
  }
}`,...r.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: ({
    size,
    color,
    value,
    ...props
  }) => {
    return <CircularProgress variant="determinate" value={value} size={size} color={color} />;
  },
  argTypes: {
    value: {
      control: {
        type: "number",
        min: 0,
        max: 100
      }
    }
  },
  args: {
    value: 40
  }
}`,...e.parameters?.docs?.source}}};const y=["Indeterminate","Determinate"];export{e as Determinate,r as Indeterminate,y as __namedExportsOrder,v as default};
