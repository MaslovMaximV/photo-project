import{r as e}from"./iframe-U1MoWpc_.js";function n(r){return parseInt(e.version,10)>=19?r?.props?.ref||null:r?.ref||null}export{n as g};
