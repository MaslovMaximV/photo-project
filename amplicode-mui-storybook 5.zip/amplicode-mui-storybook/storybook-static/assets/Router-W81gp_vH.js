import{j as e}from"./iframe-U1MoWpc_.js";import{useMDXComponents as n}from"./index-DfaKO2T-.js";import{M as i}from"./blocks-BRoCG--n.js";import{R as a}from"./Router.stories-DJv1p4F2.js";import"./preload-helper-D9Z9MdNV.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./Button-Z4BDc59h.js";import"./createTheme-CB0G2ADO.js";import"./DefaultPropsProvider-Drazl94h.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./Box-nnrC_EdN.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";function o(t){const r={code:"code",h1:"h1",h2:"h2",p:"p",pre:"pre",...n(),...t.components};return e.jsxs(e.Fragment,{children:[e.jsx(i,{of:a}),`
`,e.jsx(r.h1,{id:"router",children:"Router"}),`
`,e.jsx(r.p,{children:"React Router is a multi-strategy router for React bridging the gap from React 18 to React 19."}),`
`,e.jsx(r.p,{children:"You can use it maximally as a React framework or as minimally as you want."}),`
`,e.jsx(r.h2,{id:"browserouter",children:"BrowseRouter"}),`
`,e.jsx(r.pre,{children:e.jsx(r.code,{children:`<BrowserRouter>
  <Routes>
    <Route path="/" element={<div>Page</div>} />
  </Routes>
</BrowserRouter>
`})}),`
`,e.jsx(r.h2,{id:"usenavigate",children:"useNavigate"}),`
`,e.jsx(r.p,{children:"Returns a function that lets you navigate programmatically in the browser in response to user interactions or effects."}),`
`,e.jsx(r.p,{children:'Available as VsCode completion. Keywords: "nav", "navigate", "link", "goto".'}),`
`,e.jsx(r.pre,{children:e.jsx(r.code,{children:`  const navigate = useNavigate();
`})}),`
`,e.jsx(r.h2,{id:"usenavigate-1",children:"useNavigate"}),`
`,e.jsx(r.p,{children:"Returns an object of key/value-pairs of the dynamic params from the current URL that were matched by the routes. Child routes inherit all params from their parent routes."}),`
`,e.jsx(r.p,{children:'Available as VsCode completion. Keywords: "params", "useParams".'}),`
`,e.jsx(r.pre,{children:e.jsx(r.code,{children:`  const params = useParams();
`})})]})}function P(t={}){const{wrapper:r}={...n(),...t.components};return r?e.jsx(r,{...t,children:e.jsx(o,{...t})}):o(t)}export{P as default};
