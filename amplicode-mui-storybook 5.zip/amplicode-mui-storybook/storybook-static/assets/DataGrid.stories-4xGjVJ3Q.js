import{j as r}from"./iframe-U1MoWpc_.js";import{D as a}from"./DataGrid-DWxDeSt-.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./index-mhWa10dC.js";import"./useGridApiInitialization-i47JJJA8.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useTheme-DUWNGOj_.js";import"./useTimeout-CYujZKVu.js";import"./fastMemo-B4NBZms6.js";import"./fastObjectShallowCompare-DvmlZRcg.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./styled-DKEkqMyo.js";import"./loadStyleSheets-BzuWkbx4.js";import"./memoTheme-BNYDzr43.js";import"./MenuItem-BRakH7X1.js";import"./MenuList-BqnUBxHF.js";import"./FocusTrap-aa0DuC0e.js";import"./getReactElementRef-BK8oRZgb.js";import"./ownerDocument-DW-IO8s5.js";import"./ownerWindow-HkKU3E4x.js";import"./ButtonBase-BUPfvClL.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./isFocusVisible-B8k4qzLc.js";import"./dividerClasses-BwqMPq15.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./index-BCOT2pGA.js";import"./index-BnGSTqEq.js";import"./isDeepEqual-CWgvpjyk.js";import"./useId-vd1Ifx8D.js";import"./debounce-Be36O1Ab.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./createSvgIcon-Ck9VyYEl.js";import"./Switch-BSvuxx3D.js";import"./SwitchBase-9AkWq_7-.js";import"./useFormControl-q410XUqr.js";import"./useControlled-CeZ7-hqo.js";import"./FormLabel-gyC02a8P.js";import"./utils-DoM3o7-Q.js";import"./isMuiElement-BH3XSIgM.js";import"./formControlState-Dq1zat_P.js";import"./Select-BEnjJmuz.js";import"./useSlotProps-BHg2pJuT.js";import"./Popover-Ti7x1Jzs.js";import"./isHostComponent-DVu5iVWx.js";import"./Grow-YN3686EE.js";import"./utils-DUlJK7XT.js";import"./mergeSlotProps-BszqYXGC.js";import"./Modal-Cups6cDA.js";import"./createChainedFunction-BO_9K8Jh.js";import"./Portal-Dc2RZP_l.js";import"./Backdrop-DKjtt3hE.js";import"./Fade-P8xhlTFS.js";import"./Paper-BtmMZDrw.js";import"./Input-DC-6me1o.js";import"./Popper-ueJFtwYo.js";import"./Tooltip-DCxzgiP4.js";import"./IconButton-DY_fXBCG.js";import"./CircularProgress-Bb4IBCi9.js";import"./Button-Z4BDc59h.js";import"./TextField-D08magkU.js";import"./FormHelperText-DApA1kKb.js";import"./LinearProgress-aznT_VTh.js";import"./Divider-ldTtmydz.js";import"./Chip-8gafZhjN.js";import"./Badge-CBsmv7US.js";import"./usePreviousProps-Bv8dyoI3.js";import"./Autocomplete-iZhXfoXL.js";import"./Close-DCGMSXuw.js";import"./FormControlLabel-Bq-a8dVL.js";import"./Toolbar-CUdeLhnu.js";import"./Checkbox-BnFC51e2.js";import"./ClickAwayListener-CNurJXGo.js";import"./InputAdornment-Cn1PrQgW.js";import"./getThemeProps-4b2KySkp.js";const Ii={title:"DataDisplay/DataGrids/DataGrid",component:a,parameters:{layout:"fullscreen",studioMeta:{npmDeps:[{name:"@mui/x-data-grid"}]},docs:{description:{component:"The MIT-licensed Community version of the Data Grid is a more sophisticated implementation of the Material UI Table. It includes all of the main features listed in the navigation menu, such as editing, sorting, filtering, and pagination, as shown in the demo below"}}},args:{pageSize:5}},o=[{field:"id",headerName:"ID",width:90},{field:"firstName",headerName:"First name",width:150,editable:!0},{field:"lastName",headerName:"Last name",width:150,editable:!0},{field:"age",headerName:"Age",type:"number",width:110,editable:!0},{field:"fullName",headerName:"Full name",description:"This column has a value getter and is not sortable.",sortable:!1,width:160,valueGetter:(e,i)=>`${i.firstName||""} ${i.lastName||""}`}],m=[{id:1,lastName:"Snow",firstName:"Jon",age:14},{id:2,lastName:"Lannister",firstName:"Cersei",age:31},{id:3,lastName:"Lannister",firstName:"Jaime",age:31},{id:4,lastName:"Stark",firstName:"Arya",age:11},{id:5,lastName:"Targaryen",firstName:"Daenerys",age:null},{id:6,lastName:"Melisandre",firstName:null,age:150},{id:7,lastName:"Clifford",firstName:"Ferrara",age:44},{id:8,lastName:"Frances",firstName:"Rossini",age:36},{id:9,lastName:"Roxie",firstName:"Harvey",age:65}],t={render:({rows:e,columns:i})=>r.jsx("div",{style:{height:400,width:"100%"},children:r.jsx(a,{rows:e,columns:i,initialState:{pagination:{paginationModel:{pageSize:5}}},pageSizeOptions:[5,10],checkboxSelection:!0,disableRowSelectionOnClick:!0})}),args:{rows:m,columns:o},parameters:{docs:{description:{story:"Basic data grid with pagination."}}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    rows,
    columns
  }) => {
    return <div style={{
      height: 400,
      width: "100%"
    }}>
        <DataGrid rows={rows} columns={columns} initialState={{
        pagination: {
          paginationModel: {
            pageSize: 5
          }
        }
      }} pageSizeOptions={[5, 10]} checkboxSelection disableRowSelectionOnClick />
      </div>;
  },
  args: {
    rows: rows,
    columns: columns
  },
  parameters: {
    docs: {
      description: {
        story: "Basic data grid with pagination."
      }
    }
  }
}`,...t.parameters?.docs?.source}}};const Li=["Basic"];export{t as Basic,Li as __namedExportsOrder,Ii as default};
