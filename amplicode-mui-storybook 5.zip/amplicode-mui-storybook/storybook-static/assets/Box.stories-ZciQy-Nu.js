import{j as t}from"./iframe-U1MoWpc_.js";import{B as r}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";const m={title:"Layout/Box",component:r,parameters:{layout:"centered",controls:{exclude:["divider"]}},tags:["wrapper","morph"],argTypes:{height:{control:"number"},width:{control:"number"}}},o={render:({...e})=>t.jsx(r,{...e}),decorators:[e=>t.jsxs(r,{children:['Basic universal mui container with all available system properties. Used as an extended "div" element.',e()]})]},n={render:({...e})=>t.jsx(r,{...e,sx:{background:"action.disabledBackground"}}),decorators:[e=>t.jsxs(r,{children:['Basic universal mui container with all available system properties. Used as an extended "div" element.',e()]})]},s={render:({...e})=>t.jsx(r,{...e,sx:{position:"absolute",top:30,left:30},children:"Box content"}),decorators:[e=>t.jsxs(r,{width:200,height:200,bgcolor:"#eee",position:"relative",children:["Static content ",e()]})]},a={render:({...e})=>t.jsx(r,{...e,sx:{width:"30px",height:"30px",position:"absolute",top:0,left:0,right:0,bottom:0,margin:"auto",background:"#aaa"}}),decorators:[e=>t.jsxs(r,{width:200,height:200,bgcolor:"#eee",position:"relative",children:["Static content ",e()]})],tags:["wrapper"]};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Box {...props}></Box>;
  },
  decorators: [Story => <Box>
        Basic universal mui container with all available system properties. Used
        as an extended "div" element.
        {Story()}
      </Box>]
}`,...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Box {...props} sx={{
      background: "action.disabledBackground"
    }}></Box>;
  },
  decorators: [Story => <Box>
        Basic universal mui container with all available system properties. Used
        as an extended "div" element.
        {Story()}
      </Box>]
}`,...n.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Box {...props} sx={{
      position: "absolute",
      top: 30,
      left: 30
    }}>
        Box content
      </Box>;
  },
  decorators: [Story => <Box width={200} height={200} bgcolor={"#eee"} position={"relative"}>
        Static content {Story()}
      </Box>]
}`,...s.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Box {...props} sx={{
      width: "30px",
      height: "30px",
      position: "absolute",
      top: 0,
      left: 0,
      right: 0,
      bottom: 0,
      margin: "auto",
      background: "#aaa"
    }}>
        
      </Box>;
  },
  decorators: [Story => <Box width={200} height={200} bgcolor={"#eee"} position={"relative"}>
        Static content {Story()}
      </Box>],
  tags: ['wrapper']
}`,...a.parameters?.docs?.source}}};const x=["Default","WithThemeProperty","Absolute","AbsoluteCentered"];export{s as Absolute,a as AbsoluteCentered,o as Default,n as WithThemeProperty,x as __namedExportsOrder,m as default};
