import{j as e}from"./iframe-U1MoWpc_.js";import{L as t}from"./LinearProgress-aznT_VTh.js";import{B as m}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./index-BnGSTqEq.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";const u=r=>e.jsx(m,{sx:{width:200},children:e.jsx(r,{})}),L={title:"Feedback/Progress/LinearProgress",component:t,parameters:{layout:"centered",controls:{exclude:["options","renderInput"]}},decorators:[u],argTypes:{color:{control:"select",options:["inherit","primary","secondary","success","error","info","warning"]}},args:{color:"primary"}},o={render:({color:r,...n})=>e.jsx(t,{color:r}),args:{color:"primary"}},a={render:({color:r,value:n,...p})=>e.jsx(t,{variant:"determinate",value:n,color:r}),argTypes:{value:{control:{type:"number",min:0,max:100}}},args:{value:40,color:"primary"}},s={render:({value:r,valueBuffer:n,...p})=>e.jsx(t,{variant:"buffer",value:r,valueBuffer:n}),argTypes:{value:{control:{type:"number",min:0,max:100}},valueBuffer:{control:{type:"number",min:0,max:100}}},args:{value:40,valueBuffer:50}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    color,
    ...props
  }) => {
    return <LinearProgress color={color} />;
  },
  args: {
    color: "primary"
  }
}`,...o.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    color,
    value,
    ...props
  }) => {
    return <LinearProgress variant="determinate" value={value} color={color} />;
  },
  argTypes: {
    value: {
      control: {
        type: "number",
        min: 0,
        max: 100
      }
    }
  },
  args: {
    value: 40,
    color: "primary"
  }
}`,...a.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    value,
    valueBuffer,
    ...props
  }) => {
    return <LinearProgress variant="buffer" value={value} valueBuffer={valueBuffer} />;
  },
  argTypes: {
    value: {
      control: {
        type: "number",
        min: 0,
        max: 100
      }
    },
    valueBuffer: {
      control: {
        type: "number",
        min: 0,
        max: 100
      }
    }
  },
  args: {
    value: 40,
    valueBuffer: 50
  }
}`,...s.parameters?.docs?.source}}};const P=["Indeterminate","Determinate","Buffer"];export{s as Buffer,a as Determinate,o as Indeterminate,P as __namedExportsOrder,L as default};
