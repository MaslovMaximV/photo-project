import{r as l,j as t}from"./iframe-U1MoWpc_.js";import{S as o,I as n}from"./Select-BEnjJmuz.js";import{F as c}from"./FormLabel-gyC02a8P.js";import{M as r}from"./MenuItem-BRakH7X1.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./formControlState-Dq1zat_P.js";import"./useFormControl-q410XUqr.js";import"./DefaultPropsProvider-Drazl94h.js";import"./memoTheme-BNYDzr43.js";import"./index-BnGSTqEq.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useSlotProps-BHg2pJuT.js";import"./Popover-Ti7x1Jzs.js";import"./isHostComponent-DVu5iVWx.js";import"./ownerDocument-DW-IO8s5.js";import"./ownerWindow-HkKU3E4x.js";import"./debounce-Be36O1Ab.js";import"./Grow-YN3686EE.js";import"./useTheme-CMyrA-7l.js";import"./useTheme-DUWNGOj_.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./mergeSlotProps-BszqYXGC.js";import"./Modal-Cups6cDA.js";import"./FocusTrap-aa0DuC0e.js";import"./useEventCallback-ELgNMDCa.js";import"./createChainedFunction-BO_9K8Jh.js";import"./Portal-Dc2RZP_l.js";import"./Backdrop-DKjtt3hE.js";import"./Fade-P8xhlTFS.js";import"./Paper-BtmMZDrw.js";import"./MenuList-BqnUBxHF.js";import"./utils-DoM3o7-Q.js";import"./useControlled-CeZ7-hqo.js";import"./useId-vd1Ifx8D.js";import"./createSvgIcon-Ck9VyYEl.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./Input-DC-6me1o.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./isMuiElement-BH3XSIgM.js";import"./ButtonBase-BUPfvClL.js";import"./isFocusVisible-B8k4qzLc.js";import"./dividerClasses-BwqMPq15.js";const lt={title:"Inputs/Select",component:o,parameters:{layout:"centered",controls:{}},decorators:[],argTypes:{},args:{}},e={render:({...p})=>{const[m,i]=l.useState(""),a=s=>{i(s.target.value)};return t.jsxs(c,{sx:{width:300},children:[t.jsx(n,{id:"simple-select-label",children:"Pet"}),t.jsxs(o,{labelId:"simple-select-label",id:"simple-select",value:m,label:"Pet",...p,onChange:a,children:[t.jsx(r,{value:"Cat",children:"Cat"}),t.jsx(r,{value:"Dog",children:"Dog"}),t.jsx(r,{value:"Sparrow",children:"Sparrow"})]})]})}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    const [pet, setPet] = useState('');
    const handleChange = (event: SelectChangeEvent) => {
      setPet(event.target.value as string);
    };
    return <FormControl sx={{
      width: 300
    }}>
        <InputLabel id="simple-select-label">Pet</InputLabel>
        <Select labelId="simple-select-label" id="simple-select" value={pet} label="Pet" {...props}
      // @ts-ignore
      onChange={handleChange}>
          <MenuItem value={'Cat'}>Cat</MenuItem>
          <MenuItem value={'Dog'}>Dog</MenuItem>
          <MenuItem value={'Sparrow'}>Sparrow</MenuItem>
        </Select>
      </FormControl>;
  }
}`,...e.parameters?.docs?.source}}};const nt=["Basic"];export{e as Basic,nt as __namedExportsOrder,lt as default};
