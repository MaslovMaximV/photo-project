import{r as g,j as r,u as M}from"./iframe-U1MoWpc_.js";import{B as a}from"./Box-nnrC_EdN.js";import{B as O}from"./Button-Z4BDc59h.js";import{F as q}from"./Fade-P8xhlTFS.js";import{G as H}from"./Grow-YN3686EE.js";import{S as J}from"./Slide-DVFtChZU.js";import{u as K}from"./useTheme-CMyrA-7l.js";import{T as N,g as j,r as Q}from"./utils-DUlJK7XT.js";import{u as V}from"./useForkRef-OOgs0334.js";import{g as W}from"./getReactElementRef-BK8oRZgb.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";import"./DefaultPropsProvider-Drazl94h.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./debounce-Be36O1Ab.js";import"./ownerWindow-HkKU3E4x.js";import"./ownerDocument-DW-IO8s5.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";const X={entering:{transform:"none"},entered:{transform:"none"}},Y=g.forwardRef(function(y,h){const t=K(),T={enter:t.transitions.duration.enteringScreen,exit:t.transitions.duration.leavingScreen},{addEndListener:w,appear:F=!0,children:u,easing:S,in:E,onEnter:b,onEntered:G,onEntering:Z,onExit:R,onExited:v,onExiting:B,style:f,timeout:x=T,TransitionComponent:z=N,...C}=y,d=g.useRef(null),P=V(d,W(u),h),i=e=>o=>{if(e){const s=d.current;o===void 0?e(s):e(s,o)}},k=i(Z),A=i((e,o)=>{Q(e);const s=j({style:f,timeout:x,easing:S},{mode:"enter"});e.style.webkitTransition=t.transitions.create("transform",s),e.style.transition=t.transitions.create("transform",s),b&&b(e,o)}),I=i(G),L=i(B),U=i(e=>{const o=j({style:f,timeout:x,easing:S},{mode:"exit"});e.style.webkitTransition=t.transitions.create("transform",o),e.style.transition=t.transitions.create("transform",o),R&&R(e)}),_=i(v),D=e=>{w&&w(d.current,e)};return r.jsx(z,{appear:F,in:E,nodeRef:d,onEnter:A,onEntered:I,onEntering:k,onExit:U,onExited:_,onExiting:L,addEndListener:D,timeout:x,...C,children:(e,{ownerState:o,...s})=>g.cloneElement(u,{style:{transform:"scale(0)",visibility:e==="exited"&&!E?"hidden":void 0,...X[e],...f,...u.props.style},ref:P,...s})})}),$=(n,y)=>{const[{in:h},t]=M();return r.jsxs(a,{sx:{width:300,height:200,display:"flex",flexDirection:"column",alignItems:"center",justifyContent:"center"},children:[r.jsx(O,{onClick:()=>{t({in:!h})},sx:{mb:2},children:"Toggle"}),r.jsx(n,{})]})},ve={title:"Utils/Transitions",parameters:{layout:"centered",docs:{description:{component:`Material UI provides simple wrapper components for CSS transitions. They help you animate the appearance and disappearance of elements with a consistent API. For more details, see: https://mui.com/material-ui/transitions/
        `}}},decorators:[$],argTypes:{open:{control:"boolean"},timeout:{control:{type:"number"}},direction:{control:{type:"select"},options:["left","right","up","down"]}},tags:["wrapper"]},c={render:({...n})=>r.jsx(q,{...n,children:r.jsx(a,{sx:{width:100,height:100,bgcolor:"primary.main",borderRadius:2}})}),name:"Fade",parameters:{docs:{description:{story:"Fade applies a fade-in and fade-out effect to its children using opacity transitions."}}},args:{in:!0,timeout:500}},m={render:({...n})=>r.jsx(H,{...n,children:r.jsx(a,{sx:{width:100,height:100,bgcolor:"secondary.main",borderRadius:2}})}),name:"Grow",parameters:{docs:{description:{story:"Grow scales the child from 0% to 100% of its size and reverses the animation on exit."}}}},p={render:({...n})=>r.jsx(J,{...n,children:r.jsx(a,{sx:{width:100,height:100,bgcolor:"success.main",borderRadius:2}})}),name:"Slide",args:{direction:"up"},parameters:{docs:{description:{story:"Slide moves the child element into or out of the screen in the specified direction."}}}},l={render:({...n})=>r.jsx(Y,{...n,children:r.jsx(a,{sx:{width:100,height:100,bgcolor:"error.main",borderRadius:2}})}),name:"Zoom",parameters:{docs:{description:{story:"Zoom expands or contracts the child from its center point, creating a zoom effect."}}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Fade {...props}>
        <Box sx={{
        width: 100,
        height: 100,
        bgcolor: "primary.main",
        borderRadius: 2
      }} />
      </Fade>;
  },
  name: "Fade",
  parameters: {
    docs: {
      description: {
        story: "Fade applies a fade-in and fade-out effect to its children using opacity transitions."
      }
    }
  },
  args: {
    in: true,
    timeout: 500
  }
}`,...c.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => <Grow {...props}>
        <Box sx={{
      width: 100,
      height: 100,
      bgcolor: "secondary.main",
      borderRadius: 2
    }} />
      </Grow>,
  name: "Grow",
  parameters: {
    docs: {
      description: {
        story: "Grow scales the child from 0% to 100% of its size and reverses the animation on exit."
      }
    }
  }
}`,...m.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => <Slide {...props}>
        <Box sx={{
      width: 100,
      height: 100,
      bgcolor: "success.main",
      borderRadius: 2
    }} />
      </Slide>,
  name: "Slide",
  args: {
    direction: "up"
  },
  parameters: {
    docs: {
      description: {
        story: "Slide moves the child element into or out of the screen in the specified direction."
      }
    }
  }
}`,...p.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => <Zoom {...props}>
      <Box sx={{
      width: 100,
      height: 100,
      bgcolor: "error.main",
      borderRadius: 2
    }} />
    </Zoom>,
  name: "Zoom",
  parameters: {
    docs: {
      description: {
        story: "Zoom expands or contracts the child from its center point, creating a zoom effect."
      }
    }
  }
}`,...l.parameters?.docs?.source}}};const Be=["FadeStory","GrowStory","SlideStory","ZoomStory"];export{c as FadeStory,m as GrowStory,p as SlideStory,l as ZoomStory,Be as __namedExportsOrder,ve as default};
