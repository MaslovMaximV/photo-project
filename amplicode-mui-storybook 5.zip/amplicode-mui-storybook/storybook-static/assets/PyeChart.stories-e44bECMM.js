import{j as e}from"./iframe-U1MoWpc_.js";import{P as r}from"./PieChart-DGnPIb03.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTimeout-CYujZKVu.js";import"./ChartsWrapper-DkCjomDX.js";import"./useId-vd1Ifx8D.js";import"./useEventCallback-ELgNMDCa.js";import"./ownerWindow-HkKU3E4x.js";import"./ownerDocument-DW-IO8s5.js";import"./useForkRef-OOgs0334.js";import"./DefaultPropsProvider-Drazl94h.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./index-BY2wC7yI.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./isDeepEqual-CWgvpjyk.js";import"./Popper-ueJFtwYo.js";import"./index-BnGSTqEq.js";import"./Portal-Dc2RZP_l.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./useSlotProps-BHg2pJuT.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useTheme-CMyrA-7l.js";import"./IconButton-DY_fXBCG.js";import"./ButtonBase-BUPfvClL.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./Button-Z4BDc59h.js";import"./fastObjectShallowCompare-DvmlZRcg.js";import"./ChartDataProvider-BDwpJE3L.js";const T={title:"DataDisplay/Charts/PieChart",component:r,parameters:{layout:"centered",docs:{description:{component:"PieChart visualizes parts of a whole using slices."}},studioMeta:{npmDeps:[{name:"@mui/x-charts",version:"8"}]}}},t=[{value:10,label:"A"},{value:15,label:"B"},{value:20,label:"C"}],s={render:()=>e.jsx(r,{series:[{data:t}],width:400,height:300}),parameters:{docs:{description:{story:"Basic PieChart with three slices and default styling."}}}},a={render:()=>e.jsx(r,{series:[{data:t}],width:400,height:300}),parameters:{docs:{description:{story:"Highlights a slice on hover while fading out others."}}}},i={render:()=>e.jsx(r,{series:[{data:t,innerRadius:60}],width:400,height:300}),parameters:{docs:{description:{story:"PieChart with inner radius to create a donut effect."}}}},o={render:()=>e.jsx(r,{series:[{data:t,cx:200,cy:150,outerRadius:100,paddingAngle:5,cornerRadius:5}],colors:["#FF6B6B","#6BCB77","#4D96FF"],width:400,height:300}),parameters:{docs:{description:{story:"PieChart with custom slice colors and rounded corners."}}}},n={render:()=>e.jsx(r,{series:[{data:t,arcLabel:d=>`${d.label} (${d.value})`}],width:400,height:300}),parameters:{docs:{description:{story:"Adds custom arc labels with values."}}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <PieChart series={[{
      data: sampleData
    }]} width={400} height={300} />;
  },
  parameters: {
    docs: {
      description: {
        story: "Basic PieChart with three slices and default styling."
      }
    }
  }
}`,...s.parameters?.docs?.source}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <PieChart series={[{
      data: sampleData
    }]} width={400} height={300} />;
  },
  parameters: {
    docs: {
      description: {
        story: "Highlights a slice on hover while fading out others."
      }
    }
  }
}`,...a.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <PieChart series={[{
      data: sampleData,
      innerRadius: 60
    }]} width={400} height={300} />;
  },
  parameters: {
    docs: {
      description: {
        story: "PieChart with inner radius to create a donut effect."
      }
    }
  }
}`,...i.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <PieChart series={[{
      data: sampleData,
      cx: 200,
      cy: 150,
      outerRadius: 100,
      paddingAngle: 5,
      cornerRadius: 5
    }]} colors={['#FF6B6B', '#6BCB77', '#4D96FF']} width={400} height={300} />;
  },
  parameters: {
    docs: {
      description: {
        story: "PieChart with custom slice colors and rounded corners."
      }
    }
  }
}`,...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <PieChart series={[{
      data: sampleData,
      arcLabel: item => \`\${item.label} (\${item.value})\`
    }]} width={400} height={300} />;
  },
  parameters: {
    docs: {
      description: {
        story: "Adds custom arc labels with values."
      }
    }
  }
}`,...n.parameters?.docs?.source}}};const U=["Basic","WithHighlightedSlice","DonutChart","WithCustomColors","CustomLabels"];export{s as Basic,n as CustomLabels,i as DonutChart,o as WithCustomColors,a as WithHighlightedSlice,U as __namedExportsOrder,T as default};
