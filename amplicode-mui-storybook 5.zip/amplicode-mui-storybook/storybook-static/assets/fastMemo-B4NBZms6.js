import{r}from"./iframe-U1MoWpc_.js";import{f as t}from"./fastObjectShallowCompare-DvmlZRcg.js";function e(o){return r.memo(o,t)}export{e as f};
