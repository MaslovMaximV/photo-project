import{j as r,r as d}from"./iframe-U1MoWpc_.js";import{S as n}from"./Switch-BSvuxx3D.js";import{F as p}from"./FormControlLabel-Bq-a8dVL.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./SwitchBase-9AkWq_7-.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useFormControl-q410XUqr.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useControlled-CeZ7-hqo.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./memoTheme-BNYDzr43.js";import"./formControlState-Dq1zat_P.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";const _={title:"Inputs/Switch",component:n,tags:["autodocs"],parameters:{layout:"centered",docs:{description:{component:"Switches toggle the state of a single setting on or off."}}},args:{size:"medium"},argTypes:{checked:{control:"boolean",description:"If `true`, the component is checked."},defaultChecked:{control:"boolean",description:"The default checked state. Used when the component is not controlled."},disabled:{control:"boolean",description:"If `true`, the switch will be disabled."},required:{control:"boolean",description:"If `true`, the input element is required."},color:{control:"select",options:["primary","secondary","error","info","success","warning"],description:"The color of the component."},size:{control:"select",options:["small","medium"],description:"The size of the switch."},edge:{control:"select",options:[!1,"start","end"],description:"If given, adjusts the margin to accommodate positioning."}}},e={render:()=>r.jsx(n,{}),parameters:{docs:{description:{story:"Switches toggle the state of a single setting on or off."}}}},t={render:()=>r.jsx(p,{control:r.jsx(n,{defaultChecked:!0}),label:"Label"}),parameters:{docs:{description:{story:"Switches toggle the state of a single setting on or off."}}}},o={render:()=>{const[s,c]=d.useState(!0),i=a=>{c(a.target.checked)};return r.jsx(n,{checked:s,onChange:i})},parameters:{docs:{description:{story:"Switches toggle the state of a single setting on or off."}}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Switch />;
  },
  parameters: {
    docs: {
      description: {
        story: "Switches toggle the state of a single setting on or off."
      }
    }
  }
}`,...e.parameters?.docs?.source}}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <FormControlLabel control={<Switch defaultChecked />} label="Label" />;
  },
  parameters: {
    docs: {
      description: {
        story: "Switches toggle the state of a single setting on or off."
      }
    }
  }
}`,...t.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [checked, setChecked] = useState(true);
    const handleChange = (event: React.ChangeEvent<HTMLInputElement>) => {
      setChecked(event.target.checked);
    };
    return <Switch checked={checked} onChange={handleChange} />;
  },
  parameters: {
    docs: {
      description: {
        story: "Switches toggle the state of a single setting on or off."
      }
    }
  }
}`,...o.parameters?.docs?.source}}};const H=["Basic","Labeled","Controlled"];export{e as Basic,o as Controlled,t as Labeled,H as __namedExportsOrder,_ as default};
