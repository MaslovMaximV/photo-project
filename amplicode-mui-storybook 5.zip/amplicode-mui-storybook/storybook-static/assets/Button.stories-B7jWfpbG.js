import{j as n}from"./iframe-U1MoWpc_.js";import{A as B,S as g,C as S,a as x}from"./Send-D0pdmDNQ.js";import{B as e}from"./Button-Z4BDc59h.js";import{s as O}from"./DefaultPropsProvider-Drazl94h.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";const o={AlarmOnIcon:n.jsx(B,{}),AlarmOffIcon:n.jsx(x,{}),CloudUploadIcon:n.jsx(S,{}),SendIcon:n.jsx(g,{})},H={title:"Inputs/Button",component:e,parameters:{layout:"centered"},decorators:[],argTypes:{variant:{control:"select",options:["contained","outlined","text"]},disabled:{control:"boolean"},color:{control:"select",options:["inherit","primary","secondary","success","error","info","warning"]},size:{control:"select",options:["small","medium","large"]}},args:{variant:"contained",disabled:!1,color:"primary",size:"medium"}},s={render:({variant:r,...t})=>n.jsx(e,{variant:r,...t,children:"Button"}),args:{variant:"text"}},a={render:({variant:r,...t})=>n.jsx(e,{variant:r,...t,children:"Button"}),parameters:{},args:{variant:"contained"}},p={render:({variant:r,...t})=>n.jsx(e,{variant:r,...t,children:"Button"}),parameters:{},args:{variant:"outlined"}},c={render:({disabled:r,...t})=>n.jsx(e,{disabled:r,...t,children:"Button"}),args:{disabled:!0}},d={render:({color:r,...t})=>n.jsx(e,{color:r,...t,children:"Button"}),args:{color:"secondary"}},i={render:({size:r,...t})=>n.jsx(e,{size:r,...t,children:"Button"}),args:{size:"large"}},u={render:({startIcon:r,...t})=>n.jsx(e,{startIcon:r,...t,children:"Button"}),argTypes:{startIcon:{options:Object.keys(o),mapping:o,control:{type:"select"}}},args:{startIcon:n.jsx(B,{})}},m={render:({endIcon:r,...t})=>n.jsx(e,{endIcon:r,...t,children:"Button"}),argTypes:{endIcon:{options:Object.keys(o),mapping:o,control:{type:"select"}}},args:{endIcon:n.jsx(B,{})}},l={render:({...r})=>{const t=O("input")({display:"none"});return n.jsxs(e,{component:"label",tabIndex:-1,startIcon:n.jsx(S,{}),...r,children:["Upload file",n.jsx(t,{type:"file"})]})}},y={render:({endIcon:r,...t})=>n.jsx(e,{endIcon:r,...t,children:"Send"}),args:{endIcon:n.jsx(g,{})},parameters:{controls:{exclude:["endIcon"]}}},I={render:({startIcon:r})=>n.jsx(e,{startIcon:r,children:"Button"}),argTypes:{startIcon:{options:Object.keys(o),mapping:o,control:{type:"select"}}},args:{startIcon:n.jsx(B,{})}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    ...props
  }: ButtonOwnProps) => {
    return <Button variant={variant} {...props}>Button</Button>;
  },
  args: {
    variant: "text"
  }
}`,...s.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...s.parameters?.docs?.description}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    ...props
  }: ButtonOwnProps) => {
    return <Button variant={variant} {...props}>Button</Button>;
  },
  parameters: {},
  args: {
    variant: "contained"
  }
}`,...a.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...a.parameters?.docs?.description}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    ...props
  }: ButtonOwnProps) => {
    return <Button variant={variant} {...props}>Button</Button>;
  },
  parameters: {},
  args: {
    variant: "outlined"
  }
}`,...p.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...p.parameters?.docs?.description}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: ({
    disabled,
    ...props
  }: ButtonOwnProps) => {
    return <Button disabled={disabled} {...props}>Button</Button>;
  },
  args: {
    disabled: true
  }
}`,...c.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...c.parameters?.docs?.description}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: ({
    color,
    ...props
  }: ButtonOwnProps) => {
    return <Button color={color} {...props}>Button</Button>;
  },
  args: {
    color: "secondary"
  }
}`,...d.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...d.parameters?.docs?.description}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: ({
    size,
    ...props
  }: ButtonOwnProps) => {
    return <Button size={size} {...props}>Button</Button>;
  },
  args: {
    size: "large"
  }
}`,...i.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...i.parameters?.docs?.description}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: ({
    startIcon,
    ...props
  }: ButtonOwnProps) => {
    return <Button startIcon={startIcon} {...props}>Button</Button>;
  },
  argTypes: {
    startIcon: {
      options: Object.keys(ICONS_MAP),
      mapping: ICONS_MAP,
      control: {
        type: "select"
      }
    }
  },
  args: {
    startIcon: <AlarmOnIcon />
  }
}`,...u.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...u.parameters?.docs?.description}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: ({
    endIcon,
    ...props
  }: ButtonOwnProps) => {
    return <Button endIcon={endIcon} {...props}>Button</Button>;
  },
  argTypes: {
    endIcon: {
      options: Object.keys(ICONS_MAP),
      mapping: ICONS_MAP,
      control: {
        type: "select"
      }
    }
  },
  args: {
    endIcon: <AlarmOnIcon />
  }
}`,...m.parameters?.docs?.source},description:{story:"Simple ready to use story with arguments passed to props",...m.parameters?.docs?.description}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }: ButtonOwnProps) => {
    const VisuallyHiddenInput = styled('input')({
      display: 'none'
    });
    return <Button component="label" tabIndex={-1} startIcon={<CloudUploadIcon />} {...props}>
          Upload file
          <VisuallyHiddenInput type="file" />
        </Button>;
  }
}`,...l.parameters?.docs?.source},description:{story:"Ready to use story with inlined props",...l.parameters?.docs?.description}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: ({
    endIcon,
    ...props
  }: ButtonOwnProps) => {
    return <Button endIcon={endIcon} {...props}>
          Send
        </Button>;
  },
  args: {
    endIcon: <SendIcon />
  },
  parameters: {
    controls: {
      exclude: ['endIcon']
    }
  }
}`,...y.parameters?.docs?.source},description:{story:"Ready to use story with arguments passed to props",...y.parameters?.docs?.description}}};I.parameters={...I.parameters,docs:{...I.parameters?.docs,source:{originalSource:`{
  render: ({
    startIcon
  }: ButtonOwnProps) => {
    return <Button startIcon={startIcon}>Button</Button>;
  },
  argTypes: {
    startIcon: {
      options: Object.keys(ICONS_MAP),
      mapping: ICONS_MAP,
      control: {
        type: "select"
      }
    }
  },
  args: {
    startIcon: <AlarmOnIcon />
  }
}`,...I.parameters?.docs?.source}}};const R=["Text","Contained","Outlined","Diabled","Color","Sizes","StartIcon","EndIcon","UploadButton","SendButton","GenericIconButton"];export{d as Color,a as Contained,c as Diabled,m as EndIcon,I as GenericIconButton,p as Outlined,y as SendButton,i as Sizes,u as StartIcon,s as Text,l as UploadButton,R as __namedExportsOrder,H as default};
