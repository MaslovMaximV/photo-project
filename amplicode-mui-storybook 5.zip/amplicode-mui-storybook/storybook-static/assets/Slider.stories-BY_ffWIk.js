import{r as c,j as t}from"./iframe-U1MoWpc_.js";import{S as s}from"./Slider-43KTez9G.js";import{B as d}from"./Box-nnrC_EdN.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./index-BnGSTqEq.js";import"./useControlled-CeZ7-hqo.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./ownerDocument-DW-IO8s5.js";import"./mergeSlotProps-A8yMhZdW.js";import"./visuallyHidden-Dan1xhjv.js";import"./isFocusVisible-B8k4qzLc.js";import"./isHostComponent-DVu5iVWx.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useSlotProps-BHg2pJuT.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";const R={title:"Inputs/Slider",component:s,tags:["autodocs"],parameters:{layout:"centered",docs:{description:{component:"The Slider component allows users to select a value or range from a given range by dragging a thumb."}}},args:{value:30,min:0,max:100,step:1,marks:!1,disabled:!1,size:"medium",orientation:"horizontal"},argTypes:{value:{control:"number",description:"The current value of the slider"},min:{control:"number",description:"Minimum allowed value"},max:{control:"number",description:"Maximum allowed value"},step:{control:"number",description:"The granularity the slider can step through values"},marks:{control:"boolean",description:"Display tick marks along the slider track"},disabled:{control:"boolean",description:"Disable the slider"},size:{control:"select",options:["small","medium"],description:"The size of the slider"},orientation:{control:"select",options:["horizontal","vertical"],description:"The orientation of the slider"},valueLabelDisplay:{control:"select",options:["auto","on","off","default"],mapping:{default:void 0,auto:"auto",on:"on",off:"off"}}}},o={render:()=>{const[e,a]=c.useState(30),n=(p,r)=>{a(r)};return t.jsx(d,{sx:{width:200},children:t.jsx(s,{"aria-label":"Volume",value:e,onChange:n})})},parameters:{docs:{description:{story:"Continuous sliders allow users to select a value along a subjective range."}}}},l={render:()=>{const[e,a]=c.useState(30),n=(p,r)=>{a(r)};return t.jsx(d,{sx:{width:300},children:t.jsx(s,{value:e,onChange:n,defaultValue:30,valueLabelDisplay:"auto",shiftStep:30,step:10,marks:!0,min:10,max:110})})},parameters:{docs:{description:{story:"Discrete sliders can be adjusted to a specific value by referencing its value indicator. You can generate a mark for each step with marks={true}."}}}},h=[{value:0,label:"0°C"},{value:20,label:"20°C"},{value:37,label:"37°C"},{value:100,label:"100°C"}];function m(e){return`${e}°C`}const i={render:()=>{const[e,a]=c.useState(30);return t.jsx(d,{sx:{width:300},children:t.jsx(s,{defaultValue:20,getAriaValueText:m,step:null,valueLabelDisplay:"auto",marks:h})})},parameters:{docs:{description:{story:"You can restrict the selectable values to those provided with the marks prop with step={null}."}}}},u={render:()=>{const[e,a]=c.useState([20,37]),n=(p,r)=>{a(r)};return t.jsx(d,{sx:{width:300},children:t.jsx(s,{getAriaLabel:()=>"Temperature range",value:e,onChange:n,valueLabelDisplay:"auto",getAriaValueText:m})})},parameters:{docs:{description:{story:"You can restrict the selectable values to those provided with the marks prop with step={null}."}}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [value, setValue] = useState<number>(30);
    const handleChange = (event: Event, newValue: number | number[]) => {
      setValue(newValue as number);
    };
    return <Box sx={{
      width: 200
    }}>
        <Slider aria-label="Volume" value={value} onChange={handleChange} />
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "Continuous sliders allow users to select a value along a subjective range."
      }
    }
  }
}`,...o.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [value, setValue] = useState<number>(30);
    const handleChange = (event: Event, newValue: number | number[]) => {
      setValue(newValue as number);
    };
    return <Box sx={{
      width: 300
    }}>
        <Slider value={value} onChange={handleChange} defaultValue={30} valueLabelDisplay="auto" shiftStep={30} step={10} marks min={10} max={110} />
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "Discrete sliders can be adjusted to a specific value by referencing its value indicator. You can generate a mark for each step with marks={true}."
      }
    }
  }
}`,...l.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [value, setValue] = useState<number>(30);
    const handleChange = (event: Event, newValue: number | number[]) => {
      setValue(newValue as number);
    };
    return <Box sx={{
      width: 300
    }}>
        <Slider defaultValue={20} getAriaValueText={valuetext} step={null} valueLabelDisplay="auto" marks={marks} />
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "You can restrict the selectable values to those provided with the marks prop with step={null}."
      }
    }
  }
}`,...i.parameters?.docs?.source}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [value, setValue] = useState<number[]>([20, 37]);
    const handleChange = (event: Event, newValue: number | number[]) => {
      setValue(newValue as number[]);
    };
    return <Box sx={{
      width: 300
    }}>
        <Slider getAriaLabel={() => "Temperature range"} value={value} onChange={handleChange} valueLabelDisplay="auto" getAriaValueText={valuetext} />
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "You can restrict the selectable values to those provided with the marks prop with step={null}."
      }
    }
  }
}`,...u.parameters?.docs?.source}}};const M=["Continuous","Discrete","Restricted","Range"];export{o as Continuous,l as Discrete,u as Range,i as Restricted,M as __namedExportsOrder,R as default};
