import{j as r,u as a,r as m}from"./iframe-U1MoWpc_.js";import{B as c}from"./Backdrop-DKjtt3hE.js";import{B as l}from"./Button-Z4BDc59h.js";import{C as d}from"./CircularProgress-Bb4IBCi9.js";import{T as u}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./DefaultPropsProvider-Drazl94h.js";import"./Fade-P8xhlTFS.js";import"./useTheme-CMyrA-7l.js";import"./useTheme-DUWNGOj_.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";const k=e=>{const[{open:n},o]=a(),p=()=>{o({open:!1})};m.useEffect(()=>{o({onClick:p})},[]);const i=()=>{o({open:!0})};return r.jsxs(r.Fragment,{children:[r.jsx(l,{variant:"contained",onClick:i,children:"Open Backdrop"}),r.jsx(e,{open:n,onClick:p})]})},K={title:"Feedback/Backdrop",component:c,parameters:{layout:"centered",controls:{exclude:["onClick"]}},decorators:[k],argTypes:{},args:{}},t={render:({open:e,onClick:n,...o})=>r.jsx(c,{sx:{color:"#fff"},open:e,onClick:n,children:r.jsx(d,{color:"inherit"})}),args:{open:!1,onClick:()=>{}}},s={render:({open:e,onClick:n,children:o,...p})=>r.jsx(c,{sx:{background:"#fff"},open:e,onClick:n,children:o}),args:{open:!1,onClick:()=>{},children:r.jsx(u,{children:"Custom content"})}};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    open,
    onClick,
    ...props
  }) => {
    return <Backdrop sx={{
      color: '#fff'
    }} open={open} onClick={onClick}>
        <CircularProgress color="inherit" />
      </Backdrop>;
  },
  args: {
    open: false,
    onClick: () => {/** handle click */}
  }
}`,...t.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    open,
    onClick,
    children,
    ...props
  }) => {
    return <Backdrop sx={{
      background: '#fff'
    }} open={open} onClick={onClick}>
        {children}
      </Backdrop>;
  },
  args: {
    open: false,
    onClick: () => {/** handle click */},
    children: <Typography>Custom content</Typography>
  }
}`,...s.parameters?.docs?.source}}};const L=["WithProgress","WithCustomContent"];export{s as WithCustomContent,t as WithProgress,L as __namedExportsOrder,K as default};
