import{j as e,a as d}from"./iframe-U1MoWpc_.js";import{S as x}from"./Stack-DsCsj_BD.js";import{B as r}from"./Box-nnrC_EdN.js";import{T as h}from"./Toolbar-CUdeLhnu.js";import{T as i}from"./Typography-NbeDhiLn.js";import{C as p}from"./Container-BslDs3ZR.js";import{A as s,a as o,b as a}from"./AccordionSummary-CWABZDsO.js";import{A as l}from"./ArrowDropDown-ChzEnR_A.js";import"./preload-helper-D9Z9MdNV.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./styled-DKEkqMyo.js";import"./extendSxProp-Cl0Joej-.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./useTheme-DUWNGOj_.js";import"./memoTheme-BNYDzr43.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useControlled-CeZ7-hqo.js";import"./useTheme-CMyrA-7l.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./Paper-BtmMZDrw.js";import"./ButtonBase-BUPfvClL.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./createSvgIcon-Ck9VyYEl.js";const V={title:"Layout/Templates/ContainerLayout",parameters:{layout:"fullscreen"}},n={render:({...c})=>e.jsxs(x,{direction:"column",sx:t=>({width:"100%",height:d("100vh")}),children:[e.jsx(r,{sx:t=>({display:"flex",alignItems:"center",minHeight:t.spacing(10),background:"#fff",position:"sticky",width:"100%",top:0,left:0,zIndex:9}),children:e.jsx(h,{children:e.jsx(i,{variant:"h6",noWrap:!0,component:"div",color:"#3170de",children:"Header"})})}),e.jsx(r,{sx:t=>({flex:1,borderLeft:"1px solid #3170de",borderRight:"1px solid #3170de"}),children:e.jsx(p,{fixed:!0,sx:t=>({height:"100%"}),children:d(e.jsx(r,{sx:t=>({height:"100%",boxSizing:"border-box",background:"#fff"}),children:e.jsx(m,{})}))})}),e.jsx(r,{sx:t=>({boxShadow:"inset 0 0 12px 1px #3170de",py:2,background:"#fff"}),children:e.jsx(i,{variant:"subtitle2",textAlign:"center",children:"Footer ©"})})]})},m=()=>e.jsxs(r,{sx:c=>({p:2}),children:[e.jsx(i,{variant:"h6",children:"Container layout is a classic web page layout"}),e.jsx(i,{variant:"body2",children:"This type of layout is often used for creating clean and functional web page designs. Its main elements are:"}),e.jsxs(r,{mt:2,children:[e.jsxs(s,{children:[e.jsx(o,{expandIcon:e.jsx(l,{}),children:e.jsx(i,{variant:"subtitle2",children:"Floating Header"})}),e.jsx(a,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Fixed at the top of the browser window."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Always visible, regardless of page scrolling."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Typically contains a logo, navigation menu, or search bar."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Achieved using the position: fixed; property."})})]})]})]})})]}),e.jsxs(s,{children:[e.jsx(o,{expandIcon:e.jsx(l,{}),children:e.jsx(i,{variant:"subtitle2",children:"Centered Content Area"})}),e.jsx(a,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Occupies the main space between the header and the footer."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Horizontally and vertically centered in the remaining window space."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"May have fixed width and height or use proportional dimensions."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Scrollable if the content overflows."})})]})]})]})})]}),e.jsxs(s,{children:[e.jsx(o,{expandIcon:e.jsx(l,{}),children:e.jsx(i,{variant:"subtitle2",children:"Footer Stuck to the Bottom"})}),e.jsx(a,{children:e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Position:"}),e.jsx("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Fixed at the bottom of the browser window."})})})]}),e.jsxs("li",{children:[e.jsx(i,{variant:"subtitle2",children:"Features:"}),e.jsxs("ul",{style:{margin:0,padding:0,paddingLeft:"16px"},children:[e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Always at the bottom of the window, regardless of content height."})}),e.jsx("li",{children:e.jsx(i,{variant:"subtitle2",children:"Often contains copyright information, links, or contact details."})})]})]})]})})]})]})]});n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Stack direction="column" sx={theme => ({
      width: "100%",
      height: replaceOnGenerate("100vh", "100vh")
    })}>
        <Box sx={theme => ({
        display: 'flex',
        alignItems: 'center',
        minHeight: theme.spacing(10),
        background: "#fff",
        // boxShadow: "inset 0 0 12px 0px #3170de",
        position: "sticky",
        width: "100%",
        top: 0,
        left: 0,
        zIndex: 9
      })}>
          <Toolbar>
            <Typography variant="h6" noWrap component="div" color={"#3170de"}>
              Header
            </Typography>
          </Toolbar>
        </Box>
        <Box sx={theme => ({
        flex: 1,
        borderLeft: "1px solid #3170de",
        borderRight: "1px solid #3170de"
      })}>
          <Container fixed sx={theme => ({
          height: "100%"
        })}>
            {replaceOnGenerate(<Box sx={theme => ({
            height: "100%",
            boxSizing: "border-box",
            background: "#fff"
          })}>
                <JustLayoutStoryDescription />
              </Box>, <Typography variant="subtitle2" textAlign="center">
                Content
              </Typography>)}
          </Container>
        </Box>
        <Box sx={theme => ({
        boxShadow: "inset 0 0 12px 1px #3170de",
        py: 2,
        background: "#fff"
      })}>
          <Typography variant={"subtitle2"} textAlign={"center"}>
            Footer ©
          </Typography>
        </Box>
      </Stack>;
  }
}`,...n.parameters?.docs?.source}}};const X=["Default"];export{n as Default,X as __namedExportsOrder,V as default};
