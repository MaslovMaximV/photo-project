import{j as e}from"./iframe-U1MoWpc_.js";import{L as t}from"./Link-B50BWoEZ.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useTheme-DUWNGOj_.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./Typography-NbeDhiLn.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./isFocusVisible-B8k4qzLc.js";const L={title:"DataDisplay/Link",component:t,parameters:{layout:"centered"},decorators:[]},r={render:()=>e.jsx(t,{href:"#",children:"Basic link component"})};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: () => {
    return <Link href="#">Basic link component</Link>;
  }
}`,...r.parameters?.docs?.source}}};const D=["Default"];export{r as Default,D as __namedExportsOrder,L as default};
