import{r}from"./iframe-U1MoWpc_.js";const t=parseInt(r.version,10);export{t as r};
