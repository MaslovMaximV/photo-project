import{c as t}from"./DefaultPropsProvider-Drazl94h.js";const s=t();export{s};
