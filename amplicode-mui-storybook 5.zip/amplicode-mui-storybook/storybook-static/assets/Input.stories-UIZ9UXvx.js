import{j as i}from"./iframe-U1MoWpc_.js";import{I as e}from"./Input-DC-6me1o.js";import"./preload-helper-D9Z9MdNV.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./isHostComponent-DVu5iVWx.js";import"./formControlState-Dq1zat_P.js";import"./useFormControl-q410XUqr.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./useTheme-DUWNGOj_.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./utils-DoM3o7-Q.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./ownerWindow-HkKU3E4x.js";import"./ownerDocument-DW-IO8s5.js";import"./debounce-Be36O1Ab.js";const P={title:"Inputs/Input",component:e,parameters:{layout:"centered",controls:{exclude:["options","renderInput"]}},decorators:[],argTypes:{disabled:{control:"boolean"},error:{control:"boolean"},size:{control:"select",options:["small","medium","large"]}},args:{disabled:!1,error:!1,size:"small",defaultValue:"Owner",placeholder:"Placeholder"}},r={render:({size:o,disabled:t,defaultValue:a,placeholder:s,error:p,...l})=>i.jsx(e,{size:o,disabled:t,defaultValue:a,placeholder:s,error:p,...l})};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: ({
    size,
    disabled,
    defaultValue,
    placeholder,
    error,
    ...props
  }) => {
    return <Input size={size} disabled={disabled} defaultValue={defaultValue} placeholder={placeholder} error={error} {...props} />;
  }
}`,...r.parameters?.docs?.source}}};const R=["Basic"];export{r as Basic,R as __namedExportsOrder,P as default};
