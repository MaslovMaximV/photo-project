import{r as e}from"./iframe-U1MoWpc_.js";const o=s=>{const r=e.useRef({});return e.useEffect(()=>{r.current=s}),r.current};export{o as u};
