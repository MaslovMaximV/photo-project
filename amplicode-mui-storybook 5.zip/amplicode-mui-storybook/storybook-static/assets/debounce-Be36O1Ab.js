function i(o,u=166){let e;function t(...c){const n=()=>{o.apply(this,c)};clearTimeout(e),e=setTimeout(n,u)}return t.clear=()=>{clearTimeout(e)},t}export{i as d};
