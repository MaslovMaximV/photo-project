import{j as r,G as s}from"./iframe-U1MoWpc_.js";import{G as o}from"./Grid-DSEZCbod.js";import{B as p}from"./Box-nnrC_EdN.js";import{P as a}from"./Paper-BtmMZDrw.js";import{T as c}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./styled-DKEkqMyo.js";import"./extendSxProp-Cl0Joej-.js";import"./isMuiElement-BH3XSIgM.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./memoTheme-BNYDzr43.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const b={title:"Layout/Grid",component:o,parameters:{layout:"centered",controls:{exclude:["divider"]}},decorators:[t=>r.jsx(p,{width:500,children:t()})],argTypes:{spacing:{control:"select",options:[1,2,3,4,5,6,7,8]},rowSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columnSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columns:{control:"select",options:[7,12,16,20,24]}},args:{spacing:2},tags:["wrapper"]},n={render:({...t})=>r.jsx(o,{size:{xs:12,lg:3},children:r.jsx(s.Exclude,{children:r.jsx(a,{children:r.jsx(c,{variant:"body1",textAlign:"center",p:2,children:"Component to wrap with Grid item"})})})}),decorators:[t=>{const e=new Array(10).fill(1).map((m,i)=>i+1);return r.jsx(o,{container:!0,spacing:2,children:e.map(()=>t())})}]};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Grid size={{
      xs: 12,
      lg: 3
    }}>
        <GenerationInstructions.Exclude>
          <Paper>
            <Typography variant="body1" textAlign={"center"} p={2}>
              Component to wrap with Grid item
            </Typography>
          </Paper>
        </GenerationInstructions.Exclude>
      </Grid>;
  },
  decorators: [Story => {
    const gridItems = new Array(10).fill(1).map((_, index) => index + 1);
    return <Grid container spacing={2}>
          {gridItems.map(() => {
        return Story();
      })}
        </Grid>;
  }]
}`,...n.parameters?.docs?.source}}};const z=["Item"];export{n as Item,z as __namedExportsOrder,b as default};
