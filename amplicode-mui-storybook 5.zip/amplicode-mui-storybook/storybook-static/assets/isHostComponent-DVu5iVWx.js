function n(t){return typeof t=="string"}export{n as i};
