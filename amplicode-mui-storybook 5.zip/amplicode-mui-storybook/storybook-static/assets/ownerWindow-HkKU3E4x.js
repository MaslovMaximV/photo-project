import{o as n}from"./ownerDocument-DW-IO8s5.js";function t(o){return n(o).defaultView||window}export{t as o};
