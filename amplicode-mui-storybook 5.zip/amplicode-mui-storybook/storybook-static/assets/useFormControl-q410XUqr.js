import{r as o}from"./iframe-U1MoWpc_.js";const t=o.createContext(void 0);function e(){return o.useContext(t)}export{t as F,e as u};
