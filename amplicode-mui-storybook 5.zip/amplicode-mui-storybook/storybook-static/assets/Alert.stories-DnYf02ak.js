import{j as t,r as W,G as re}from"./iframe-U1MoWpc_.js";import{g as te,a as ne,c as se,b as H}from"./createTheme-CB0G2ADO.js";import{m as oe}from"./memoTheme-BNYDzr43.js";import{u as p}from"./useSlot-ntrDZa7C.js";import{c as b}from"./createSimplePaletteValueFilter-bm0fmN_7.js";import{c as w}from"./createSvgIcon-Ck9VyYEl.js";import{C as ae}from"./Close-DCGMSXuw.js";import{u as ie,s as I,a as le}from"./DefaultPropsProvider-Drazl94h.js";import{I as ce}from"./IconButton-DY_fXBCG.js";import{P as de}from"./Paper-BtmMZDrw.js";import{B as L}from"./Button-Z4BDc59h.js";import"./preload-helper-D9Z9MdNV.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./useTheme-CMyrA-7l.js";import"./useTheme-DUWNGOj_.js";function pe(e){return ne("MuiAlert",e)}const $=te("MuiAlert",["root","action","icon","message","filled","colorSuccess","colorInfo","colorWarning","colorError","filledSuccess","filledInfo","filledWarning","filledError","outlined","outlinedSuccess","outlinedInfo","outlinedWarning","outlinedError","standard","standardSuccess","standardInfo","standardWarning","standardError"]),ue=w(t.jsx("path",{d:"M20,12A8,8 0 0,1 12,20A8,8 0 0,1 4,12A8,8 0 0,1 12,4C12.76,4 13.5,4.11 14.2, 4.31L15.77,2.74C14.61,2.26 13.34,2 12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0, 0 22,12M7.91,10.08L6.5,11.5L11,16L21,6L19.59,4.58L11,13.17L7.91,10.08Z"})),ge=w(t.jsx("path",{d:"M12 5.99L19.53 19H4.47L12 5.99M12 2L1 21h22L12 2zm1 14h-2v2h2v-2zm0-6h-2v4h2v-4z"})),me=w(t.jsx("path",{d:"M11 15h2v2h-2zm0-8h2v6h-2zm.99-5C6.47 2 2 6.48 2 12s4.47 10 9.99 10C17.52 22 22 17.52 22 12S17.52 2 11.99 2zM12 20c-4.42 0-8-3.58-8-8s3.58-8 8-8 8 3.58 8 8-3.58 8-8 8z"})),ve=w(t.jsx("path",{d:"M11,9H13V7H11M12,20C7.59,20 4,16.41 4,12C4,7.59 7.59,4 12,4C16.41,4 20,7.59 20, 12C20,16.41 16.41,20 12,20M12,2A10,10 0 0,0 2,12A10,10 0 0,0 12,22A10,10 0 0,0 22,12A10, 10 0 0,0 12,2M11,17H13V11H11V17Z"})),fe=e=>{const{variant:n,color:s,severity:r,classes:o}=e,i={root:["root",`color${H(s||r)}`,`${n}${H(s||r)}`,`${n}`],icon:["icon"],message:["message"],action:["action"]};return le(i,pe,o)},xe=I(de,{name:"MuiAlert",slot:"Root",overridesResolver:(e,n)=>{const{ownerState:s}=e;return[n.root,n[s.variant],n[`${s.variant}${H(s.color||s.severity)}`]]}})(oe(({theme:e})=>{const n=e.palette.mode==="light"?e.darken:e.lighten,s=e.palette.mode==="light"?e.lighten:e.darken;return{...e.typography.body2,backgroundColor:"transparent",display:"flex",padding:"6px 16px",variants:[...Object.entries(e.palette).filter(b(["light"])).map(([r])=>({props:{colorSeverity:r,variant:"standard"},style:{color:e.vars?e.vars.palette.Alert[`${r}Color`]:n(e.palette[r].light,.6),backgroundColor:e.vars?e.vars.palette.Alert[`${r}StandardBg`]:s(e.palette[r].light,.9),[`& .${$.icon}`]:e.vars?{color:e.vars.palette.Alert[`${r}IconColor`]}:{color:e.palette[r].main}}})),...Object.entries(e.palette).filter(b(["light"])).map(([r])=>({props:{colorSeverity:r,variant:"outlined"},style:{color:e.vars?e.vars.palette.Alert[`${r}Color`]:n(e.palette[r].light,.6),border:`1px solid ${(e.vars||e).palette[r].light}`,[`& .${$.icon}`]:e.vars?{color:e.vars.palette.Alert[`${r}IconColor`]}:{color:e.palette[r].main}}})),...Object.entries(e.palette).filter(b(["dark"])).map(([r])=>({props:{colorSeverity:r,variant:"filled"},style:{fontWeight:e.typography.fontWeightMedium,...e.vars?{color:e.vars.palette.Alert[`${r}FilledColor`],backgroundColor:e.vars.palette.Alert[`${r}FilledBg`]}:{backgroundColor:e.palette.mode==="dark"?e.palette[r].dark:e.palette[r].main,color:e.palette.getContrastText(e.palette[r].main)}}}))]}})),ye=I("div",{name:"MuiAlert",slot:"Icon"})({marginRight:12,padding:"7px 0",display:"flex",fontSize:22,opacity:.9}),Ae=I("div",{name:"MuiAlert",slot:"Message"})({padding:"8px 0",minWidth:0,overflow:"auto"}),he=I("div",{name:"MuiAlert",slot:"Action"})({display:"flex",alignItems:"flex-start",padding:"4px 0 0 16px",marginLeft:"auto",marginRight:-8}),O={success:t.jsx(ue,{fontSize:"inherit"}),warning:t.jsx(ge,{fontSize:"inherit"}),error:t.jsx(me,{fontSize:"inherit"}),info:t.jsx(ve,{fontSize:"inherit"})},a=W.forwardRef(function(n,s){const r=ie({props:n,name:"MuiAlert"}),{action:o,children:i,className:c,closeText:u="Close",color:M,components:T={},componentsProps:E={},icon:P,iconMapping:F=O,onClose:z,role:R="alert",severity:g="success",slotProps:U={},slots:N={},variant:G="standard",...V}=r,l={...r,color:M,severity:g,variant:G,colorSeverity:M||g},m=fe(l),d={slots:{closeButton:T.CloseButton,closeIcon:T.CloseIcon,...N},slotProps:{...E,...U}},[Z,_]=p("root",{ref:s,shouldForwardComponentProp:!0,className:se(m.root,c),elementType:xe,externalForwardedProps:{...d,...V},ownerState:l,additionalProps:{role:R,elevation:0}}),[D,q]=p("icon",{className:m.icon,elementType:ye,externalForwardedProps:d,ownerState:l}),[J,K]=p("message",{className:m.message,elementType:Ae,externalForwardedProps:d,ownerState:l}),[B,k]=p("action",{className:m.action,elementType:he,externalForwardedProps:d,ownerState:l}),[Q,X]=p("closeButton",{elementType:ce,externalForwardedProps:d,ownerState:l}),[Y,ee]=p("closeIcon",{elementType:ae,externalForwardedProps:d,ownerState:l});return t.jsxs(Z,{..._,children:[P!==!1?t.jsx(D,{...q,children:P||F[g]||O[g]}):null,t.jsx(J,{...K,children:i}),o!=null?t.jsx(B,{...k,children:o}):null,o==null&&z?t.jsx(B,{...k,children:t.jsx(Q,{size:"small","aria-label":u,title:u,color:"inherit",onClick:z,...X,children:t.jsx(Y,{fontSize:"small",...ee})})}):null]})}),Ve={title:"Feedback/Alert",component:a,parameters:{layout:"centered",controls:{}},decorators:[],argTypes:{severity:{control:"select",options:["success","info","warning","error"]},variant:{control:"select",options:["standard","filled","outlined"]}},args:{variant:"standard"}},v={render:({variant:e,text:n})=>t.jsx(a,{severity:"success",variant:e,children:n}),args:{text:"Here is a gentle message about finished action."}},f={render:({variant:e,text:n})=>t.jsx(a,{severity:"info",variant:e,children:n}),args:{text:"Here is a gentle message about finished action."}},x={render:({variant:e,text:n})=>t.jsx(a,{severity:"warning",variant:e,children:n}),args:{text:"Here is a gentle message about finished action."}},y={render:({variant:e,text:n})=>t.jsx(a,{severity:"error",variant:e,children:n}),args:{text:"Here is a gentle message about finished action."}},A={render:({text:e})=>t.jsx(a,{variant:"filled",children:e}),args:{text:"Here is a gentle message about finished action."}},h={render:({text:e})=>t.jsx(a,{variant:"outlined",children:e}),args:{text:"Here is a gentle message about finished action."}},S={render:({severity:e,variant:n,color:s,text:r,...o})=>t.jsx(a,{severity:e,variant:n,color:s,...o,children:r}),argTypes:{severity:{control:"select",options:["success","info","warning","error"]},variant:{control:"select",options:["standard","filled","outlined"]},color:{control:"select",options:["success","info","warning","error"]}},args:{severity:"success",variant:"standard",color:"success",text:"Here is a gentle message about finished action."}},C={render:({severity:e,variant:n,color:s,text:r,actionText:o,...i})=>{function c(){}return t.jsx(a,{severity:e,variant:n,color:s,action:t.jsx(L,{color:"inherit",size:"small",onClick:c,children:o}),...i,children:r})},argTypes:{severity:{control:"select",options:["success","info","warning","error"]},variant:{control:"select",options:["standard","filled","outlined"]},color:{control:"select",options:["success","info","warning","error"]}},args:{severity:"success",variant:"standard",color:"success",text:"Here is a gentle message about finished action.",actionText:"Undo"}},j={render:({severity:e,variant:n,color:s,text:r,...o})=>{const[i,c]=W.useState(!0);function u(){c(!1)}return t.jsxs(t.Fragment,{children:[t.jsx(re.InsertOnly,{children:i&&t.jsx(a,{severity:e,variant:n,color:s,onClose:u,...o,children:r})}),!i&&t.jsx(L,{onClick:()=>{c(!0)},children:"Show alert"})]})},argTypes:{severity:{control:"select",options:["success","info","warning","error"]},variant:{control:"select",options:["standard","filled","outlined"]},color:{control:"select",options:["success","info","warning","error"]}},args:{severity:"success",variant:"standard",color:"success",text:"Here is a gentle message about finished action."}};v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    text
  }) => {
    return <Alert severity="success" variant={variant}>
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...v.parameters?.docs?.source}}};f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    text
  }) => {
    return <Alert severity="info" variant={variant}>
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...f.parameters?.docs?.source}}};x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    text
  }) => {
    return <Alert severity="warning" variant={variant}>
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...x.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    text
  }) => {
    return <Alert severity="error" variant={variant}>
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...y.parameters?.docs?.source}}};A.parameters={...A.parameters,docs:{...A.parameters?.docs,source:{originalSource:`{
  render: ({
    text
  }) => {
    return <Alert variant="filled">
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...A.parameters?.docs?.source}}};h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: ({
    text
  }) => {
    return <Alert variant="outlined">
        {text}
      </Alert>;
  },
  args: {
    text: "Here is a gentle message about finished action."
  }
}`,...h.parameters?.docs?.source}}};S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  render: ({
    severity,
    variant,
    color,
    text,
    ...props
  }) => {
    return <Alert severity={severity} variant={variant} color={color} {...props}>
        {text}
      </Alert>;
  },
  argTypes: {
    severity: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    },
    variant: {
      control: "select",
      options: ["standard", "filled", "outlined"]
    },
    color: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    }
  },
  args: {
    severity: "success",
    variant: "standard",
    color: "success",
    text: "Here is a gentle message about finished action."
  }
}`,...S.parameters?.docs?.source}}};C.parameters={...C.parameters,docs:{...C.parameters?.docs,source:{originalSource:`{
  render: ({
    severity,
    variant,
    color,
    text,
    actionText,
    ...props
  }) => {
    function alertAction() {
      // userAction
    }
    return <Alert severity={severity} variant={variant} color={color} action={<Button color="inherit" size="small" onClick={alertAction}>{actionText}</Button>} {...props}>
        {text}
      </Alert>;
  },
  argTypes: {
    severity: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    },
    variant: {
      control: "select",
      options: ["standard", "filled", "outlined"]
    },
    color: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    }
  },
  args: {
    severity: "success",
    variant: "standard",
    color: "success",
    text: "Here is a gentle message about finished action.",
    actionText: "Undo"
  }
}`,...C.parameters?.docs?.source}}};j.parameters={...j.parameters,docs:{...j.parameters?.docs,source:{originalSource:`{
  render: ({
    severity,
    variant,
    color,
    text,
    ...props
  }) => {
    const [showAlert, setShowAlert] = useState(true);
    function closeHandler() {
      // user actions
      setShowAlert(false);
    }
    return <>
            <GenerationInstructions.InsertOnly>
                {showAlert && <Alert severity={severity} variant={variant} color={color} onClose={closeHandler} {...props}>
                    {text}
                </Alert>}
            </GenerationInstructions.InsertOnly>

            {!showAlert && <Button onClick={() => {
        setShowAlert(true);
      }}>Show alert</Button>}
        </>;
  },
  argTypes: {
    severity: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    },
    variant: {
      control: "select",
      options: ["standard", "filled", "outlined"]
    },
    color: {
      control: "select",
      options: ["success", "info", "warning", "error"]
    }
  },
  args: {
    severity: "success",
    variant: "standard",
    color: "success",
    text: "Here is a gentle message about finished action."
  }
}`,...j.parameters?.docs?.source}}};const Ze=["Success","Info","Warning","Error","Filled","Outlined","Basic","WithAction","WithClose"];export{S as Basic,y as Error,A as Filled,f as Info,h as Outlined,v as Success,x as Warning,C as WithAction,j as WithClose,Ze as __namedExportsOrder,Ve as default};
