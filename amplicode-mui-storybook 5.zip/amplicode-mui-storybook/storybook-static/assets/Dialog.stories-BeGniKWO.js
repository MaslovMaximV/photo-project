import{r as a,j as o}from"./iframe-U1MoWpc_.js";import{D as O,g as k,a as u,b as m,c as D}from"./DialogContent-BuSkWC5S.js";import{a as w,g as A,c as h}from"./createTheme-CB0G2ADO.js";import{u as y,s as C,a as j,b as F}from"./DefaultPropsProvider-Drazl94h.js";import{T as b}from"./Typography-NbeDhiLn.js";import{B as s}from"./Button-Z4BDc59h.js";import{S as M}from"./Slide-DVFtChZU.js";import"./preload-helper-D9Z9MdNV.js";import"./useTheme-CMyrA-7l.js";import"./useTheme-DUWNGOj_.js";import"./memoTheme-BNYDzr43.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./Paper-BtmMZDrw.js";import"./Fade-P8xhlTFS.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./useId-vd1Ifx8D.js";import"./Modal-Cups6cDA.js";import"./FocusTrap-aa0DuC0e.js";import"./ownerDocument-DW-IO8s5.js";import"./ownerWindow-HkKU3E4x.js";import"./useEventCallback-ELgNMDCa.js";import"./createChainedFunction-BO_9K8Jh.js";import"./Portal-Dc2RZP_l.js";import"./Backdrop-DKjtt3hE.js";import"./index-CR3QZgfD.js";import"./extendSxProp-Cl0Joej-.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./ButtonBase-BUPfvClL.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./debounce-Be36O1Ab.js";function R(t){return w("MuiDialogContentText",t)}A("MuiDialogContentText",["root"]);const U=t=>{const{classes:n}=t,i=j({root:["root"]},R,n);return{...n,...i}},v=C(b,{shouldForwardProp:t=>F(t)||t==="classes",name:"MuiDialogContentText",slot:"Root"})({}),x=a.forwardRef(function(n,e){const i=y({props:n,name:"MuiDialogContentText"}),{children:f,className:l,...c}=i,r=U(c);return o.jsx(v,{component:"p",variant:"body1",color:"textSecondary",ref:e,ownerState:c,className:h(r.root,l),...i,classes:r})}),z=t=>{const{classes:n}=t;return j({root:["root"]},k,n)},N=C(b,{name:"MuiDialogTitle",slot:"Root"})({padding:"16px 24px",flex:"0 0 auto"}),T=a.forwardRef(function(n,e){const i=y({props:n,name:"MuiDialogTitle"}),{className:f,id:l,...c}=i,r=i,S=z(r),{titleId:B=l}=a.useContext(O);return o.jsx(N,{component:"h2",className:h(S.root,f),ownerState:r,ref:e,variant:"h6",id:l??B,...c})}),So={title:"Feedback/Dialog",component:u,parameters:{layout:"centered",controls:{}},decorators:[],argTypes:{fullScreen:{control:"boolean"},fullWidth:{control:"boolean"},maxWidth:{control:"select",options:["xs","sm","md","lg","xl"]}},args:{}},p={render:()=>{const[t,n]=a.useState(!0);return o.jsxs(u,{open:t,onClose:()=>{},children:[o.jsx(T,{children:"Basic dialog title"}),o.jsx(m,{children:o.jsx(x,{children:"Description of dialog actions"})}),o.jsxs(D,{children:[o.jsx(s,{onClick:()=>{},children:"Cancel"}),o.jsx(s,{onClick:()=>{},autoFocus:!0,children:"Accept"})]})]})}},g={render:()=>{const[t,n]=a.useState(!0);return o.jsxs(P,{open:t,onClose:()=>{},children:[o.jsx(T,{children:"Dialog with dropped gaps"}),o.jsx(m,{children:o.jsx(x,{children:"You can set gaps by your own if you need custom dialog locally"})}),o.jsxs(D,{children:[o.jsx(s,{onClick:()=>{},children:"Cancel"}),o.jsx(s,{onClick:()=>{},autoFocus:!0,children:"Accept"})]})]})}},P=C(u)(({theme:t})=>({"& .MuiDialogTitle-root":{margin:t.spacing(0),padding:t.spacing(0),boxSizing:"border-box"},"& .MuiCardContent-root":{margin:t.spacing(0),padding:t.spacing(0),boxSizing:"border-box"},"& .MuiDialogContent-root":{margin:t.spacing(0),padding:t.spacing(0),boxSizing:"border-box"},"& .MuiDialogActions-root":{margin:t.spacing(0),padding:t.spacing(0),boxSizing:"border-box"}})),d={render:()=>{const[t,n]=a.useState(!1);return o.jsxs(o.Fragment,{children:[o.jsx(s,{variant:"outlined",onClick:()=>n(e=>!e),children:"Slide in alert dialog"}),o.jsxs(u,{open:t,TransitionComponent:Y,onClose:()=>{},children:[o.jsx(T,{children:"Dialog with dropped gaps"}),o.jsx(m,{children:o.jsx(x,{children:"You can set gaps by your own if you need custom dialog locally"})}),o.jsxs(D,{children:[o.jsx(s,{onClick:()=>{},children:"Cancel"}),o.jsx(s,{onClick:()=>{},autoFocus:!0,children:"Accept"})]})]})]})}},Y=a.forwardRef(function(n,e){return o.jsx(M,{direction:"up",ref:e,...n})});p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [dialogOpen, setDialogOpen] = useState(true);
    return <Dialog open={dialogOpen} onClose={() => {}}>
        <DialogTitle>Basic dialog title</DialogTitle>
        <DialogContent>
          <DialogContentText>Description of dialog actions</DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {}}>Cancel</Button>
          <Button onClick={() => {}} autoFocus>
            Accept
          </Button>
        </DialogActions>
      </Dialog>;
  }
}`,...p.parameters?.docs?.source}}};g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [dialogOpen, setDialogOpen] = useState(true);
    return <CustomDialog open={dialogOpen} onClose={() => {}}>
        <DialogTitle>Dialog with dropped gaps</DialogTitle>
        <DialogContent>
          <DialogContentText>
            You can set gaps by your own if you need custom dialog locally
          </DialogContentText>
        </DialogContent>
        <DialogActions>
          <Button onClick={() => {}}>Cancel</Button>
          <Button onClick={() => {}} autoFocus>
            Accept
          </Button>
        </DialogActions>
      </CustomDialog>;
  }
}`,...g.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [dialogOpen, setDialogOpen] = useState(false);
    return <>
        <Button variant="outlined" onClick={() => setDialogOpen(open => !open)}>
          Slide in alert dialog
        </Button>
        <Dialog open={dialogOpen} TransitionComponent={Transition} onClose={() => {}}>
          <DialogTitle>Dialog with dropped gaps</DialogTitle>
          <DialogContent>
            <DialogContentText>
              You can set gaps by your own if you need custom dialog locally
            </DialogContentText>
          </DialogContent>
          <DialogActions>
            <Button onClick={() => {}}>Cancel</Button>
            <Button onClick={() => {}} autoFocus>
              Accept
            </Button>
          </DialogActions>
        </Dialog>
      </>;
  }
}`,...d.parameters?.docs?.source}}};const Bo=["Basic","DropGaps","Transitioned"];export{p as Basic,g as DropGaps,d as Transitioned,Bo as __namedExportsOrder,So as default};
