import{r as i,j as n}from"./iframe-U1MoWpc_.js";import{F as V,a as J,b as _,c as q,d as K,e as Q,f as X,g as Y}from"./FormatUnderlined-CH8IpgdT.js";import{A as Z}from"./ArrowDropDown-ChzEnR_A.js";import{g as L,a as S,c as W,b as A}from"./createTheme-CB0G2ADO.js";import{m as O}from"./memoTheme-BNYDzr43.js";import{c as tt}from"./createSimplePaletteValueFilter-bm0fmN_7.js";import{r as ot,u as E,s as N,a as P}from"./DefaultPropsProvider-Drazl94h.js";import{B as et}from"./ButtonBase-BUPfvClL.js";import{g as nt}from"./getValidReactChildren-DXyoNhBF.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useForkRef-OOgs0334.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";function rt(t){return S("MuiToggleButton",t)}const B=L("MuiToggleButton",["root","disabled","selected","standard","primary","secondary","sizeSmall","sizeMedium","sizeLarge","fullWidth"]),D=i.createContext({}),U=i.createContext(void 0);function at(t,o){return o===void 0||t===void 0?!1:Array.isArray(o)?o.includes(t):t===o}const lt=t=>{const{classes:o,fullWidth:r,selected:d,disabled:s,size:m,color:v}=t,g={root:["root",d&&"selected",s&&"disabled",r&&"fullWidth",`size${A(m)}`,v]};return P(g,rt,o)},st=N(et,{name:"MuiToggleButton",slot:"Root",overridesResolver:(t,o)=>{const{ownerState:r}=t;return[o.root,o[`size${A(r.size)}`]]}})(O(({theme:t})=>({...t.typography.button,borderRadius:(t.vars||t).shape.borderRadius,padding:11,border:`1px solid ${(t.vars||t).palette.divider}`,color:(t.vars||t).palette.action.active,[`&.${B.disabled}`]:{color:(t.vars||t).palette.action.disabled,border:`1px solid ${(t.vars||t).palette.action.disabledBackground}`},"&:hover":{textDecoration:"none",backgroundColor:t.alpha((t.vars||t).palette.text.primary,(t.vars||t).palette.action.hoverOpacity),"@media (hover: none)":{backgroundColor:"transparent"}},variants:[{props:{color:"standard"},style:{[`&.${B.selected}`]:{color:(t.vars||t).palette.text.primary,backgroundColor:t.alpha((t.vars||t).palette.text.primary,(t.vars||t).palette.action.selectedOpacity),"&:hover":{backgroundColor:t.alpha((t.vars||t).palette.text.primary,`${(t.vars||t).palette.action.selectedOpacity} + ${(t.vars||t).palette.action.hoverOpacity}`),"@media (hover: none)":{backgroundColor:t.alpha((t.vars||t).palette.text.primary,(t.vars||t).palette.action.selectedOpacity)}}}}},...Object.entries(t.palette).filter(tt()).map(([o])=>({props:{color:o},style:{[`&.${B.selected}`]:{color:(t.vars||t).palette[o].main,backgroundColor:t.alpha((t.vars||t).palette[o].main,(t.vars||t).palette.action.selectedOpacity),"&:hover":{backgroundColor:t.alpha((t.vars||t).palette[o].main,`${(t.vars||t).palette.action.selectedOpacity} + ${(t.vars||t).palette.action.hoverOpacity}`),"@media (hover: none)":{backgroundColor:t.alpha((t.vars||t).palette[o].main,(t.vars||t).palette.action.selectedOpacity)}}}}})),{props:{fullWidth:!0},style:{width:"100%"}},{props:{size:"small"},style:{padding:7,fontSize:t.typography.pxToRem(13)}},{props:{size:"large"},style:{padding:15,fontSize:t.typography.pxToRem(15)}}]}))),c=i.forwardRef(function(o,r){const{value:d,...s}=i.useContext(D),m=i.useContext(U),v=ot({...s,selected:at(o.value,d)},o),g=E({props:v,name:"MuiToggleButton"}),{children:R,className:T,color:p="standard",disabled:F=!1,disableFocusRipple:b=!1,fullWidth:l=!1,onChange:h,onClick:C,selected:f,size:j="medium",value:x,...M}=g,y={...g,color:p,disabled:F,disableFocusRipple:b,fullWidth:l,size:j},k=lt(y),G=a=>{C&&(C(a,x),a.defaultPrevented)||h&&h(a,x)},u=m||"";return n.jsx(st,{className:W(s.className,k.root,T,u),disabled:F,focusRipple:!b,ref:r,onClick:G,onChange:h,value:x,ownerState:y,"aria-pressed":f,...M,children:R})});function it(t){return S("MuiToggleButtonGroup",t)}const e=L("MuiToggleButtonGroup",["root","selected","horizontal","vertical","disabled","grouped","groupedHorizontal","groupedVertical","fullWidth","firstButton","lastButton","middleButton"]),dt=t=>{const{classes:o,orientation:r,fullWidth:d,disabled:s}=t,m={root:["root",r,d&&"fullWidth"],grouped:["grouped",`grouped${A(r)}`,s&&"disabled"],firstButton:["firstButton"],lastButton:["lastButton"],middleButton:["middleButton"]};return P(m,it,o)},ut=N("div",{name:"MuiToggleButtonGroup",slot:"Root",overridesResolver:(t,o)=>{const{ownerState:r}=t;return[{[`& .${e.grouped}`]:o.grouped},{[`& .${e.grouped}`]:o[`grouped${A(r.orientation)}`]},{[`& .${e.firstButton}`]:o.firstButton},{[`& .${e.lastButton}`]:o.lastButton},{[`& .${e.middleButton}`]:o.middleButton},o.root,r.orientation==="vertical"&&o.vertical,r.fullWidth&&o.fullWidth]}})(O(({theme:t})=>({display:"inline-flex",borderRadius:(t.vars||t).shape.borderRadius,variants:[{props:{orientation:"vertical"},style:{flexDirection:"column",[`& .${e.grouped}`]:{[`&.${e.selected} + .${e.grouped}.${e.selected}`]:{borderTop:0,marginTop:0}},[`& .${e.firstButton},& .${e.middleButton}`]:{borderBottomLeftRadius:0,borderBottomRightRadius:0},[`& .${e.lastButton},& .${e.middleButton}`]:{marginTop:-1,borderTop:"1px solid transparent",borderTopLeftRadius:0,borderTopRightRadius:0},[`& .${e.lastButton}.${B.disabled},& .${e.middleButton}.${B.disabled}`]:{borderTop:"1px solid transparent"}}},{props:{fullWidth:!0},style:{width:"100%"}},{props:{orientation:"horizontal"},style:{[`& .${e.grouped}`]:{[`&.${e.selected} + .${e.grouped}.${e.selected}`]:{borderLeft:0,marginLeft:0}},[`& .${e.firstButton},& .${e.middleButton}`]:{borderTopRightRadius:0,borderBottomRightRadius:0},[`& .${e.lastButton},& .${e.middleButton}`]:{marginLeft:-1,borderLeft:"1px solid transparent",borderTopLeftRadius:0,borderBottomLeftRadius:0},[`& .${e.lastButton}.${B.disabled},& .${e.middleButton}.${B.disabled}`]:{borderLeft:"1px solid transparent"}}}]}))),H=i.forwardRef(function(o,r){const d=E({props:o,name:"MuiToggleButtonGroup"}),{children:s,className:m,color:v="standard",disabled:g=!1,exclusive:R=!1,fullWidth:T=!1,onChange:p,orientation:F="horizontal",size:b="medium",value:l,...h}=d,C={...d,disabled:g,fullWidth:T,orientation:F,size:b},f=dt(C),j=i.useCallback((u,a)=>{if(!p)return;const $=l&&l.indexOf(a);let I;l&&$>=0?(I=l.slice(),I.splice($,1)):I=l?l.concat(a):[a],p(u,I)},[p,l]),x=i.useCallback((u,a)=>{p&&p(u,l===a?null:a)},[p,l]),M=i.useMemo(()=>({className:f.grouped,onChange:R?x:j,value:l,size:b,fullWidth:T,color:v,disabled:g}),[f.grouped,R,x,j,l,b,T,v,g]),y=nt(s),k=y.length,G=u=>{const a=u===0,$=u===k-1;return a&&$?"":a?f.firstButton:$?f.lastButton:f.middleButton};return n.jsx(ut,{role:"group",className:W(f.root,m),ref:r,ownerState:C,...h,children:n.jsx(D.Provider,{value:M,children:y.map((u,a)=>n.jsx(U.Provider,{value:G(a),children:u},a))})})}),jt={title:"Inputs/ToggleButton",component:c,tags:["autodocs"],parameters:{layout:"centered",docs:{description:{component:"ToggleButtones toggle the state of a single setting on or off."}}},args:{size:"medium"},argTypes:{value:{control:"text",description:"The currently selected value(s). Must be controlled."},exclusive:{control:"boolean",description:"If `true`, only one ToggleButton can be selected at a time (like radio buttons)."},orientation:{control:"select",options:["horizontal","vertical"],description:"Defines the orientation of the buttons."},size:{control:"select",options:["small","medium","large"],description:"The size of the buttons."},color:{control:"select",options:["standard","primary","secondary","error","info","success","warning"],description:"The color of the toggle buttons."},disabled:{control:"boolean",description:"If `true`, all toggle buttons in the group will be disabled."},fullWidth:{control:"boolean",description:"If `true`, the toggle buttons take up the full width of their container."},onChange:{action:"changed",description:"Callback fired when the selected value changes."}}},z={render:()=>{const[t,o]=i.useState("left"),r=(d,s)=>{o(s)};return n.jsxs(H,{value:t,exclusive:!0,onChange:r,children:[n.jsx(c,{value:"left",children:n.jsx(V,{})}),n.jsx(c,{value:"center",children:n.jsx(J,{})}),n.jsx(c,{value:"right",children:n.jsx(_,{})}),n.jsx(c,{value:"justify",disabled:!0,children:n.jsx(q,{})})]})},parameters:{docs:{description:{story:"ToggleButtones toggle the state of a single setting on or off."}}}},w={render:()=>{const[t,o]=i.useState(()=>["bold","italic"]),r=(d,s)=>{o(s)};return n.jsxs(H,{value:t,onChange:r,"aria-label":"text formatting",children:[n.jsx(c,{value:"bold","aria-label":"bold",children:n.jsx(K,{})}),n.jsx(c,{value:"italic","aria-label":"italic",children:n.jsx(Q,{})}),n.jsx(c,{value:"underlined","aria-label":"underlined",children:n.jsx(X,{})}),n.jsxs(c,{value:"color","aria-label":"color",disabled:!0,children:[n.jsx(Y,{}),n.jsx(Z,{})]})]})},parameters:{docs:{description:{story:"ToggleButtones toggle the state of a single setting on or off."}}}};z.parameters={...z.parameters,docs:{...z.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [alignment, setAlignment] = useState<string | null>("left");
    const handleAlignment = (event: MouseEvent<HTMLElement>, newAlignment: string | null) => {
      setAlignment(newAlignment);
    };
    return <ToggleButtonGroup value={alignment} exclusive onChange={handleAlignment}>
        <ToggleButton value="left">
          <FormatAlignLeftIcon />
        </ToggleButton>
        <ToggleButton value="center">
          <FormatAlignCenterIcon />
        </ToggleButton>
        <ToggleButton value="right">
          <FormatAlignRightIcon />
        </ToggleButton>
        <ToggleButton value="justify" disabled>
          <FormatAlignJustifyIcon />
        </ToggleButton>
      </ToggleButtonGroup>;
  },
  parameters: {
    docs: {
      description: {
        story: "ToggleButtones toggle the state of a single setting on or off."
      }
    }
  }
}`,...z.parameters?.docs?.source}}};w.parameters={...w.parameters,docs:{...w.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [formats, setFormats] = useState(() => ["bold", "italic"]);
    const handleFormat = (event: React.MouseEvent<HTMLElement>, newFormats: string[]) => {
      setFormats(newFormats);
    };
    return <ToggleButtonGroup value={formats} onChange={handleFormat} aria-label="text formatting">
        <ToggleButton value="bold" aria-label="bold">
          <FormatBoldIcon />
        </ToggleButton>
        <ToggleButton value="italic" aria-label="italic">
          <FormatItalicIcon />
        </ToggleButton>
        <ToggleButton value="underlined" aria-label="underlined">
          <FormatUnderlinedIcon />
        </ToggleButton>
        <ToggleButton value="color" aria-label="color" disabled>
          <FormatColorFillIcon />
          <ArrowDropDownIcon />
        </ToggleButton>
      </ToggleButtonGroup>;
  },
  parameters: {
    docs: {
      description: {
        story: "ToggleButtones toggle the state of a single setting on or off."
      }
    }
  }
}`,...w.parameters?.docs?.source}}};const It=["Exclusive","Multiple"];export{z as Exclusive,w as Multiple,It as __namedExportsOrder,jt as default};
