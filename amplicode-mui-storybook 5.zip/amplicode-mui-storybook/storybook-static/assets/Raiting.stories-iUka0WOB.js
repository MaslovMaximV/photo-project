import{j as n,r as h}from"./iframe-U1MoWpc_.js";import{F as S,a as R}from"./FavoriteBorder-DiR9fGnD.js";import{R as a}from"./Rating-Bk-5Sb9J.js";import{B as f}from"./Box-nnrC_EdN.js";import{T as z}from"./Typography-NbeDhiLn.js";import{s as w}from"./DefaultPropsProvider-Drazl94h.js";import"./preload-helper-D9Z9MdNV.js";import"./createSvgIcon-Ck9VyYEl.js";import"./createTheme-CB0G2ADO.js";import"./memoTheme-BNYDzr43.js";import"./index-BnGSTqEq.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useId-vd1Ifx8D.js";import"./useControlled-CeZ7-hqo.js";import"./visuallyHidden-Dan1xhjv.js";import"./isFocusVisible-B8k4qzLc.js";import"./useTheme-DUWNGOj_.js";import"./extendSxProp-Cl0Joej-.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const K={title:"Inputs/Rating",component:a,tags:["autodocs"],parameters:{layout:"centered",docs:{description:{component:"The Rating component allows users to provide a feedback score by selecting a number of visual symbols, typically stars."}}},args:{value:3,precision:1,max:5,readOnly:!1,size:"medium",disabled:!1,showLabel:!1},argTypes:{value:{control:"number",description:"The rating value"},precision:{control:"number",description:"The minimum increment value change allowed"},max:{control:"number",description:"Maximum rating value"},readOnly:{control:"boolean",description:"Whether the component is read-only"},size:{control:"select",options:["small","medium","large"],description:"Defines the size of the rating icons"},disabled:{control:"boolean",description:"Disables the component"},showLabel:{control:"boolean",description:"Displays the numeric value alongside the rating"}}},m={render:({value:e,max:r,precision:o,readOnly:t,size:i,disabled:s})=>n.jsx(a,{value:e,max:r,precision:o,readOnly:t,size:i,disabled:s}),parameters:{docs:{description:{story:"A basic rating component with configurable value, size, and precision."}}}},p={render:({value:e,size:r,max:o})=>n.jsx(a,{value:e,readOnly:!0,size:r,max:o}),parameters:{docs:{description:{story:"A read-only rating component where user input is disabled."}}}},u={render:({value:e,size:r,max:o})=>n.jsx(a,{value:e,disabled:!0,size:r,max:o}),parameters:{docs:{description:{story:"A disabled rating component that is non-interactive."}}}},g={render:({precision:e})=>n.jsx(a,{defaultValue:2.5,precision:e}),args:{precision:.5},parameters:{docs:{description:{story:"Demonstrates fractional rating values using custom precision."}}}},v={render:({precision:e,max:r,size:o,disabled:t,readOnly:i,showLabel:s})=>{const[l,d]=h.useState(2);return n.jsxs(f,{children:[n.jsx(a,{value:l,onChange:(x,c)=>d(c),precision:e,max:r,size:o,disabled:t,readOnly:i}),s&&n.jsxs(z,{variant:"body2",sx:{mt:1},children:["Selected: ",l??"None"]})]})},parameters:{docs:{description:{story:"Controlled version of the rating component using local state."}}}},y={render:({max:e,size:r,precision:o})=>{const[t,i]=h.useState(-1),[s,l]=h.useState(2),d={1:"Very Bad",2:"Bad",3:"Okay",4:"Good",5:"Excellent"};return n.jsxs(f,{children:[n.jsx(a,{name:"hover-feedback",value:s,max:e,precision:o,size:r,onChange:(x,c)=>l(c),onChangeActive:(x,c)=>i(c)}),n.jsx(z,{variant:"body2",sx:{mt:1},children:t!==-1?d[t]:s!==null?d[s]:"No rating"})]})},parameters:{docs:{description:{story:"Displays a label describing the rating level when hovering over the icons."}}}},b={render:()=>{const e=w(a)({"& .MuiRating-iconFilled":{color:"#ff6d75"},"& .MuiRating-iconHover":{color:"#ff3d47"}});return n.jsx(e,{name:"customized-color",defaultValue:2,getLabelText:r=>`${r} Heart${r!==1?"s":""}`,precision:.5,icon:n.jsx(R,{fontSize:"inherit"}),emptyIcon:n.jsx(S,{fontSize:"inherit"})})},parameters:{docs:{description:{story:"Demonstrates customization of rating icons using emojis or custom SVGs."}}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: ({
    value,
    max,
    precision,
    readOnly,
    size,
    disabled
  }) => <Rating value={value} max={max} precision={precision} readOnly={readOnly} size={size} disabled={disabled} />,
  parameters: {
    docs: {
      description: {
        story: "A basic rating component with configurable value, size, and precision."
      }
    }
  }
}`,...m.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: ({
    value,
    size,
    max
  }) => <Rating value={value} readOnly size={size} max={max} />,
  parameters: {
    docs: {
      description: {
        story: "A read-only rating component where user input is disabled."
      }
    }
  }
}`,...p.parameters?.docs?.source}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: ({
    value,
    size,
    max
  }) => <Rating value={value} disabled size={size} max={max} />,
  parameters: {
    docs: {
      description: {
        story: "A disabled rating component that is non-interactive."
      }
    }
  }
}`,...u.parameters?.docs?.source}}};g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: ({
    precision
  }) => <Rating defaultValue={2.5} precision={precision} />,
  args: {
    precision: 0.5
  },
  parameters: {
    docs: {
      description: {
        story: "Demonstrates fractional rating values using custom precision."
      }
    }
  }
}`,...g.parameters?.docs?.source}}};v.parameters={...v.parameters,docs:{...v.parameters?.docs,source:{originalSource:`{
  render: ({
    precision,
    max,
    size,
    disabled,
    readOnly,
    showLabel
  }) => {
    const [value, setValue] = useState<number | null>(2);
    return <Box>
        <Rating value={value} onChange={(_, newValue) => setValue(newValue)} precision={precision} max={max} size={size} disabled={disabled} readOnly={readOnly} />
        {showLabel && <Typography variant="body2" sx={{
        mt: 1
      }}>
            Selected: {value ?? "None"}
          </Typography>}
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "Controlled version of the rating component using local state."
      }
    }
  }
}`,...v.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: ({
    max,
    size,
    precision
  }) => {
    const [hover, setHover] = useState(-1);
    const [value, setValue] = useState<number | null>(2);
    const labels: {
      [index: number]: string;
    } = {
      1: "Very Bad",
      2: "Bad",
      3: "Okay",
      4: "Good",
      5: "Excellent"
    };
    return <Box>
        <Rating name="hover-feedback" value={value} max={max} precision={precision} size={size} onChange={(_, newValue) => setValue(newValue)} onChangeActive={(_, newHover) => setHover(newHover)} />
        <Typography variant="body2" sx={{
        mt: 1
      }}>
          {hover !== -1 ? labels[hover] : value !== null ? labels[value] : "No rating"}
        </Typography>
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "Displays a label describing the rating level when hovering over the icons."
      }
    }
  }
}`,...y.parameters?.docs?.source}}};b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: () => {
    const StyledRating = styled(Rating)({
      "& .MuiRating-iconFilled": {
        color: "#ff6d75"
      },
      "& .MuiRating-iconHover": {
        color: "#ff3d47"
      }
    });
    return <StyledRating name="customized-color" defaultValue={2} getLabelText={(value: number) => \`\${value} Heart\${value !== 1 ? "s" : ""}\`} precision={0.5} icon={<FavoriteIcon fontSize="inherit" />} emptyIcon={<FavoriteBorderIcon fontSize="inherit" />} />;
  },
  parameters: {
    docs: {
      description: {
        story: "Demonstrates customization of rating icons using emojis or custom SVGs."
      }
    }
  }
}`,...b.parameters?.docs?.source}}};const Q=["Basic","ReadOnly","Disabled","CustomPrecision","Controlled","HoverFeedback","CustomIcon"];export{m as Basic,v as Controlled,b as CustomIcon,g as CustomPrecision,u as Disabled,y as HoverFeedback,p as ReadOnly,Q as __namedExportsOrder,K as default};
