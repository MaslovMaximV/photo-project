import{j as r}from"./iframe-U1MoWpc_.js";import"./preload-helper-D9Z9MdNV.js";const N={title:"Store/Templates",parameters:{layout:"fullscreen",studioMeta:{kind:"remote-template"}},tags:["!autodocs"]},R={display:"flex",border:"none",width:"100%",height:"100vh"},v=8080,z="/proxy/mui",P=`http://localhost:${v}${z}`,t=({src:e})=>{const K=P,U=e.startsWith("http")?e:`${K}${e}`;return r.jsx("iframe",{src:U,style:R})},a={render:({...e})=>r.jsx(t,{src:"/store/items/minimal-dashboard/"}),parameters:{studioMeta:{npmDeps:[{name:"@storybook/react-vite"},{name:"storybook"},{name:"@amplicode/amplicode-mui-storybook"},{name:"@amplicode/storybook-extensions"}],kind:"remote-template",repo:"https://github.com/minimal-ui-kit/material-kit-react.git",storeLink:"https://mui.com/store/items/minimal-dashboard-free/",include:["src","public"]}}},s={render:({...e})=>r.jsx(t,{src:"/store/items/modernize-next-js-free-admin-template/"}),parameters:{studioMeta:{kind:"remote-template",repo:"https://github.com/minimal-ui-kit/material-kit-react.git",storeLink:"https://mui.com/store/items/modernize-next-js-free-admin-template/",projectRootFolder:"package"}}},o={render:({...e})=>r.jsx(t,{src:"/store/items/saasable-free-multipurpose-ui-kit-dashboard/"}),parameters:{studioMeta:{kind:"remote-template",repo:"https://github.com/minimal-ui-kit/material-kit-react.git",storeLink:"https://mui.com/store/items/saasable-free-multipurpose-ui-kit-dashboard/",projectRootFolder:"admin"}}},n={render:({...e})=>r.jsx(t,{src:"/store/items/the-front-landing-page/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/the-front-landing-page/"}}},i={render:({...e})=>r.jsx(t,{src:"https://material-kit-pro-react.devias.io/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://material-kit-pro-react.devias.io/"}}},m={render:({...e})=>r.jsx(t,{src:"/store/items/paperbase/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/paperbase/"}}},p={render:({...e})=>r.jsx(t,{src:"/store/items/devias-kit-pro/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/devias-kit-pro/"}}},d={render:({...e})=>r.jsx(t,{src:"/store/items/mantis-react-admin-dashboard-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/mantis-react-admin-dashboard-template/"}}},c={render:({...e})=>r.jsx(t,{src:"/store/items/berry-react-material-admin/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/berry-react-material-admin/"}}},u={render:({...e})=>r.jsx(t,{src:"/store/items/zone-landing-page/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/zone-landing-page/"}}},l={render:({...e})=>r.jsx(t,{src:"/store/items/bazar-pro-react-ecommerce-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/bazar-pro-react-ecommerce-template/"}}},k={render:({...e})=>r.jsx(t,{src:"/store/items/uifort-react-admin-dashboard-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/uifort-react-admin-dashboard-template/"}}},h={render:({...e})=>r.jsx(t,{src:"/store/items/ui-foundations-kit-saas-admin-dashboard-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"/store/items/ui-foundations-kit-saas-admin-dashboard-template/"}}},b={render:({...e})=>r.jsx(t,{src:"/store/items/aurora/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/aurora/"}}},M={render:({...e})=>r.jsx(t,{src:"/store/items/webbee-landing-page/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/webbee-landing-page/"}}},g={render:({...e})=>r.jsx(t,{src:"/store/items/uko-client-admin-dashboard/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/uko-client-admin-dashboard/"}}},A={render:({...e})=>r.jsx(t,{src:"/store/items/saasable-multipurpose-ui-kit-and-dashboard/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/saasable-multipurpose-ui-kit-and-dashboard/"}}},L={render:({...e})=>r.jsx(t,{src:"/store/items/lotru/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/lotru/"}}},x={render:({...e})=>r.jsx(t,{src:"/store/items/materio-mui-react-nextjs-admin-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/materio-mui-react-nextjs-admin-template/"}}},D={render:({...e})=>r.jsx(t,{src:"/store/items/modernize-next-js-admin-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/modernize-next-js-admin-template/"}}},F={render:({...e})=>r.jsx(t,{src:"/store/items/soft-ui-pro-dashboard/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/soft-ui-pro-dashboard/"}}},j={render:({...e})=>r.jsx(t,{src:"/store/items/otis-admin-pro-material-dashboard-react/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/otis-admin-pro-material-dashboard-react/"}}},f={render:({...e})=>r.jsx(t,{src:"/store/items/otis-kit-pro-material-kit-react/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/otis-kit-pro-material-kit-react/"}}},I={render:({...e})=>r.jsx(t,{src:"/store/items/devias-kit/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/devias-kit/"}}},S={render:({...e})=>r.jsx(t,{src:"/store/items/mantis-free-react-admin-dashboard-template/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/mantis-free-react-admin-dashboard-template/"}}},T={render:({...e})=>r.jsx(t,{src:"/store/items/berry-react-material-admin-free/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/berry-react-material-admin-free/"}}},y={render:({...e})=>r.jsx(t,{src:"/store/items/onepirate/"}),parameters:{studioMeta:{kind:"remote-template",storeLink:"https://mui.com/store/items/onepirate/"}}};a.parameters={...a.parameters,docs:{...a.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/minimal-dashboard/\`} />;
  },
  parameters: {
    studioMeta: {
      npmDeps: [{
        name: "@storybook/react-vite"
      }, {
        name: "storybook"
      }, {
        name: "@amplicode/amplicode-mui-storybook"
      }, {
        name: "@amplicode/storybook-extensions"
      }],
      kind: "remote-template",
      repo: "https://github.com/minimal-ui-kit/material-kit-react.git",
      storeLink: "https://mui.com/store/items/minimal-dashboard-free/",
      include: ["src", "public"]
    }
  }
}`,...a.parameters?.docs?.source}}};s.parameters={...s.parameters,docs:{...s.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/modernize-next-js-free-admin-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      repo: "https://github.com/minimal-ui-kit/material-kit-react.git",
      storeLink: "https://mui.com/store/items/modernize-next-js-free-admin-template/",
      projectRootFolder: "package"
    }
  }
}`,...s.parameters?.docs?.source}}};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/saasable-free-multipurpose-ui-kit-dashboard/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      repo: "https://github.com/minimal-ui-kit/material-kit-react.git",
      storeLink: "https://mui.com/store/items/saasable-free-multipurpose-ui-kit-dashboard/",
      projectRootFolder: "admin"
    }
  }
}`,...o.parameters?.docs?.source}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/the-front-landing-page/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/the-front-landing-page/"
    }
  }
}`,...n.parameters?.docs?.source}}};i.parameters={...i.parameters,docs:{...i.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`https://material-kit-pro-react.devias.io/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://material-kit-pro-react.devias.io/"
    }
  }
}`,...i.parameters?.docs?.source}}};m.parameters={...m.parameters,docs:{...m.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/paperbase/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/paperbase/"
    }
  }
}`,...m.parameters?.docs?.source}}};p.parameters={...p.parameters,docs:{...p.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/devias-kit-pro/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/devias-kit-pro/"
    }
  }
}`,...p.parameters?.docs?.source}}};d.parameters={...d.parameters,docs:{...d.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/mantis-react-admin-dashboard-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/mantis-react-admin-dashboard-template/"
    }
  }
}`,...d.parameters?.docs?.source}}};c.parameters={...c.parameters,docs:{...c.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/berry-react-material-admin/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/berry-react-material-admin/"
    }
  }
}`,...c.parameters?.docs?.source}}};u.parameters={...u.parameters,docs:{...u.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/zone-landing-page/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/zone-landing-page/"
    }
  }
}`,...u.parameters?.docs?.source}}};l.parameters={...l.parameters,docs:{...l.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/bazar-pro-react-ecommerce-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/bazar-pro-react-ecommerce-template/"
    }
  }
}`,...l.parameters?.docs?.source}}};k.parameters={...k.parameters,docs:{...k.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/uifort-react-admin-dashboard-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/uifort-react-admin-dashboard-template/"
    }
  }
}`,...k.parameters?.docs?.source}}};h.parameters={...h.parameters,docs:{...h.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/ui-foundations-kit-saas-admin-dashboard-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "/store/items/ui-foundations-kit-saas-admin-dashboard-template/"
    }
  }
}`,...h.parameters?.docs?.source}}};b.parameters={...b.parameters,docs:{...b.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/aurora/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/aurora/"
    }
  }
}`,...b.parameters?.docs?.source}}};M.parameters={...M.parameters,docs:{...M.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/webbee-landing-page/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/webbee-landing-page/"
    }
  }
}`,...M.parameters?.docs?.source}}};g.parameters={...g.parameters,docs:{...g.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/uko-client-admin-dashboard/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/uko-client-admin-dashboard/"
    }
  }
}`,...g.parameters?.docs?.source}}};A.parameters={...A.parameters,docs:{...A.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/saasable-multipurpose-ui-kit-and-dashboard/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/saasable-multipurpose-ui-kit-and-dashboard/"
    }
  }
}`,...A.parameters?.docs?.source}}};L.parameters={...L.parameters,docs:{...L.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/lotru/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/lotru/"
    }
  }
}`,...L.parameters?.docs?.source}}};x.parameters={...x.parameters,docs:{...x.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/materio-mui-react-nextjs-admin-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/materio-mui-react-nextjs-admin-template/"
    }
  }
}`,...x.parameters?.docs?.source}}};D.parameters={...D.parameters,docs:{...D.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/modernize-next-js-admin-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/modernize-next-js-admin-template/"
    }
  }
}`,...D.parameters?.docs?.source}}};F.parameters={...F.parameters,docs:{...F.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/soft-ui-pro-dashboard/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/soft-ui-pro-dashboard/"
    }
  }
}`,...F.parameters?.docs?.source}}};j.parameters={...j.parameters,docs:{...j.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/otis-admin-pro-material-dashboard-react/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/otis-admin-pro-material-dashboard-react/"
    }
  }
}`,...j.parameters?.docs?.source}}};f.parameters={...f.parameters,docs:{...f.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/otis-kit-pro-material-kit-react/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/otis-kit-pro-material-kit-react/"
    }
  }
}`,...f.parameters?.docs?.source}}};I.parameters={...I.parameters,docs:{...I.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/devias-kit/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/devias-kit/"
    }
  }
}`,...I.parameters?.docs?.source}}};S.parameters={...S.parameters,docs:{...S.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/mantis-free-react-admin-dashboard-template/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/mantis-free-react-admin-dashboard-template/"
    }
  }
}`,...S.parameters?.docs?.source}}};T.parameters={...T.parameters,docs:{...T.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/berry-react-material-admin-free/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/berry-react-material-admin-free/"
    }
  }
}`,...T.parameters?.docs?.source}}};y.parameters={...y.parameters,docs:{...y.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <IFrame src={\`/store/items/onepirate/\`} />;
  },
  parameters: {
    studioMeta: {
      kind: "remote-template",
      storeLink: "https://mui.com/store/items/onepirate/"
    }
  }
}`,...y.parameters?.docs?.source}}};const O=["MinimalClientAndAdminDashboard","ModernizeNextJsFreeAdminTemplate","SaasAbleFreeMultipurposeUiKitAndDashboardTemplate","TheFrontMultipurposeTemplateAndUIKitDeviasKitProClientAndAdminDashboard","MiraProReactMaterialUIAdminDashboard","Paperbase","DeviasKitProClientAndAdminDashboard","MantisReactMaterialUIDashboardTemplate","BerryReactMaterialUIDashboardTemplate","ZoneMultipurposeLandingPageUIKit","BazaarProMultipurposeNextJsEcommerceTemplate","UifortReactClientAndAdminDashboardTemplate","UIFoundationsKitSaaSDashboardTemplateDeviasKitProClientAndAdminDashboard","AuroraAdminDashboardAndWebAppTemplate","WebbeeMultipurposeLandingPageUiKit","UKOClientAndAdminDashboardNextJsAndVite","SaasAbleMultipurposeUiKitAndDashboardTemplate","LotruJoyUiDashboard","MaterioNextJsAdminTemplate","ModernizeReactAndNextJsAdminDashboard","SoftUiProReactAdminDashboardTemplate","OtisAdminProMaterialDashboardForReact","OtisKitProMaterialKitForReact","DeviasKitClientAndAdminDashboard","MantisFreeReactAdminDashboardTemplate","BerryFreeReactMaterialAdminDashboard","Onepirate"];export{b as AuroraAdminDashboardAndWebAppTemplate,l as BazaarProMultipurposeNextJsEcommerceTemplate,T as BerryFreeReactMaterialAdminDashboard,c as BerryReactMaterialUIDashboardTemplate,I as DeviasKitClientAndAdminDashboard,p as DeviasKitProClientAndAdminDashboard,L as LotruJoyUiDashboard,S as MantisFreeReactAdminDashboardTemplate,d as MantisReactMaterialUIDashboardTemplate,x as MaterioNextJsAdminTemplate,a as MinimalClientAndAdminDashboard,i as MiraProReactMaterialUIAdminDashboard,s as ModernizeNextJsFreeAdminTemplate,D as ModernizeReactAndNextJsAdminDashboard,y as Onepirate,j as OtisAdminProMaterialDashboardForReact,f as OtisKitProMaterialKitForReact,m as Paperbase,o as SaasAbleFreeMultipurposeUiKitAndDashboardTemplate,A as SaasAbleMultipurposeUiKitAndDashboardTemplate,F as SoftUiProReactAdminDashboardTemplate,n as TheFrontMultipurposeTemplateAndUIKitDeviasKitProClientAndAdminDashboard,h as UIFoundationsKitSaaSDashboardTemplateDeviasKitProClientAndAdminDashboard,g as UKOClientAndAdminDashboardNextJsAndVite,k as UifortReactClientAndAdminDashboardTemplate,M as WebbeeMultipurposeLandingPageUiKit,u as ZoneMultipurposeLandingPageUIKit,O as __namedExportsOrder,N as default};
