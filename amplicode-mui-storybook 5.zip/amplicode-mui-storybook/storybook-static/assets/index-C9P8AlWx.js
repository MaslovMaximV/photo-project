import{g as r}from"./iframe-U1MoWpc_.js";import{r as o}from"./index-BP8LJUfb.js";var t=o();const m=r(t);export{m as P,t as r};
