import{j as r,G as a}from"./iframe-U1MoWpc_.js";import{G as o}from"./Grid-DSEZCbod.js";import{B as s}from"./Box-nnrC_EdN.js";import{P as c}from"./Paper-BtmMZDrw.js";import{T as i}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./useTheme-CMyrA-7l.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createTheme-CB0G2ADO.js";import"./useTheme-DUWNGOj_.js";import"./styled-DKEkqMyo.js";import"./extendSxProp-Cl0Joej-.js";import"./isMuiElement-BH3XSIgM.js";import"./useThemeProps-DLpnsM8j.js";import"./getThemeProps-4b2KySkp.js";import"./memoTheme-BNYDzr43.js";import"./index-CR3QZgfD.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";const P={title:"Layout/Grid",component:o,parameters:{layout:"centered",controls:{exclude:["divider"]}},decorators:[n=>r.jsx(s,{width:500,children:n()})],argTypes:{spacing:{control:"select",options:[1,2,3,4,5,6,7,8]},rowSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columnSpacing:{control:"select",options:[1,2,3,4,5,6,7,8]},columns:{control:"select",options:[7,12,16,20,24]}},args:{spacing:2},tags:["wrapper"]},t={render:({...n})=>r.jsx(o,{container:!0,children:r.jsx(a.Exclude,{children:new Array(10).fill(1).map((e,p)=>p+1).map(e=>r.jsx(o,{size:3,children:r.jsxs(i,{variant:"body1",textAlign:"center",p:2,children:["Demo ",e]})}))})}),decorators:[n=>r.jsxs(c,{children:[r.jsx(i,{variant:"body1",textAlign:"center",p:2,children:"Component to wrap node with Grid container"}),n()]})]};t.parameters={...t.parameters,docs:{...t.parameters?.docs,source:{originalSource:`{
  render: ({
    ...props
  }) => {
    return <Grid container>
        <GenerationInstructions.Exclude>
          {new Array(10).fill(1).map((_, index) => index + 1).map(item => {
          return <Grid size={3}>
                  <Typography variant="body1" textAlign={"center"} p={2}>
                    Demo {item}
                  </Typography>
                </Grid>;
        })}
        </GenerationInstructions.Exclude>
      </Grid>;
  },
  decorators: [Story => {
    return <Paper>
          <Typography variant="body1" textAlign={"center"} p={2}>
            Component to wrap node with Grid container
          </Typography>
          {Story()}
        </Paper>;
  }]
}`,...t.parameters?.docs?.source}}};const _=["Contaier"];export{t as Contaier,_ as __namedExportsOrder,P as default};
