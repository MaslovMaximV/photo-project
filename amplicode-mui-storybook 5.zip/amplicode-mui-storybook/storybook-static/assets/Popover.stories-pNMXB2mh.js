import{r as m,j as o,G as d}from"./iframe-U1MoWpc_.js";import{P as p}from"./Popover-Ti7x1Jzs.js";import{B as s}from"./Box-nnrC_EdN.js";import{B as h}from"./Button-Z4BDc59h.js";import{T as u}from"./Typography-NbeDhiLn.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./isHostComponent-DVu5iVWx.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./DefaultPropsProvider-Drazl94h.js";import"./ownerDocument-DW-IO8s5.js";import"./ownerWindow-HkKU3E4x.js";import"./debounce-Be36O1Ab.js";import"./Grow-YN3686EE.js";import"./useTheme-CMyrA-7l.js";import"./useTheme-DUWNGOj_.js";import"./utils-DUlJK7XT.js";import"./useTimeout-CYujZKVu.js";import"./index-C9P8AlWx.js";import"./index-BP8LJUfb.js";import"./getReactElementRef-BK8oRZgb.js";import"./mergeSlotProps-BszqYXGC.js";import"./Modal-Cups6cDA.js";import"./memoTheme-BNYDzr43.js";import"./FocusTrap-aa0DuC0e.js";import"./useEventCallback-ELgNMDCa.js";import"./createChainedFunction-BO_9K8Jh.js";import"./Portal-Dc2RZP_l.js";import"./Backdrop-DKjtt3hE.js";import"./Fade-P8xhlTFS.js";import"./Paper-BtmMZDrw.js";import"./extendSxProp-Cl0Joej-.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useId-vd1Ifx8D.js";import"./ButtonBase-BUPfvClL.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./isFocusVisible-B8k4qzLc.js";import"./CircularProgress-Bb4IBCi9.js";import"./index-CR3QZgfD.js";const to={title:"Utils/Popover",component:p,parameters:{docs:{description:{component:"The <code>Popover</code> component displays content on top of another element, anchored to it. It is typically used for contextual menus, tooltips, or additional information triggered by user actions."}}}},n={render:()=>{const[t,r]=m.useState(null),a=l=>{r(l.currentTarget)},c=()=>{r(null)},e=!!t,i=e?"simple-popover":void 0;return o.jsxs(s,{children:[o.jsx(h,{"aria-describedby":i,variant:"contained",onClick:a,children:"Open Popover"}),o.jsx(d.InsertOnly,{children:o.jsx(p,{id:i,open:e,anchorEl:t,onClose:c,anchorOrigin:{vertical:"bottom",horizontal:"right"},children:o.jsx(s,{sx:{p:2},children:o.jsx(u,{children:"This is the Popover content."})})})})]})},parameters:{docs:{description:{story:"A simple `Popover` anchored to a button, closing on click outside."}}}};n.parameters={...n.parameters,docs:{...n.parameters?.docs,source:{originalSource:`{
  render: () => {
    const [anchorEl, setAnchorEl] = useState<HTMLButtonElement | null>(null);
    const handleClick = (event: React.MouseEvent<HTMLButtonElement>) => {
      setAnchorEl(event.currentTarget);
    };
    const handleClose = () => {
      setAnchorEl(null);
    };
    const open = Boolean(anchorEl);
    const id = open ? "simple-popover" : undefined;
    return <Box>
        <Button aria-describedby={id} variant="contained" onClick={handleClick}>
          Open Popover
        </Button>
        <GenerationInstructions.InsertOnly>
          <Popover id={id} open={open} anchorEl={anchorEl} onClose={handleClose} anchorOrigin={{
          vertical: "bottom",
          horizontal: "right"
        }}>
            <Box sx={{
            p: 2
          }}>
              <Typography>This is the Popover content.</Typography>
            </Box>
          </Popover>
        </GenerationInstructions.InsertOnly>
      </Box>;
  },
  parameters: {
    docs: {
      description: {
        story: "A simple \`Popover\` anchored to a button, closing on click outside."
      }
    }
  }
}`,...n.parameters?.docs?.source}}};const ro=["Basic"];export{n as Basic,ro as __namedExportsOrder,to as default};
