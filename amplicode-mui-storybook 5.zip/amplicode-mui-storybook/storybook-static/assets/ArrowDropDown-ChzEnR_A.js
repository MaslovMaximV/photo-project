import{j as o}from"./iframe-U1MoWpc_.js";import{c as r}from"./createSvgIcon-Ck9VyYEl.js";const m=r(o.jsx("path",{d:"m7 10 5 5 5-5z"}));export{m as A};
