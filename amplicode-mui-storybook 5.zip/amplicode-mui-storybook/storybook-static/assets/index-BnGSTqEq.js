import{r as e,j as s}from"./iframe-U1MoWpc_.js";const r=e.createContext();function u({value:t,...o}){return s.jsx(r.Provider,{value:t??!0,...o})}const a=()=>e.useContext(r)??!1;export{u as R,a as u};
