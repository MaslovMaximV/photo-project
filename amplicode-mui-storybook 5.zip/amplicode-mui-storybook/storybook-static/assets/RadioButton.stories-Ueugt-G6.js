import{j as n}from"./iframe-U1MoWpc_.js";import{R as r}from"./Radio-BaYSeLyF.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./SwitchBase-9AkWq_7-.js";import"./DefaultPropsProvider-Drazl94h.js";import"./useFormControl-q410XUqr.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./useControlled-CeZ7-hqo.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";import"./createSvgIcon-Ck9VyYEl.js";import"./memoTheme-BNYDzr43.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./createChainedFunction-BO_9K8Jh.js";const C={title:"Inputs/Radio/RadioButton",component:r,parameters:{layout:"centered",controls:{}},decorators:[],argTypes:{checked:{control:"boolean"},size:{control:"select",options:["small","medium","large"]},color:{control:"select",options:["primary","secondary","success","error","info","warning"]}},args:{checked:!1,size:"medium",color:"primary"}},o={render:({checked:e,size:t,color:i})=>n.jsx(r,{checked:e,onChange:()=>{},size:t,color:i,value:"radio",name:"radio-buttons"})};o.parameters={...o.parameters,docs:{...o.parameters?.docs,source:{originalSource:`{
  render: ({
    checked,
    size,
    color
  }) => {
    return <Radio checked={checked} onChange={() => {}} size={size} color={color} value="radio" name="radio-buttons" />;
  }
}`,...o.parameters?.docs?.source}}};const E=["Single"];export{o as Single,E as __namedExportsOrder,C as default};
