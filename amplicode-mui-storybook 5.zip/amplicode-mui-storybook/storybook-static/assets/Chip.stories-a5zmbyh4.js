import{j as s}from"./iframe-U1MoWpc_.js";import{C as i}from"./Chip-8gafZhjN.js";import"./preload-helper-D9Z9MdNV.js";import"./createTheme-CB0G2ADO.js";import"./createSvgIcon-Ck9VyYEl.js";import"./memoTheme-BNYDzr43.js";import"./DefaultPropsProvider-Drazl94h.js";import"./createSimplePaletteValueFilter-bm0fmN_7.js";import"./useSlot-ntrDZa7C.js";import"./mergeSlotProps-A8yMhZdW.js";import"./useForkRef-OOgs0334.js";import"./ButtonBase-BUPfvClL.js";import"./useTimeout-CYujZKVu.js";import"./emotion-react.browser.esm-B8CpGYti.js";import"./useEventCallback-ELgNMDCa.js";import"./isFocusVisible-B8k4qzLc.js";const B={title:"DataDisplay/Chip",component:i,parameters:{layout:"centered",controls:{exclude:["onDelete"]}},decorators:[],argTypes:{label:{control:"text"},variant:{control:"select",options:["outlined","filled"]},size:{control:"select",options:["small","medium","large"]},color:{control:"select",options:["primary","secondary","success","error","info","warning"]}},args:{variant:"filled",label:"Chip Info",size:"medium",color:"primary"}},r={render:({variant:o,size:t,color:a,label:n})=>s.jsx(i,{variant:o,size:t,color:a,label:n})},e={render:({variant:o,size:t,color:a,label:n,...l})=>s.jsx(i,{variant:o,size:t,color:a,label:n,onDelete:()=>{},...l})};r.parameters={...r.parameters,docs:{...r.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    size,
    color,
    label
  }) => {
    return <Chip variant={variant} size={size} color={color} label={label} />;
  }
}`,...r.parameters?.docs?.source}}};e.parameters={...e.parameters,docs:{...e.parameters?.docs,source:{originalSource:`{
  render: ({
    variant,
    size,
    color,
    label,
    ...props
  }) => {
    return <Chip variant={variant} size={size} color={color} label={label} onDelete={() => {}} {...props} />;
  }
}`,...e.parameters?.docs?.source}}};const E=["Basic","WithDelete"];export{r as Basic,e as WithDelete,E as __namedExportsOrder,B as default};
