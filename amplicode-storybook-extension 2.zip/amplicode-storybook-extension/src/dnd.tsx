import React from "react";

interface DraggableBase {
  children: React.JSX.Element;
  ["data-proceed"]: "asIs" | "generateComponent";
}

interface DraggableCommonComponent extends DraggableBase {
  ["data-proceed"]: "asIs";
}

interface DraggableGenerateComponent extends DraggableBase {
  ["data-proceed"]: "generateComponent";
  ["data-component-name"]: string;
  ["data-component-package"]: string;
  ["data-default-export"]: boolean;
}

type DraggableProps = DraggableCommonComponent | DraggableGenerateComponent;

export function Draggable({ children, ...props }: DraggableProps) {
  return (
    <div
      draggable
      style={{
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        cursor: "pointer",
      }}
      {...props}
    >
      {children}
    </div>
  );
}
