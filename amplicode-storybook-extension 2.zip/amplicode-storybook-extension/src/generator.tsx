import { ReactNode } from "react";
// import { InputType } from "storybook/internal/types";

export namespace GenerationInstructions {
  export const Exclude = (props: { children?: ReactNode }) => {
    return <>{props.children}</>;
  };

  export const InsertOnly = (props: { children: ReactNode }) => {
    return <>{props.children}</>;
  };
}

export function replaceOnGenerate<T>(storyParam: T, insertParam: T) {
  return storyParam;
}

export function topLevel<T>(content: T): T {
  return content;
}

export type WizardInfo<T> = {
  wizardName: string;
  info: T;
};

export function generatorProp(config: {
  description?: string;
  generatorId: string;
  hideInStoryBook?: undefined | true;
  defaultValue?: any;
}) {
  const result: Record<string, any> = {};

  if (config.hideInStoryBook) {
    result.table = { disable: true };
  }

  if (config.description) {
    result.description = config.description;
  }

  if (config.defaultValue) {
    result.defaultValue = config.defaultValue;
  }

  return result;
}