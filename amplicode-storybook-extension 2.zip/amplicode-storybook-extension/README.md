## Amplicode Storybook Extension _by Amplicode Team_ [![npm version](https://img.shields.io/npm/v/@amplicode/storybook-extensions.svg)](https://www.npmjs.com/package/@amplicode/storybook-extensions)

The package provides extensions for [Storybook](https://storybook.js.org/) API that is used by the [Amplicode](https://marketplace.visualstudio.com/items?itemName=Haulmont.amplicode) VS Code extension.

The extension offers developers tools to use their stories as a component palette.